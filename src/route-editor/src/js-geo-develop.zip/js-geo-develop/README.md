# Js Geo


> [object Object]

## Installation

```sh
npm install @elbit/js-geo --save
```

## Usage

```js
var jsGeo = require('@elbit/js-geo')

jsGeo() //=> "Hello World!"
```

## License

MIT license



