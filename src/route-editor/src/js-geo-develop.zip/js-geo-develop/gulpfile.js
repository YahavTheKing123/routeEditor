//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

var gulp = require('gulp');
var babel = require('gulp-babel');
var bump = require('gulp-bump');
var sourcemaps = require('gulp-sourcemaps');

