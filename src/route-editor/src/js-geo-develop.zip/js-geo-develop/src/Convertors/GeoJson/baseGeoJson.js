//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 31/10/2017.
 */
const { Logger } = require ( '@elbit/logger-server');
const logger = Logger.getLogger("BaseGeoJson");
const {geoKind} =require("../../Types/geoKind");


class BaseGeoJson {

  makePolygonRing(polygonCoordinates) {
    if (polygonCoordinates.length >= 1) {
      let coord = polygonCoordinates[0];
      if (coord.length >= 3) {
        if (Math.abs(coord[coord.length - 1][0] - coord[0][0]) < 0.00002   //compare longitude
          && Math.abs(coord[coord.length - 1][1] - coord[0][1]) < 0.00002) {
          coord[coord.length - 1] = coord[0];
        } else { //the difference is not minor, add new point that is exactly like first point
          coord[coord.length] = coord[0];
        }
        return polygonCoordinates;
      } else {
        logger.error("The input coordinates length for geoJson polygon ring check should be at least 3.");
        return null;
      }
    } else {
      logger.error("The input coordinates length for geoJson polygon ring is wrong.");
      return null;
    }
  }


  createGeoJsonSection(shape, geoJsonType) {
    function getFallback(shape, context) {

      let baseGeometryShape = shape.getShapeFallback();
      if (baseGeometryShape != null) {
        let coordinates = baseGeometryShape.coordinates;
        if (coordinates != null) {
          if (coordinates.length > 0) {
            let arrOfCoordinates = context.buildPolylineCoordinates(coordinates);
            let array = null;
            if (baseGeometryShape.getPositionType() == geoKind.Point.Name) {
              return arrOfCoordinates[0];
            } else if (baseGeometryShape.getPositionType() == geoKind.Polygon.Name) {
              let coordinates = [];
              coordinates[0] = arrOfCoordinates;
              coordinates = context.makePolygonRing(coordinates);
              return coordinates;
            } else if (baseGeometryShape.getPositionType() == geoKind.Polyline.Name) {
              return arrOfCoordinates;
            }
            return array;
          } else {
            logger.error("cannot get fallback, result returned with empty coordinates");
          }
        } else {
          logger.error("cannot get fallback, result returned without coordinates");
        }
      } else {
        logger.error("cannot get fallback, result returned as null");
      }
      return null;
    }


    let node = {};
    node["type"] = "Feature";
    node["geometry"] = {};
    node.geometry["type"] = geoJsonType;
    node.geometry["coordinates"] = getFallback(shape, this);
    return node;
  }


  buildPolygonCoordinates(coordinates) {
    let resultCoordinates = [];
    resultCoordinates[0] = this.buildPolylineCoordinates(coordinates);
    resultCoordinates = this.makePolygonRing(resultCoordinates);
    return resultCoordinates;
  }

  buildPolylineCoordinates(coordinates) {
    let resultCoordinates = [];
    for (let i = 0; i < coordinates.length; i++) {
      resultCoordinates[i] = [];
      resultCoordinates[i][0] = coordinates[i].getLongitude();
      resultCoordinates[i][1] = coordinates[i].getLatitude();
      if (coordinates[i].getAltitude()) {
        resultCoordinates[i][2] = coordinates[i].getAltitude();
      }
    }
    return resultCoordinates;
  }

  createGeoJsonCoordinate(coordinates) {
    if (coordinates != null && coordinates != undefined && coordinates.length > 0) {
      let centerPoint = [];
      centerPoint.push(coordinates[0].longitude);
      centerPoint.push(coordinates[0].latitude);
      if (coordinates[0].altitude != undefined) {
        centerPoint.push(coordinates[0].altitude);
      }
      return centerPoint;
    }
    return null;
  }
}
module.exports={BaseGeoJson};
