//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 31/10/2017.
 */
const {geoJSONTypes}=require("./geoJsonTypes");
const { Logger } = require ( '@elbit/logger-server');
const logger = Logger.getLogger("GeoJsonPoint");
const {BaseGeoJson}=require("./baseGeoJson");
const {returnTypeEnum} =require("../../Types/returnTypeEnum");

class GeoJsonPoint extends BaseGeoJson{

  createGeoJson(customGeoShape, returnType) {
    try {
      let node;
      if (returnType == returnTypeEnum.geoJsonPlusPlusOnly) { //if geo++
        node = this.createGeoPlusPlus(customGeoShape);
      } else if (returnType == returnTypeEnum.geoJsonPlusPlus) { //plus plus with geoJson
        node = this.createGeoJsonSection(customGeoShape, geoJSONTypes.Point);
        node = this.createGeoPlusPlus(customGeoShape,node);
      } else if (returnType == returnTypeEnum.geoJson) {
        node = this.createGeoJsonSection(customGeoShape, geoJSONTypes.Point);
      }
      return node;
    }
    catch (exception) {
      logger.error("Error occurred in GeoJsonPoint.createGeoJson method", exception);
      return null;
    }
    return null;
  }

  createGeoPlusPlus(customGeoShape, rootNode) {
    if (rootNode == null || rootNode == undefined) {
      rootNode = {};
    }
    rootNode["shape"] = geoJSONTypes.Point;
    rootNode["coordinates"] = this.createGeoJsonCoordinate(customGeoShape.coordinates);
    return rootNode;
  }
}

module.exports={GeoJsonPoint};
