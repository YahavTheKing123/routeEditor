//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 31/10/2017.
 */
let geoJSONTypes = {
  "Point": "Point",
  "LineString": "LineString",
  "Polygon": "Polygon",
  "GeoCamera": "GeoCamera",
  "Circle": "Circle",
  "Ellipse": "Ellipse",
  "Rectangle": "Rectangle",
  "Sector": "Sector",
  "Corridor": "Corridor",
  "Arrow": "Arrow",
  "Arc": "Arc",
  "TwoPoints": "TwoPoints"
};
module.exports = {geoJSONTypes};
