//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

class CoordSysConvertor {

  constructor() {

  }

  /**
   * Convert coordinate from geo to mgrs
   * @param coord
   * @param datum of the geo
   * @returns mgrs coordinate
   */
  static convertGeoToMgrs(coord, datum = GEOGRAPHIC_LIBRARY_DATUM) {
    return this.coordSysConvLibrary.geoToMgrs(coord, datum);
  }

  /**
   * Convert coordinate from mgrs to geo
   * @param coord - mgrs coord
   * @param datum of the geo
   * @returns geo coordinate
   */
  static convertMgrsToGeo(coord, datum = GEOGRAPHIC_LIBRARY_DATUM) {
    return this.coordSysConvLibrary.mgrsToGeo(coord, datum);
  }

  /**
   * Convert coordinate from geo to bng
   * @param coord
   * @param datum of the geo
   * @returns bng coordinate
   */
  static convertGeoToBng(coord, datum = GEOGRAPHIC_LIBRARY_DATUM) {
    return this.coordSysConvLibrary.geoToBng(coord, datum);
  }

  /**
   * Convert coordinate from bng to geo
   * @param coord - bng coord
   * @param datum of the geo
   * @returns geo coordinate
   */
  static convertBngToGeo(coord, datum = GEOGRAPHIC_LIBRARY_DATUM) {
    return this.coordSysConvLibrary.bngToGeo(coord, datum);
  }

  /**
   * Convert coordinate from geo to utm
   * @param coord
   * @param srcDatum - datum of the geo
   * @param dstDatum - datum of the utm
   * @returns {{zone, coordinate in utm}|*}
   */
  static convertGeoToUtm(coord, srcDatum = GEOGRAPHIC_LIBRARY_DATUM, dstDatum = GEOGRAPHIC_LIBRARY_DATUM) {
    return this.coordSysConvLibrary.geoToUtm(coord, srcDatum, dstDatum);
  }

  /**
   * Convert coordinate from utm to geo
   * @param coord
   * @param zone
   * @param srcDatum - datum of the utm
   * @param dstDatum - datum of the geo
   * @returns {*}
   */
  static convertUtmToGeo(coord, srcDatum = GEOGRAPHIC_LIBRARY_DATUM, dstDatum = GEOGRAPHIC_LIBRARY_DATUM) {
    return this.coordSysConvLibrary.utmToGeo(coord, srcDatum, dstDatum);
  }


  /**
   * Convert coordinate from geo to s42
   * @param coord
   * @param srcDatum - datum of the geo
   * @param dstDatum - datum of the s42
   * @returns {{zone, coordinate in s42}|*}
   */
  static convertGeoToS42(coord, srcDatum = GEOGRAPHIC_LIBRARY_DATUM, dstDatum = GEOGRAPHIC_LIBRARY_DATUM) {
    return this.coordSysConvLibrary.geoToS42(coord, srcDatum, dstDatum);
  }

  /**
   * Convert coordinate from s42 to geo
   * @param coord
   * @param zone
   * @param srcDatum - datum of the s42
   * @param dstDatum - datum of the geo
   * @returns {*}
   */
  static convertS42ToGeo(coord, srcDatum = GEOGRAPHIC_LIBRARY_DATUM, dstDatum = GEOGRAPHIC_LIBRARY_DATUM) {
    try {
      return this.coordSysConvLibrary.s42ToGeo(coord, srcDatum, dstDatum);
    } catch (ex) {
      return null;
    }
  }

  /**
   * Convert coordinate from geo to irish
   * @param coord
   * @param srcDatum - datum of the geo
   * @returns irish coord
   */
  static convertGeoToIrishWorld(coord, srcDatum = GEOGRAPHIC_LIBRARY_DATUM) {
    return this.coordSysConvLibrary.geoToIrish(coord, srcDatum);
  }

  /**
   * Convert coordinate from irish to geo
   * @param coord
   * @param dstDatum - datum of the geo
   * @returns {geo coord}
   */
  static convertIrishWorldToGeo(coord, dstDatum = GEOGRAPHIC_LIBRARY_DATUM) {
    return this.coordSysConvLibrary.irishToGeo(coord, dstDatum);
  }

  /**
   * Convert coordinate from geo to irish
   * @param coord
   * @param srcDatum - datum of the geo
   * @returns irish coord
   */
  static convertGeoToGars(coord, srcDatum = GEOGRAPHIC_LIBRARY_DATUM) {
    return this.coordSysConvLibrary.geoToGars(coord, srcDatum);
  }

  /**
   * Convert coordinate from irish to geo
   * @param coord
   * @param dstDatum - datum of the geo
   * @returns {geo coord}
   */
  static convertGarsToGeo(gars5minute, dstDatum = GEOGRAPHIC_LIBRARY_DATUM) {
    return this.coordSysConvLibrary.garsToGeo(gars5minute, dstDatum);
  }

  /**
   * Convert coordinate from geo to generic
   * @param coord
   * @param srcDatum - datum of the geo
   * @returns generic coord
   */
  static convertGeoToGeneric(coord, gridEpsg, srcDatum = GEOGRAPHIC_LIBRARY_DATUM) {
    return this.coordSysConvLibrary.geoToGeneric(coord, gridEpsg, srcDatum);
  }

  /**
   * Convert coordinate from generic to geo
   * @param coord
   * @param dstDatum - datum of the geo
   * @returns {geo coord}
   */
  static convertGenericToGeo(coord, gridEpsg, dstDatum = GEOGRAPHIC_LIBRARY_DATUM) {
    return this.coordSysConvLibrary.genericToGeo(coord, gridEpsg, dstDatum)
  }

  /**
   * convert geo to grid azimuth
   * @param coord
   * @param geoAzimuth
   * @returns {*}
   */
  static convertGeoToGridAzimuth(coord, geoAzimuth, datum = GEOGRAPHIC_LIBRARY_DATUM) {
    return this.coordSysConvLibrary.geoToGridAzimuth(coord, geoAzimuth, datum)
  }


  /**
   * convert grid to geo azimuth
   * @param coord
   * @param gridAzimuth
   * @returns {*}
   */
  static convertGridToGeoAzimuth(coord, gridAzimuth, datum = GEOGRAPHIC_LIBRARY_DATUM) {
    return this.coordSysConvLibrary.gridToGeoAzimuth(coord, gridAzimuth, datum)
  }

  static dmsToDm({degrees, minutes, seconds}) {
    let Mm = minutes + (seconds / 60);
    return {degrees, Mm};
  }

  static dmsToDd({degrees, minutes, seconds}) {
    if (degrees < 0) {
      return degrees - (minutes / 60) - (seconds / 3600);
    } else {
      return degrees + (minutes / 60) + (seconds / 3600);
    }

  }

  static dmToDd({degrees, minutes}) {
    if (degrees < 0) {
      return degrees - (minutes / 60);
    } else {
      return degrees + (minutes / 60);
    }
  }

  static ddToDms(decimalDegrees) {
    let d = Math.trunc(decimalDegrees);
    let m = Math.abs(Math.trunc((decimalDegrees - d) * 60));
    let s = Math.abs((Math.abs(decimalDegrees) - Math.abs(d) - Math.abs(m) / 60) * 3600);
    return {d, m, s};
  }

  static ddToDm(decimalDegrees) {
    let d = Math.trunc(decimalDegrees);
    let m = Math.abs((Math.abs(decimalDegrees) - Math.abs(d)) * 60);
    return {d, m};
  }
}


var coordinateSystemEnum = Object.freeze({
  GEO: 0,
  UTM: 1,
  MGRS: 2,
  S42: 3,
  BNG: 4,
  IRISH_WORLD: 5,
  GARS: 6,
});


module.exports = {CoordSysConvertor, coordinateSystemEnum};
