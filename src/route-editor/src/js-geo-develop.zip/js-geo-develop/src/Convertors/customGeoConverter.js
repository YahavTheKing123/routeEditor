//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 01/11/2017.
 */
const {Polygon} =require("../Shapes/polygon");
const {Polyline} =require("../Shapes/polyline");
const {Point} =require("../Shapes/point");
const {Circle} =require("../Shapes/circle");
const {Ellipse} =require("../Shapes/ellipse");
const {Rectangle} =require("../Shapes/rectangle");
const {Sector} =require("../Shapes/sector");
const {Corridor} =require("../Shapes/corridor");
const {Arrow} =require("../Shapes/arrow");
const {Arc} =require("../Shapes/arc");
const {GeoCamera} =require("../Shapes/geoCamera");
const {TwoPoints} =require("../Shapes/twoPoints");
const {geoKind} =require("../Types/geoKind");

class CustomGeoConverter
{
    static convertToBaseGeometryShape(type,geometry)
    {
        if (type) {
          if (type=="LineString")
          {
            type=geoKind.Polyline.Name;
          }
          let shape;
          switch (type) {
            case geoKind.Polygon.Name: {
              shape = new Polygon();
              break;
            }
            case geoKind.Polyline.Name: {
              shape = new Polyline();
              break;
            }
            case geoKind.Point.Name: {
              shape = new Point();
              break;
            }
            case geoKind.Circle.Name: {
              shape = new Circle();
              break;
            }
            case geoKind.Ellipse.Name: {
              shape = new Ellipse();
              break;
            }
            case geoKind.Rectangle.Name: {
              shape = new Rectangle();
              break;
            }
            case geoKind.Sector.Name: {
              shape = new Sector();
              break;
            }
            case geoKind.Corridor.Name: {
              shape = new Corridor();
              break;
            }
            case geoKind.Arrow.Name: {
              shape = new Arrow();
              break;
            }
            case geoKind.Arc.Name: {
              shape = new Arc();
              break;
            }
            case geoKind.GeoCamera.Name: {
              shape = new GeoCamera();
              break;
            }
            case geoKind.TwoPoints.Name: {
              shape = new TwoPoints();
              break;
            }
          }

          if (shape != null && shape != undefined) {
            shape.initFromGeoJson(geometry);
            return shape;
          }
        }
    }
}
module.exports={CustomGeoConverter};
