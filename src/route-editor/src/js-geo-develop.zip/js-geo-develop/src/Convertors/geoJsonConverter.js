//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 06/11/2017.
 */
const {GeoJsonPoint} = require("./GeoJson/geoJsonPoint");
const {GeoJsonPolygon} = require("./GeoJson/geoJsonPolygon");
const {GeoJsonLineString} = require("./GeoJson/geoJsonLineString");
const {GeoJsonCircle} = require("./GeoJson/geoJsonCircle");
const {GeoJsonRectangle} = require("./GeoJson/geoJsonRectangle");
const {GeoJsonSector} = require("./GeoJson/geoJsonSector");
const {GeoJsonArc} = require("./GeoJson/geoJsonArc");
const {GeoJsonCorridor} = require("./GeoJson/geoJsonCorridor");
const {GeoJsonArrow} = require("./GeoJson/geoJsonArrow");
const {GeoJsonEllipse} = require("./GeoJson/geoJsonEllipse");
const {GeoJsonGeoCamera} = require("./GeoJson/geoJsonGeoCamera");
const {GeoJsonTwoPoints} = require("./GeoJson/geoJsonTwoPoints");
const {geoKind} = require("../Types/geoKind");
const {Logger} = require('@elbit/logger-server');
const logger = Logger.getLogger("GeoJsonConverter");
const {returnTypeEnum} = require("../Types/returnTypeEnum");

class GeoJsonConverter {
  static convertToGeoJson(customGeoShape, returnType) {
    logger.trace("Trying to convert custom geo object ('" + customGeoShape.getPositionType() + "') to geoJson\\geoJson++.");
    let geoJsonShape;
    switch (customGeoShape.getPositionType()) {
      case geoKind.Point.Name: {
        geoJsonShape = new GeoJsonPoint();
        break;
      }
      case geoKind.Polygon.Name: {
        geoJsonShape = new GeoJsonPolygon();
        break;
      }
      case geoKind.Polyline.Name: {
        geoJsonShape = new GeoJsonLineString();
        break;
      }
      case geoKind.Ellipse.Name: {
        geoJsonShape = new GeoJsonEllipse();
        break;
      }
      case geoKind.Circle.Name: {
        geoJsonShape = new GeoJsonCircle();
        break;
      }
      case geoKind.Rectangle.Name: { //GeoJson++
        geoJsonShape = new GeoJsonRectangle();
        break;
      }
      case geoKind.Sector.Name: { //GeoJson++
        geoJsonShape = new GeoJsonSector();
        break;
      }
      case geoKind.Corridor.Name: { //GeoJson++
        geoJsonShape = new GeoJsonCorridor();
        break;
      }
      case geoKind.Arrow.Name: { //GeoJson++
        geoJsonShape = new GeoJsonArrow();
        break;
      }
      case geoKind.Arc.Name: { //GeoJson++
        geoJsonShape = new GeoJsonArc();
        break;
      }
      case geoKind.GeoCamera.Name: { //GeoJson++
        geoJsonShape = new GeoJsonGeoCamera();
        break;
      }
      case geoKind.TwoPoints.Name: { //GeoJson++
        geoJsonShape = new GeoJsonTwoPoints();
        break;
      }
    }
    if (geoJsonShape != null && geoJsonShape != undefined) {
      return geoJsonShape.createGeoJson(customGeoShape, returnType)
    }
  }

  /**
   * convert from standard geo json
   * @param geoJsonObj
   * @returns {{type}|*|{geometry: ({type}|*), type: string}|*}
   */
  static convertFromStandardGeoJsonToJsGeoJson(geoJsonObj) {
    logger.trace("Trying to convert standard geoJson ('" + geoJsonObj + "') to geoJson");
    if (!geoJsonObj.isCustomGeoObject && geoJsonObj.type) {
      if (geoJsonObj.type == "Point" || geoJsonObj.type == "LineString" || geoJsonObj.type == "Polygon") {
        return {
          type: "Feature",
          geometry: geoJsonObj
        }
      } else {
        return geoJsonObj
      }
    }
    return geoJsonObj
  }
}

module.exports = {GeoJsonConverter};
