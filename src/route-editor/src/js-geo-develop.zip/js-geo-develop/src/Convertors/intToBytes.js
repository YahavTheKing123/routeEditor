//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 25/10/2017.
 */

class IntToBytes
{
    static toBytes(bufferToWrite, idxToStartObj, valueToConvert,isDeltaCalculation) {
        let negative;
        if (valueToConvert < 0) {
            valueToConvert *= -1;
            negative=128;//10000000
        }
        else {
            negative=0;
        }

        valueToConvert=parseInt(valueToConvert);

        if (isDeltaCalculation) {
            let isTwoBytes;
            if ((valueToConvert > TWO_BYTES_LOWER_RANGE && valueToConvert < TWO_BYTES_UPPER_RANGE_MINUS_TWO_BIT)) {
                isTwoBytes=64;//01000000
                bufferToWrite[idxToStartObj.value + 1] = valueToConvert & 0xff;
                bufferToWrite[idxToStartObj.value] = (valueToConvert >> ONE_BYTE_OFFSET ) & 0xff | negative | isTwoBytes;
                idxToStartObj.value += 2
            }
            else {
                isTwoBytes = 0;
                bufferToWrite[idxToStartObj.value + 3] = valueToConvert & 0xff;
                bufferToWrite[idxToStartObj.value + 2] = (valueToConvert >> ONE_BYTE_OFFSET ) & 0xff;
                bufferToWrite[idxToStartObj.value + 1] = (valueToConvert >> TWO_BYTE_OFFSET ) & 0xff;
                bufferToWrite[idxToStartObj.value] = ((valueToConvert >> THREE_BYTE_OFFSET ) & 0xff) | negative | isTwoBytes;
                idxToStartObj.value += 4;
            }
        }
        else {
            /* bufferToWrite[idxToStartObj.value++] = valueToConvert & 0xff;
             bufferToWrite[idxToStartObj.value++] = (valueToConvert >> ONE_BYTE_OFFSET ) & 0xff;
             bufferToWrite[idxToStartObj.value++] = (valueToConvert >> TWO_BYTE_OFFSET ) & 0xff;
             bufferToWrite[idxToStartObj.value++] = ((valueToConvert >> THREE_BYTE_OFFSET ) & 0xff) | negative;*/
            bufferToWrite[idxToStartObj.value+3] = valueToConvert & 0xff ;
            bufferToWrite[idxToStartObj.value+2] = (valueToConvert >> ONE_BYTE_OFFSET ) & 0xff;
            bufferToWrite[idxToStartObj.value+1] = (valueToConvert >> TWO_BYTE_OFFSET ) & 0xff;
            bufferToWrite[idxToStartObj.value] = ((valueToConvert >> THREE_BYTE_OFFSET ) & 0xff) | negative;
            idxToStartObj.value+=4;
        }
    }

    static fromBytes(bufferToRead, idxToStartObj,isDeltaCalculation) {
        if (isDeltaCalculation)
        {
            let isNegative;
            let isTwoBytes;
            let result=bufferToRead[idxToStartObj.value] &  192; //(192=11000000)
            if (result==0)
            {
                isNegative=false;
                isTwoBytes=false;
            }
            else if (result==64)
            {
                isNegative=false;
                isTwoBytes=true;

            }
            else if (result==128)
            {
                isNegative=true;
                isTwoBytes=false;
            }
            else if (result==192)
            {
                isNegative=true;
                isTwoBytes=true;
            }
            bufferToRead[idxToStartObj.value]=bufferToRead[idxToStartObj.value] & 63; //(127=00111111)
            let num =bufferToRead[idxToStartObj.value];
            num = num << ONE_BYTE_OFFSET;

            num += bufferToRead[idxToStartObj.value + 1];
            if (!isTwoBytes) {
                num = num << ONE_BYTE_OFFSET;
                num += bufferToRead[idxToStartObj.value + 2];
                num = num << ONE_BYTE_OFFSET;
                num += bufferToRead[idxToStartObj.value + 3];
                idxToStartObj.value += 4;
            }
            else
            {
                idxToStartObj.value += 2;
            }
            if (isNegative) {
                num *= -1;
            }
            return num;

        }
        else {
            let isNagative=bufferToRead[idxToStartObj.value] &  128; //(128=10000000)
            if (isNagative==0)
            {
                isNagative=false;
            }
            else
            {
                bufferToRead[idxToStartObj.value]=bufferToRead[idxToStartObj.value] & 127; //(127=01111111)
                isNagative=true;
            }
            let num =bufferToRead[idxToStartObj.value];
            num = num << ONE_BYTE_OFFSET;

            num += bufferToRead[idxToStartObj.value + 1];
            num = num << ONE_BYTE_OFFSET;

            num += bufferToRead[idxToStartObj.value + 2];
            num = num << ONE_BYTE_OFFSET;

            num += bufferToRead[idxToStartObj.value+3];

            idxToStartObj.value += 4;

            if (isNagative == 1) {
                num *= -1;
            }
            return num;

        }


    }
}
module.exports={IntToBytes};
