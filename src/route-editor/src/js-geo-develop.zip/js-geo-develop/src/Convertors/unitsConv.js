//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34018 on 28/12/17.
 */
const PI = Math.PI;
/**
 * Convert radians to degrees factor.
 */
const RAD_TO_DEG = 180 / Math.PI;
/**
 * Convert degrees to radians factor.
 */
const DEG_TO_RAD = Math.PI / 180;
/**
 * Convert degrees to mils factor.
 */
const DEG_TO_MILS = 17.777777778;
/**
 * Convert mils to degrees factor.
 */
const MILS_TO_DEG = 0.05625;
/** Convert radians to mils factor.
 */
const RAD_TO_MILS = 6400 / 2 * Math.PI;
/**
 * Convert mils to radians factor.
 */
const MILS_TO_RAD = 2 * Math.PI / 6400;

class UnitsConv {

  /**
   * Convert radians to degrees factor.
   */
  static radToDeg(val) {
    return val * RAD_TO_DEG;
  }

  /**
   * Convert degrees to radians factor.
   */
  static degToRad(val) {
    return val * DEG_TO_RAD;
  }

  /**
   * Convert degrees to mils factor.
   */
  static degToMils(val) {
    return val * DEG_TO_MILS;
  }

  /**
   * Convert mils to degrees factor.
   */
  static milsToDeg(val) {
    return val * MILS_TO_DEG;
  }

  /**
   * Convert radians to mils factor.
   */
  static radToMils(val) {
    return val * RAD_TO_MILS;
  }

  /**
   * Convert mils to radians factor.
   */
  static milsToRad(val) {
    return val * MILS_TO_RAD;
  }

}
module.exports={UnitsConv};
