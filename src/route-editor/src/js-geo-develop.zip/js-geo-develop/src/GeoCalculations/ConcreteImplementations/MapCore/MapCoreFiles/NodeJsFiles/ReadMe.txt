To use IMcGridGeneric in node.js, map "NodeJsFiles" directory to virtual "FS" directory by calling IMcMapDevice.MapNodeJsDirectory("NodeJsFiles", "FS") 
