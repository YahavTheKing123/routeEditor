//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

const {McCommonUtils} = require("./mcCommonUtils");
const {MgrsCoordinate} = require("../../../Types/mgrsCoordinate");
const {BngCoordinate} = require("../../../Types/bngCoordinate");
const {UtmCoordinate} = require("../../../Types/utmCoordinate");
const {IrishCoordinate} = require("../../../Types/irishCoordinate");
const {GarsCoordinate} = require("../../../Types/garsCoordinate");
const {datums} = require("../../../Types/datums");
const {coordinateSystemEnum} = require("../../../Convertors/coordSysConvertor");
const {Logger} = require('@elbit/logger-server');
const logger = Logger.getLogger("MapcoreConversionsCalculations");
var mapcoreCalculations;

class MapcoreConversionsCalculations {
  constructor(library) {
    if (library == null || library == undefined) {
      let path = "./MapCoreFiles/MapCore_Calculations";
      mapcoreCalculations = require(path);
    } else {
      mapcoreCalculations = library;
    }
    McCommonUtils.initMapcoreLibrary(mapcoreCalculations);
    this.gridConvertorMap = new Map();
    this.gridMgrs = undefined;
    this.gridBng = undefined;
    this.gridIrish = undefined;
    this.gridGars = undefined;
    this.geoCalcUtmMap = new Map();
  }

  /**
   *
   * @param coord
   * @param datum
   * @returns {*}
   */
  geoToMgrs(coord, datum) {
    if (!this.gridMgrs) {
      this.gridMgrs = mapcoreCalculations.IMcGridMGRS.Create();
    }
    let gridConvertor = this.getGridConverter(coordinateSystemEnum.GEO, datum, coordinateSystemEnum.MGRS, datums.UNDEFINED);
    let mcCoord = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(coord);
    let coordInMgrs = gridConvertor.ConvertAtoB(mcCoord);
    let fullMgrsCoord = this.gridMgrs.CoordToFullMGRS(coordInMgrs);
    return new MgrsCoordinate(fullMgrsCoord.Coord.x, fullMgrsCoord.Coord.y, fullMgrsCoord.Coord.z, fullMgrsCoord.Square.cSquareFst,
      fullMgrsCoord.Square.cSquareSnd, fullMgrsCoord.Square.cBand, fullMgrsCoord.Square.nZone);

  }

  mgrsToGeo(mgrsCoord, datum) {
    if (!this.gridMgrs) {
      this.gridMgrs = mapcoreCalculations.IMcGridMGRS.Create();
    }
    let mcCoord = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(mgrsCoord, false);
    let squre = mapcoreCalculations.IMcGridMGRS.SSquare();
    squre.nZone = mgrsCoord.getZone();
    squre.cSquareFst = mgrsCoord.getSquareFirst();
    squre.cSquareSnd = mgrsCoord.getSquareSecond();
    squre.cBand = mgrsCoord.getBand();
    let mcMgrsFullCoord = mapcoreCalculations.IMcGridMGRS.SFullMGRS();
    mcMgrsFullCoord.Coord = mcCoord;
    mcMgrsFullCoord.Square = squre;
    let mcMgrsCoord = this.gridMgrs.FullMGRSToCoord(mcMgrsFullCoord);

    let gridConvertor = this.getGridConverter(coordinateSystemEnum.MGRS, datums.UNDEFINED, coordinateSystemEnum.GEO, datum);
    let geoCoord = gridConvertor.ConvertAtoB(mcMgrsCoord);
    return McCommonUtils.convertMapcoreCoordinateToKnownCoordinate(geoCoord);
  }

  geoToUtm(geoCoord, srcDatum, dstDatum) {
    let zone = {Value: 0};

    let gridConvertor = this.getGridConverter(coordinateSystemEnum.GEO, srcDatum, coordinateSystemEnum.UTM, dstDatum, "", 0);
    let mcGeoCoord = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(geoCoord);
    let mcUtmCoord = gridConvertor.ConvertAtoB(mcGeoCoord, zone);
    let utmCoord = new UtmCoordinate(mcUtmCoord.x, mcUtmCoord.y, mcUtmCoord.z, zone.Value);
    return utmCoord;
  }

  utmToGeo(utmCoord, srcDatum, dstDatum) {
    let gridConvertor = this.getGridConverter(coordinateSystemEnum.UTM, srcDatum, coordinateSystemEnum.GEO, dstDatum, utmCoord.getZone());
    let mcUtmCoord = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(utmCoord, false);
    let mcGeoCoord = gridConvertor.ConvertAtoB(mcUtmCoord);
    return McCommonUtils.convertMapcoreCoordinateToKnownCoordinate(mcGeoCoord);
  }

  geoToS42(geoCoord, srcDatum, dstDatum) {
    let zone = {Value: 0};
    let gridConvertor = this.getGridConverter(coordinateSystemEnum.GEO, srcDatum, coordinateSystemEnum.S42, dstDatum, "", 0);
    let mcGeoCoord = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(geoCoord);
    let mcS42Coord = gridConvertor.ConvertAtoB(mcGeoCoord, zone);
    let utmCoord = new UtmCoordinate(mcS42Coord.x, mcS42Coord.y, mcS42Coord.z, zone.Value);
    return utmCoord;
  }

  s42ToGeo(utmCoord, srcDatum, dstDatum) {
    let zone = utmCoord.getZone();
    let gridConvertor = this.getGridConverter(coordinateSystemEnum.S42, srcDatum, coordinateSystemEnum.GEO, dstDatum, zone);
    let mcUtmCoord = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(utmCoord, false);
    mcUtmCoord.x = mcUtmCoord.x + zone * 1000000;
    let mcGeoCoord = gridConvertor.ConvertAtoB(mcUtmCoord);
    return McCommonUtils.convertMapcoreCoordinateToKnownCoordinate(mcGeoCoord);
  }

  /**
   * convert from geo to bng
   * @param coord
   * @param datum
   * @returns {BngCoordinate|*}
   */
  geoToBng(coord, datum) {
    if (!this.gridBng) {
      this.gridBng = mapcoreCalculations.IMcGridBNG.Create();

    }
    let gridConvertor = this.getGridConverter(coordinateSystemEnum.GEO, datum, coordinateSystemEnum.BNG, datum);
    let mcCoord = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(coord);
    let coordInBng = gridConvertor.ConvertAtoB(mcCoord);
    let fullBngCoord = this.gridBng.CoordToFullBNG(coordInBng);
    return new BngCoordinate(fullBngCoord.Coord.x, fullBngCoord.Coord.y, fullBngCoord.Coord.z, fullBngCoord.Square.cSquareFst,
      fullBngCoord.Square.cSquareSnd);
  }

  /**
   * convert from bng to geo
   * @param bngCoord
   * @param datum
   * @returns {Coordinate}
   */
  bngToGeo(bngCoord, datum) {
    if (!this.gridBng) {
      this.gridBng = mapcoreCalculations.IMcGridBNG.Create();
    }
    let mcCoord = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(bngCoord, false);
    let squre = mapcoreCalculations.IMcGridBNG.SSquare();
    squre.cSquareFst = bngCoord.getSquareFirst();
    squre.cSquareSnd = bngCoord.getSquareSecond();
    let mcBngFullCoord = mapcoreCalculations.IMcGridBNG.SFullBNG();
    mcBngFullCoord.Coord = mcCoord;
    mcBngFullCoord.Square = squre;
    let mcBngCoord = this.gridBng.FullBNGToCoord(mcBngFullCoord);

    let gridConvertor = this.getGridConverter(coordinateSystemEnum.BNG, datums.UNDEFINED, coordinateSystemEnum.GEO, datum);
    let geoCoord = gridConvertor.ConvertAtoB(mcBngCoord);
    return McCommonUtils.convertMapcoreCoordinateToKnownCoordinate(geoCoord);
  }

  /**
   * convert from geo to irish
   * @param coord
   * @param datum
   * @returns {IrishCoordinate|*}
   */
  geoToIrish(coord, datum) {
    if (!this.gridIrish) {
      this.gridIrish = mapcoreCalculations.IMcGridIrish.Create();
    }
    let gridConvertor = this.getGridConverter(coordinateSystemEnum.GEO, datum, coordinateSystemEnum.IRISH_WORLD, datum);
    let mcCoord = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(coord);
    let coordInIrish = gridConvertor.ConvertAtoB(mcCoord);
    let fullIrishCoord = this.gridIrish.CoordToFullIrish(coordInIrish);
    return new IrishCoordinate(fullIrishCoord.Coord.x, fullIrishCoord.Coord.y, fullIrishCoord.Coord.z, fullIrishCoord.cLetter);
  }

  /**
   * convert from irish to geo
   * @param irishCoord
   * @param datum
   * @returns {Coordinate}
   */
  irishToGeo(irishCoord, datum) {
    if (!this.gridIrish) {
      this.gridIrish = mapcoreCalculations.IMcGridIrish.Create();
    }
    let mcCoord = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(irishCoord, false);
    // TODO: remove this code after mapcore will fix
    mapcoreCalculations.IMcGridIrish.SFullIrish = mapcoreCalculations.__IMcGridIrish_SFullIrish;
    let mcIrishFullCoord = new mapcoreCalculations.IMcGridIrish.SFullIrish();
    mcIrishFullCoord.Coord = mcCoord;
    mcIrishFullCoord.cLetter = irishCoord.getLetter();
    let mcIrishCoord = this.gridIrish.FullIrishToCoord(mcIrishFullCoord);

    let gridConvertor = this.getGridConverter(coordinateSystemEnum.IRISH_WORLD, datums.UNDEFINED, coordinateSystemEnum.GEO, datum);
    let geoCoord = gridConvertor.ConvertAtoB(mcIrishCoord);
    return McCommonUtils.convertMapcoreCoordinateToKnownCoordinate(geoCoord);
  }

  /**
   * convert from geo to gars
   * @param coord
   * @param datum
   * @returns {IrishCoordinate|*}
   */
  geoToGars(coord, datum) {
    if (!this.gridGars) {
      this.gridGars = mapcoreCalculations.IMcGridGARS.Create();
    }
    let mcCoord = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(coord);
    let minutes = this.gridGars.CoordToFullGARS(mcCoord);

    return new GarsCoordinate(minutes);
  }

  /**
   * convert from gars to geo
   * @param irishCoord
   * @param datum
   * @returns {Coordinate}
   */
  garsToGeo(gars5minute, datum) {
    if (!this.gridGars) {
      this.gridGars = mapcoreCalculations.IMcGridGARS.Create();
    }
    let mcGeoCoord = this.gridGars.FullGARSToCoord(gars5minute.getMinute());

    // let gridConvertor = this.getGridConverter(coordinateSystemEnum.GARS, datums.UNDEFINED, coordinateSystemEnum.GEO, datum);
    // let geoCoord = gridConvertor.ConvertAtoB(mcGeoCoord);
    return McCommonUtils.convertMapcoreCoordinateToKnownCoordinate(mcGeoCoord);
  }

  /**
   * convert from geo to generic
   * @param geoCoord
   * @param gridEpsg
   * @param srcDatum
   * @returns {Coordinate}
   */
  geoToGeneric(geoCoord, gridEpsg, srcDatum) {
    McCommonUtils.initMapcoreNodeFiles();
    let gridConvertor = this.getGridConverter(coordinateSystemEnum.GEO, srcDatum, gridEpsg, "", "", 0);
    let mcGeoCoord = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(geoCoord);
    let mcGenericCoord = gridConvertor.ConvertAtoB(mcGeoCoord);
    return McCommonUtils.convertMapcoreCoordinateToKnownCoordinate(mcGenericCoord);
  }

  /**
   * convert from generic to geo
   * @param coord
   * @param gridEpsg
   * @param dstDatum
   * @returns {Coordinate}
   */
  genericToGeo(coord, gridEpsg, dstDatum) {
    McCommonUtils.initMapcoreNodeFiles();
    let gridConvertor = this.getGridConverter(gridEpsg, "", coordinateSystemEnum.GEO, dstDatum);
    let mcGenericCoord = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(coord);
    let mcGeoCoord = gridConvertor.ConvertAtoB(mcGenericCoord);
    return McCommonUtils.convertMapcoreCoordinateToKnownCoordinate(mcGeoCoord);
  }

  geoToGridAzimuth(coord, geoAzimuth, datum) {
    try {
      let zone = this.utmZoneFromX(coord.getLongitude());
      let mcCoord = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(coord);
      let geoCaclUtm = this.getGeoCalcUtm(datum, zone);
      return geoCaclUtm.ConvertAzimuthFromGeoToGrid(mcCoord, geoAzimuth, true);
    } catch (exception) {
      logger.error("MapcoreGeographicCalculations-geoToGridAzimuth", exception);
    }
  }

  gridToGeoAzimuth(coord, gridAzimuth, datum) {
    try {
      let zone = this.utmZoneFromX(coord.getLongitude());
      let mcCoord = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(coord);
      let geoCaclUtm = this.getGeoCalcUtm(datum, zone);
      return geoCaclUtm.ConvertAzimuthFromGridToGeo(mcCoord, gridAzimuth, true);
    } catch (exception) {
      logger.error("MapcoreGeographicCalculations-gridToGeoAzimuth", exception);
    }
  }

  utmZoneFromX(x) {

    // isExtended ?
    let zone = (31 + Math.floor(x / 6));
    if (zone >= 60) {
      zone = 60;
    }

    return zone;
  }


  toMapCoreDatum(datum) {
    switch (datum) {
      case datums.WGS84: {
        return mapcoreCalculations.IMcGridCoordinateSystem.EDatumType.EDT_WGS84;
      }
      case datums.OSGB: {
        return mapcoreCalculations.IMcGridCoordinateSystem.EDatumType.EDT_OSGB;

      }
      case datums.ED50: {
        return mapcoreCalculations.IMcGridCoordinateSystem.EDatumType.EDT_ED50_ISRAEL;
      }
      case datums.IRIS: {
        return mapcoreCalculations.IMcGridCoordinateSystem.EDatumType.EDT_IRISH1965;
      }
    }
  }

  getGridConverter(coordinateSystemSrc, datumSrc, coordinateSystemDest, datumDest, zoneSrc = "", zoneDest = "") {
    let keyGridConvertor = this.getKeyOfGridConverter(coordinateSystemSrc, datumSrc, coordinateSystemDest, datumDest, zoneSrc, zoneDest);
    let gridConvertor;
    if (this.gridConvertorMap.has(keyGridConvertor)) {
      gridConvertor = this.gridConvertorMap.get(keyGridConvertor);
    } else {
      let coordSysSrc = this.createMcCoordSys(coordinateSystemSrc, datumSrc, zoneSrc);
      let coordSysDest = this.createMcCoordSys(coordinateSystemDest, datumDest, zoneDest);
      gridConvertor = mapcoreCalculations.IMcGridConverter.Create(coordSysSrc, coordSysDest);
      this.gridConvertorMap.set(keyGridConvertor, gridConvertor);
    }

    return gridConvertor;
  }

  getGeoCalcUtm(datum, zone) {
    let keyGeoCalcUtm = this.getKeyOfGeoCalcUtm(datum, zone);
    let geoCaclUtm;
    if (this.geoCalcUtmMap.has(keyGeoCalcUtm)) {
      geoCaclUtm = this.geoCalcUtmMap.get(keyGeoCalcUtm);
    } else {
      let coordSys = this.createMcCoordSys(coordinateSystemEnum.UTM, datum, zone);
      geoCaclUtm = mapcoreCalculations.IMcGeographicCalculations.Create(coordSys);
      this.geoCalcUtmMap.set(keyGeoCalcUtm, geoCaclUtm);
    }

    return geoCaclUtm;
  }

  createMcCoordSys(coordinateSystem, datum, zone = "") {
    switch (coordinateSystem) {
      case coordinateSystemEnum.GEO: {
        return mapcoreCalculations.IMcGridCoordSystemGeographic.Create(this.toMapCoreDatum(datum));

      }
      case coordinateSystemEnum.MGRS: {
        if (!this.gridMgrs) {
          this.gridMgrs = mapcoreCalculations.IMcGridMGRS.Create();
        }
        return this.gridMgrs;
      }
      case coordinateSystemEnum.UTM: {
        return mapcoreCalculations.IMcGridUTM.Create(zone, this.toMapCoreDatum(datum));
      }
      case coordinateSystemEnum.S42: {
        return mapcoreCalculations.IMcGridS42.Create(zone, this.toMapCoreDatum(datum));
      }
      case coordinateSystemEnum.BNG: {
        if (!this.gridBng) {
          this.gridBng = mapcoreCalculations.IMcGridBNG.Create();
        }
        return this.gridBng;
      }
      case coordinateSystemEnum.IRISH_WORLD: {
        if (!this.gridIrish) {
          this.gridIrish = mapcoreCalculations.IMcGridIrish.Create();
        }
        return this.gridIrish;
      }
      case coordinateSystemEnum.GARS: {
        if (!this.gridGars) {
          this.gridGars = mapcoreCalculations.IMcGridGARS.Create();
        }
        return this.gridGars;
      }
      default: {
        if (coordinateSystem.toLocaleLowerCase().startsWith("epsg")) {
          return mapcoreCalculations.IMcGridGeneric.Create(coordinateSystem.toLocaleLowerCase());
        }
        break;
      }
    }
  }

  getKeyOfGridConverter(coordinateSystemSrc, datumSrc, coordinateSystemDes, datumDest, zoneSrc = "", zoneDest = "") {
    return coordinateSystemSrc + "" + datumSrc + "" + zoneSrc + "|" + coordinateSystemDes + "" + datumDest + "" + zoneDest;
  }

  getKeyOfGeoCalcUtm(datum, zone) {
    return datum + "|" + zone;
  }


}

module.exports = {MapcoreConversionsCalculations};
