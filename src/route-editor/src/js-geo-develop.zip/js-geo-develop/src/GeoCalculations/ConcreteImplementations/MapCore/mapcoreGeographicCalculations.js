//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

const {Vector} = require("../../../Shapes/vector");
const {Coordinate} = require("../../../Types/coordinate");
const {BaseGeometry} = require("../../../Types/baseGeometry");
const {geoKind} = require("../../../Types/geoKind");
const definitions = require("../../../definitions");
const {Logger} = require('@elbit/logger-server');
const logger = Logger.getLogger("MapcoreGeographicCalculations");
const {Point} = require("../../../Shapes/point");
const {Polyline} = require("../../../Shapes/polyline");
const {Polygon} = require("../../../Shapes/polygon");
const {Circle} = require("../../../Shapes/circle");
const {Rectangle} = require("../../../Shapes/rectangle");
const {McCommonUtils} = require("./mcCommonUtils");
const {datums} = require("../../../Types/datums");
const {Constants} = require("../../../constants");
var proj4 = require('../../proj4');
var util = require('util');
var mapcoreCalculations;

class MapcoreGeographicCalculations {


  async init(datumFromEnum, library) {
    return new Promise((resolve, reject) => {
      if (library == null || library == undefined) {
        let path = "./MapCoreFiles/MapCore_Calculations";
        mapcoreCalculations = require(path);
        global.MapCore.SetStartCallbackFunction(function () {
          resolve();
        });
      } else {
        mapcoreCalculations = library;
        resolve();
      }
    }).catch(function (error) {
      logger.error(error);
      return null;
    });
  }


  async postInit(datumFromEnum) {

    function getMapCoreDatum(datumFromEnum) {
      switch (datumFromEnum) {
        case datums.WGS84:
          return mapcoreCalculations.IMcGridCoordinateSystem.EDatumType.EDT_WGS84;
        case datums.ED50:
          return mapcoreCalculations.IMcGridCoordinateSystem.EDatumType.EDT_ED50_MEAN;
        default:
          return null;
      }
    }

    McCommonUtils.initMapcoreLibrary(mapcoreCalculations);
    let mapCoreDatum = getMapCoreDatum(datumFromEnum);
    if (mapCoreDatum == null || mapCoreDatum == undefined) {
      throw ("MapCore instance for geographic calculations not initialized - unsupported datum!");
    }

    this.coordinateSystem = mapcoreCalculations.IMcGridCoordSystemGeographic.Create(mapCoreDatum);
    this.mapcoreGeographicCalculations = mapcoreCalculations.IMcGeographicCalculations.Create(this.coordinateSystem);
    if (this.mapcoreGeographicCalculations == null || this.mapcoreGeographicCalculations == undefined) {
      throw ("MapCore instance for geographic calculations not initialized!");
    }
  }

  /**
   * Get shape and expand its area by provided distance
   * @param shape - shape to expand (typeOf BaseGeometry)
   * @param distance - expand by parameter
   * @return {BaseGeometry} - return expanded shape (Circle-->Circle, Ellipe-->Ellipse, Point-->Circle, Rextangle-->Rectangle, the rest will return polygon)
   */
  expandShape(shape, distance) {
    try {
      let positionType = shape.getPositionType();
      switch (positionType) {
        case (geoKind.Circle.Name):
          shape.radius += distance;
          return shape;
        case (geoKind.Ellipse.Name):
          shape.verticalRadius += distance;
          shape.horizontalRadius += distance;
          return shape;
        case (geoKind.Point.Name):
        case (geoKind.GeoCamera.Name):
          let pointCoordinate = shape.coordinates[0];
          let circle = new Circle();
          circle.radius = distance;
          circle.setCoordinates([]);
          circle.coordinates.push(new Coordinate(pointCoordinate.getLongitude(), pointCoordinate.getLatitude(), pointCoordinate.getAltitude()));
          return circle;
        case (geoKind.Rectangle.Name):
          shape.width += distance;
          shape.height += distance;
          return shape;
        default:
          let polygon = this.getPolygon(shape, NUM_POLYGON_POINTS);
          let mapcoreCoordinates = McCommonUtils.convertKnownCoordinatesToMapcoreCoordinates(polygon.coordinates);
          const mapcoreCoordinatesReversedIfNeed = BaseGeometry.geometricLibrary.isPolygonNeedReverse(mapcoreCoordinates);
          let expandResult = this.mapcoreGeographicCalculations.PolygonExpand(mapcoreCoordinatesReversedIfNeed, distance, 5);
          let polygonResult = new Polygon();
          polygonResult.setCoordinates(McCommonUtils.convertMapcoreCoordinatesToKnownCoordinates(expandResult));
          return polygonResult;
      }
    } catch (exception) {
      logger.error("Error occured in MapcoreGeographicCalculations-expandShape.", exception);
    }
  }

  areaOfGeometry(geometry) {

    function isPolygonClosed(shape) {
      let shapeCoordinates = shape.coordinates;
      if (shapeCoordinates != null && shapeCoordinates.length > 2 && shapeCoordinates[0].getLongitude() == shapeCoordinates[shapeCoordinates.length - 1].getLongitude() ||
        (shapeCoordinates[0].getLatitude() == shapeCoordinates[shapeCoordinates.length - 1].getLatitude())) {
        return true;
      }
      return false;
    }

    let shape = this.getPolygon(geometry, NUM_POLYGON_POINTS);
    if (shape != null && shape.getPositionType() == geoKind.Polygon.Name) {
      let isPolygonManualyClosed = false;
      try {
        //if polygon is not closed - closed it
        if (!isPolygonClosed(shape)) {
          isPolygonManualyClosed = true;
          shape.coordinates.push(shape.coordinates[0].cloneCoordinate(shape.coordinates[0]));
        }
        let mapcoreCoordinates = McCommonUtils.convertKnownCoordinatesToMapcoreCoordinates(shape.coordinates);
        let retVal = {Value: 0};
        let success = this.mapcoreGeographicCalculations.PolygonSphericArea(mapcoreCoordinates, -1, retVal);
        return retVal.Value;
      } finally {
        if (isPolygonManualyClosed) {
          shape.coordinates = shape.coordinates.slice(0, shape.coordinates.length - 1);
        }
      }
    }
    return -1;
  }


  /**
   *  Calculate and return BaseGeometry shape as Polygon\Polyline
   * @param shape - input shape (typeof Types.BaseGeometry)
   * @param numOfPoint - number of points representation
   * @return {BaseGeometry} - return Polygon\Polyline with 'numOfPoint' points.
   */
  getPolygon(shape, numOfPoint) {

    function sectorToPolygon(sector, numOfPoints, context) {

      // convert to Js geo azimuth type
      let fromAngle = McCommonUtils.convertClientAzimuthToMapcoreAzimuth(sector.getCenter(), sector.fromAngle);
      let toAngle = McCommonUtils.convertClientAzimuthToMapcoreAzimuth(sector.getCenter(), sector.toAngle);
      return arcSample(sector.getCenter(), sector.maximumRadius, sector.maximumRadius, 0, fromAngle, toAngle, sector.minimumRadius / sector.maximumRadius, numOfPoints, context);
    }

    function ellipseToPolygon(ellipse, numOfPoints, context) {
      // convert to Js geo azimuth type
      let orientation = McCommonUtils.convertClientAzimuthToMapcoreAzimuth(ellipse.getCenter(), ellipse.orientation);
      return arcSample(ellipse.getCenter(), ellipse.horizontalRadius, ellipse.verticalRadius, orientation, 0, 360, 0, numOfPoints, context);
    }

    function circleToPolygon(circle, numOfPoints, context) {
      return arcSample(circle.getCenter(), circle.radius, circle.radius, 0, 0, 360, 0, numOfPoints, context);
    }

    function rectangleToPolygon(rectangle, num, context) {
      // convert to Js geo azimuth type
      let orientation = McCommonUtils.convertClientAzimuthToMapcoreAzimuth(rectangle.getCenter(), rectangle.orientation);
      let center = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(rectangle.getCenter());
      let leftUp = {};
      let rightUp = {};
      let rightDown = {};
      let leftDown = {};
      context.self.mapcoreGeographicCalculations.CalcRectangleFromCenterAndLengths(center,
        rectangle.height * 2,
        rectangle.width * 2,
        orientation,
        leftUp,
        rightUp,
        rightDown,
        leftDown,
        false);

      let polygon = new Polygon();
      polygon.coordinates = [];
      polygon.coordinates.push(leftUp.Value);
      polygon.coordinates.push(rightUp.Value);
      polygon.coordinates.push(rightDown.Value);
      polygon.coordinates.push(leftDown.Value);

      polygon.coordinates = McCommonUtils.convertMapcoreCoordinatesToKnownCoordinates(polygon.coordinates);
      return polygon;
    }

    function createPolylineFromCoordinates(coordinates) {
      let polyline = new Polyline();
      polyline.setCoordinates([]);
      for (let i = 0; i < coordinates.length; i++) {
        polyline.coordinates.push(coordinates[i].clone());
      }
      return polyline;
    }

    function arcSample(centerPoint, radX, radY, rotationAngel, fromAngle, toAngel, innerRadiusFactor, numOfPoint, context) {

      let mapcoreCalculations = context.mapcoreCalculations;
      let self = context.self;

      let arc = new mapcoreCalculations.IMcGeographicCalculations.SEllipseArc();
      arc.Center = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(centerPoint);
      arc.dRadiusX = radX;
      arc.dRadiusY = radY;
      arc.dRotationAngle = rotationAngel;
      arc.dInnerRadiusFactor = innerRadiusFactor;
      arc.dStartAzimuth = fromAngle;
      arc.dEndAzimuth = toAngel;
      arc.bClockWise = true;
      let coordinatesArray = self.mapcoreGeographicCalculations.ArcSample(arc, numOfPoint);
      let polygon = new Polygon();
      polygon.coordinates = McCommonUtils.convertMapcoreCoordinatesToKnownCoordinates(coordinatesArray);
      return polygon;
    }

    try {
      let context = {mapcoreCalculations: mapcoreCalculations, self: this};

      let positionType = shape.getPositionType();
      switch (positionType) {
        case (geoKind.Sector.Name):
          return sectorToPolygon(shape, numOfPoint, context);
        case (geoKind.Circle.Name):
          return circleToPolygon(shape, numOfPoint, context);
        case (geoKind.Ellipse.Name):
          return ellipseToPolygon(shape, numOfPoint, context);
        case (geoKind.Rectangle.Name):
          return rectangleToPolygon(shape, numOfPoint, context);
        case (geoKind.GeoCamera.Name):
          let point = new Point();
          point.setCoordinates([]);
          point.coordinates.push(shape.coordinates[0].clone());
          return point;
        case (geoKind.Polygon.Name):
        case (geoKind.Polyline.Name):
        case (geoKind.Point.Name):
          return shape;
        case (geoKind.Arc.Name):
          let arcCenterPoint = shape.coordinates[0];
          let firstCoordinate = this.locationFromLocationAndVector(arcCenterPoint, shape.fromAngle, shape.radius);
          let secondCoordinate = this.locationFromLocationAndVector(arcCenterPoint, shape.toAngle, shape.radius);
          let polygon = new Polygon();
          polygon.setCoordinates([]);
          polygon.coordinates.push(firstCoordinate);
          polygon.coordinates.push(arcCenterPoint);
          polygon.coordinates.push(secondCoordinate);
          return polygon;

        case (geoKind.Corridor.Name):
        case (geoKind.Arrow.Name):
          return createPolylineFromCoordinates(shape.coordinates);
        case (geoKind.TwoPoints.Name):
          if (shape.coordinates.length == 2) {
            return createPolylineFromCoordinates(shape.coordinates);
          } else {
            logger.error("Error occurred in MapcoreGeographicCalculations-getPolygon. size of TwoPoints coordinates should equal to 2, input geoCamera size: " + shape.coordinates.length);
          }
      }
    } catch (exception) {
      logger.error("Error occurred in MapcoreGeographicCalculations-getPolygon.", exception);
    }
  }

  /**
   * this method checks if shape2 exists between min and max distance from shape1
   * @param shape1 - the source shape (typeOf Types.BaseGeometry).
   * @param shape2 - the check shape (typeOf Types.BaseGeometry).
   * @param minDistance - minimum distance in meters
   * @param maxDistance - maximum distance in meters
   * @return {boolean} - return true if shape2 is within distance range of shape1, otherwise return false
   */
  isLocationsWithinDistance(shape1, shape2, minDistance, maxDistance) {
    try {
      let coordinate1 = shape1.getCenter();
      let coordinate2 = shape2.getCenter();

      let vector = this.vectorFromTwoLocations(coordinate1, coordinate2);
      if (vector != null && vector != undefined) {
        let distance = vector.getDistance();
        if (distance != null && distance != undefined) {
          distance = Math.abs(distance);
          //if no min distance, set it to 0
          if (minDistance == null || minDistance == undefined) {
            minDistance = 0;
          }

          //if no max distance, set it to 0
          if (maxDistance == null || maxDistance == undefined) {
            maxDistance = 0;
          }


          if (distance >= minDistance && distance <= maxDistance) {
            return true;
          }
          return false;
        } else {
          logger.error("error in MapcoreGeographicCalculations-isLocationsWithinDistance distance is null or undefined.")
        }
      } else {
        logger.error("error in MapcoreGeographicCalculations-isLocationsWithinDistance. vector is null or undefined.")
      }
    } catch (exception) {
      logger.error("Error occured in MapcoreGeographicCalculations-isLocationsWithinDistance", exception);
    }
  }

  /**
   * get 2 coordinates and return the vector between them
   * @param startCoordinate  - first coordinate (typeof Types.Coordinate)
   * @param endCoordinate - second coordinate (typeof Types.Coordinate)
   * @return {Vector} - (typeof Shapes.Vector). if error return null.
   */
  vectorFromTwoLocations(startCoordinate, endCoordinate) {
    try {
      let sourceCoordinate = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(startCoordinate);
      let destinationCoordinate = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(endCoordinate);
      let vectorLengthInMeters = {};
      let vectorAzimuth = {};
      let vectorElevation = {};
      this.mapcoreGeographicCalculations.VectorFromTwoLocations(sourceCoordinate, destinationCoordinate, vectorLengthInMeters, vectorAzimuth, vectorElevation);
      let azimuthClient = McCommonUtils.convertMapcoreAzimuthToClientAzimuth(startCoordinate, vectorAzimuth.Value);
      let vector = new Vector(startCoordinate, endCoordinate, vectorLengthInMeters.Value, azimuthClient, vectorElevation);
      return vector;
    } catch (exception) {
      logger.error("Error occurred in method MapcoreGeographicCalculations-vectorFromTwoLocation.", exception);
    }
    return null;
  }

  /**
   *
   * @param startCoordinate  - start coordinate (typeof Types.Coordinate)
   * @param azimuth - vector azimuth (number)
   * @param distance  vector distance (number)
   * @param elevetion  vector distance (number)
   * @return {Coordinate} - the end coordinate (typeof Types.Coordinate)
   */
  locationFromLocationAndVector(startCoordinate, azimuth, distance, elevetion) {
    try {
      let sourceCoordinate = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(startCoordinate);
      let vectorLengthInMeters = {};
      let vectorAzimuth = {};
      let vectorElevation = {};
      if (elevetion == null || elevetion == undefined) {
        elevetion = 0;
      }
      let azimuthMc = McCommonUtils.convertClientAzimuthToMapcoreAzimuth(startCoordinate, azimuth);
      let mapcoreCoordinate = this.mapcoreGeographicCalculations.LocationFromLocationAndVector(sourceCoordinate, Number(distance), Number(azimuthMc), Number(elevetion));
      if (mapcoreCoordinate != null && mapcoreCoordinate != undefined) {
        return McCommonUtils.convertMapcoreCoordinateToKnownCoordinate(mapcoreCoordinate);
      } else {
        logger.error("error in MapcoreGeographicCalculations-locationFromLocationAndVector. got null or undefined from library");
      }
    } catch (exception) {
      logger.error("MapcoreGeographicCalculations-locationFromLocationAndVector.", exception);
    }
    return null;
  }


  nearestDistanceBetweenGeometries(geometry1, geometry2, relationResult) {
    let intersectionPoints = relationResult.intersectionPoints;
    let vector = this.vectorFromTwoLocations(intersectionPoints[0], intersectionPoints[1]);
    relationResult.nearestDistance = vector.getDistance();
    return relationResult;
  }

  /**
   * Return bounding box (rectangle) of baseGeometry shape
   * @param shape (typeOf BaseGeometry)
   * @return {*} return rectangle as smallest bounding box or null if error
   */
  getSmallestBoundingRect(shape) {
    try {
      let coordinates;
      if (shape && shape.coordinates) {
        let polygon = shape.getShapeFallback();
        if (polygon != null) {
          if (polygon.coordinates != null) {
            coordinates = McCommonUtils.convertKnownCoordinatesToMapcoreCoordinates(polygon.coordinates);

            let dDeltaAngleToCheck = 0, pCenterPoint = {}, pdAzimuth = {}, pdLength = {}, pdWidth = {}, pdArea = {};
            this.mapcoreGeographicCalculations.SmallestBoundingRect(coordinates, dDeltaAngleToCheck, pCenterPoint, pdAzimuth, pdLength, pdWidth, pdArea);

            if (pdLength && pdLength.Value && pdWidth && pdWidth.Value && pCenterPoint && pCenterPoint.Value && pdAzimuth && pdAzimuth.Value) {
              let boundingRect = new Rectangle();
              boundingRect.height = pdLength.Value / 2;
              boundingRect.width = pdWidth.Value / 2;
              boundingRect.orientation = pdAzimuth.Value;
              boundingRect.coordinates = [];
              let center = McCommonUtils.convertMapcoreCoordinateToKnownCoordinate(pCenterPoint.Value);
              boundingRect.coordinates.push(center);
              return boundingRect;
            } else {
              logger.error("trying to get smallest bounding box values from provider while calculating bounding box failed");
            }
          } else {
            logger.error("trying to get shape fallback while calculating bounding box failed, fallback coordinates are null");
          }
        } else {
          logger.error("trying to get shape fallback while calculating bounding box failed, fallback is null");
        }
      } else {
        logger.error("Shape arrived without coordinates, cant calculate bounding box");
      }
    } catch (exception) {
      logger.error("Error occurred in method getSmallestBoundingRect. exception :", exception);
    }
    return null;
  }


  geoToGridAzimuth(coord, geoAzimuth) {
    try {
      let mcCoord = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(coord);
      let geoCaclUtm = mapcoreCalculations.IMcGeographicCalculations.Create(
        mapcoreCalculations.IMcGridUTM.Create(36, mapcoreCalculations.IMcGridCoordinateSystem.EDatumType.EDT_WGS84));
      return geoCaclUtm.ConvertAzimuthFromGeoToGrid(mcCoord, geoAzimuth, true);
    } catch (exception) {
      logger.error("MapcoreGeographicCalculations-geoToGridAzimuth.", exception);
    }
  }

  gridToGeoAzimuth(coord, gridAzimuth) {
    try {
      let mcCoord = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(coord);
      return this.mapcoreGeographicCalculations.ConvertAzimuthFromGridToGeo(mcCoord, gridAzimuth, true);
    } catch (exception) {
      logger.error("MapcoreGeographicCalculations-gridToGeoAzimuth", exception);
    }
  }

  /**
   * init or get mapcoreGeographicCalculations with magnetic
   */
  setMagneticCalculations() {
    if (this.mapcoreGeographicCalculationsMegantic == null || this.mapcoreGeographicCalculationsMegantic == undefined) {
      if (definitions.isNodeEnvironment()) {
        McCommonUtils.initMapcoreNodeFiles();
        this.mapcoreGeographicCalculationsMegantic = mapcoreCalculations.IMcGeographicCalculations.Create(this.coordinateSystem, "FS/MagneticElements/WMM.COF");
      } else {
        // todo: handle browser
      }
    }
  }

  initMagneticBrowser(bytesCof, bytesBin) {
    if (bytesCof != null && bytesBin != null) {
      FS.writeFile("FS/TempMagneticDataFile.COF", bytesCof);
      FS.writeFile("FS/TempMagneticDataFile.bin", bytesBin);
      this.mapcoreGeographicCalculationsMegantic = mapcoreCalculations.IMcGeographicCalculations.Create(this.coordinateSystem, "FS/TempMagneticDataFile.COF");
    }
  }

  /**
   * Get magnetic declination
   * @param coord
   * @param date
   * @returns {*}
   */
  getMagneticDeclination(coord, date) {
    this.setMagneticCalculations();
    if (this.mapcoreGeographicCalculationsMegantic != null || this.mapcoreGeographicCalculationsMegantic != undefined) {
      let mcCoord = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(coord);


      let magneticElements = this.mapcoreGeographicCalculationsMegantic.CalcMagneticElements(mcCoord, date);
      return magneticElements.dDecl;
    }
    return null;
  }

  static conversionsCrs(coord, sourceCrs, destinationCrs) {
    return proj4(sourceCrs, destinationCrs, coord);
  }

  static convertGeoToUtm(coord, sourceDatum, destDatum) {
    return proj4(sourceDatum.geo, util.format(destDatum.utm, 36), coord);
  }

  static convertUtmToGeo(coord, sourceDatum, destDatum) {
    return proj4(util.format(sourceDatum.utm, 36), destDatum.geo, coord);
  }

  /**
   * @azimuthAndDistanceBetweenTwoLocations
   * Use mapcore function version of AzimuthAndDistanceBetweenTwoLocations
   * @param startCoordinate
   * @param endCoordinate
   * @param isUseHeight
   * @returns {null|Vector|*}
   */
  azimuthAndDistanceBetweenTwoLocations(startCoordinate, endCoordinate, isUseHeight) {
    try {
      // Convert to mapcore coordinate
      let sourceCoordinate = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(startCoordinate);
      let destinationCoordinate = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(endCoordinate);
      let vectorLengthInMeters = {};
      let vectorAzimuth = {};
      isUseHeight = (typeof isUseHeight === "boolean") ? isUseHeight : false;

      // fill the objects
      this.mapcoreGeographicCalculations.AzimuthAndDistanceBetweenTwoLocations(sourceCoordinate, destinationCoordinate, vectorAzimuth, vectorLengthInMeters, isUseHeight);
      let azimuthClient = McCommonUtils.convertMapcoreAzimuthToClientAzimuth(startCoordinate, vectorAzimuth.Value);
      let vector = new Vector(startCoordinate, endCoordinate, vectorLengthInMeters.Value, azimuthClient);
      return vector;
    } catch (exception) {
      logger.error("Error occurred in method MapcoreGeographicCalculations-azimuthAndDistanceBetweenTwoLocations.", exception);
    }
    return null;
  }
}


module.exports = {MapcoreGeographicCalculations};
