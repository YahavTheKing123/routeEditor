//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

const {Logger} = require('@elbit/logger-server');
const logger = Logger.getLogger("MapcoreGeometricCalculations");
const {geoKind} = require("../../../Types/geoKind");
const {Polygon} = require("../../../Shapes/polygon");
const {polygonRelationOperations} = require("../../../Types/polygonRelationOperations");
const {PolygonRelationResult} = require("../../../Types/polygonRelationResult");
const {GeoRelationResult} = require("../../../Types/geoRelationResult");
const {McCommonUtils} = require("./mcCommonUtils");
var mapcoreCalculations;

class MapcoreGeometricCalculations {

  constructor(library) {

    if (library == null || library == undefined) {
      let path = "./MapCoreFiles/MapCore_Calculations";
      mapcoreCalculations = require(path);
    } else {
      mapcoreCalculations = library;
    }
    McCommonUtils.initMapcoreLibrary(mapcoreCalculations);

    this.mapcoreGeometricCalculations = mapcoreCalculations.IMcGeometricCalculations;
    this.polygonsRelationStatuses = mapcoreCalculations.PG_PG_STATUS;
    this.polygonToPolygonStatus = mapcoreCalculations.PL_PL_STATUS;
    this.polygonDirection = mapcoreCalculations.PG_DIRECTION;
    this.geometricShape = mapcoreCalculations.GEOMETRIC_SHAPE;
    if (this.mapcoreGeometricCalculations == null || this.mapcoreGeometricCalculations == undefined) {
      throw ("MapCore instance for geometric calculations not initialized!");
    }
    logger.info("isSplineFunctionalityEnabled = " + IS_SPLINE_FUNCTIONALITY_ENABLED);
  }

  nearestDistanceBetweenGeometries(geometry1, geometry2) {
    let retVal;
    if (geometry1.getPositionType() == geoKind.Point.Name) {
      let point = geometry1;
      retVal = this.nearestDistanceBetweenPointToGeometry(point, geometry2);
    } else if (geometry2.getPositionType() == geoKind.Point.Name) {
      let point = geometry2;
      retVal = this.nearestDistanceBetweenPointToGeometry(point, geometry1);
    } else {
      let basicPoly1 = geometry1.getShapeFallback();
      let basicPoly2 = geometry2.getShapeFallback();
      let coord1 = basicPoly1.coordinates;
      let coord2 = basicPoly2.coordinates;
      let isPolygon1 = basicPoly1.getPositionType() == geoKind.Polygon.Name ? true : false;
      let isPolygon2 = basicPoly2.getPositionType() == geoKind.Polygon.Name ? true : false;
      if (geometry1.getPositionType() == geoKind.GeoCamera.Name) {
        coord1 = geometry1.getSightPolygon();
        isPolygon1 = true;
      }
      if (geometry2.getPositionType() == geoKind.GeoCamera.Name) {
        coord2 = geometry2.getSightPolygon();
        isPolygon2 = true;
      }
      retVal = this.polyToPolyNearestPoint(coord1, isPolygon1, coord2, isPolygon2);
    }
    return retVal;
  }

  nearestDistanceBetweenPointToGeometry(point, otherGeometry) {
    let retVal = null;
    let coord = point.getCenter();
    switch (otherGeometry.getPositionType()) {
      case geoKind.Point.Name: {
        let otherPoint = otherGeometry;
        retVal = new GeoRelationResult();
        retVal.intersectionPoints = [];
        retVal.intersectionPoints.push(point.getCenter());
        retVal.intersectionPoints.push(otherGeometry.getCenter());
        retVal.nearestDistance = point.getGeometricDistance(otherGeometry);
        break;
      }
      case geoKind.GeoCamera.Name: {
        let geoCamera = otherGeometry;
        retVal = this.pointToPolyNearestPoint(coord, geoCamera.getSightPolygon(), true);
        break;
      }
      case geoKind.Ellipse.Name:
      case geoKind.Sector.Name:
      case geoKind.Circle.Name:
      case geoKind.Rectangle.Name:
      case geoKind.Corridor.Name:
      case geoKind.Arrow.Name:
      case geoKind.Polygon.Name:
      case geoKind.Polyline.Name: {
        let basicPoly = otherGeometry.getShapeFallback();
        let coordsPoly = basicPoly.coordinates;
        retVal = this.pointToPolyNearestPoint(coord, coordsPoly, basicPoly.getPositionType() == geoKind.Polyline.Name ? false : true);
        break;
      }
      default: {
        break;
      }
    }

    return retVal;
  }


  pointToPolyNearestPoint(point, poly, isPolygon) {
    let geoRelationResult = new GeoRelationResult();
    let pointArr = McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(point);
    let polygonArr = McCommonUtils.convertKnownCoordinatesToMapcoreCoordinates(poly);
    let type;
    if (isPolygon) {
      type = this.geometricShape.EG_POLYGON;
    } else {
      type = this.geometricShape.EG_POLYLINE;
    }
    let pstClosest = {};
    let puSegment = {};
    let pdDistance = {};

    this.mapcoreGeometricCalculations.EGDistancePoint2Poly(pointArr, polygonArr, type, pstClosest, puSegment, pdDistance, 2);

    if (pstClosest && pstClosest.Value && pdDistance && pdDistance.Value) {
      geoRelationResult.intersectionPoints = [];
      geoRelationResult.intersectionPoints.push(point);
      geoRelationResult.intersectionPoints.push(McCommonUtils.convertMapcoreCoordinateToKnownCoordinate(pstClosest.Value));
      geoRelationResult.nearestDistance = pdDistance.Value;
    }
    return geoRelationResult;
  }

  polyToPolyNearestPoint(poly1, isPolygon1, poly2, isPolygon2) {
    let geoRelationResult = new GeoRelationResult();

    let polyArr1 = McCommonUtils.convertKnownCoordinatesToMapcoreCoordinates(poly1);
    let polyArr2 = McCommonUtils.convertKnownCoordinatesToMapcoreCoordinates(poly2);


    let poly1Type;
    if (isPolygon1) {
      poly1Type = this.geometricShape.EG_POLYGON;
    } else {
      poly1Type = this.geometricShape.EG_POLYLINE;
    }
    let poly2Type;
    if (isPolygon2) {
      poly2Type = this.geometricShape.EG_POLYGON;
    } else {
      poly2Type = this.geometricShape.EG_POLYLINE;
    }
    let pstClosest = {};
    let puSegment = {};
    let pdDistance = {};

    this.mapcoreGeometricCalculations.EGDistancePoly2Poly(polyArr1, poly1Type, polyArr2, poly2Type, pstClosest, puSegment, pdDistance, 2);
    if (pstClosest && pstClosest.Value && puSegment && puSegment.Value && pdDistance && pdDistance.Value) {
      let close1 = McCommonUtils.convertMapcoreCoordinateToKnownCoordinate(pstClosest.Value);
      let close2 = McCommonUtils.convertMapcoreCoordinateToKnownCoordinate(puSegment.Value);
      geoRelationResult.intersectionPoints = [];
      geoRelationResult.intersectionPoints.push(close1);
      geoRelationResult.intersectionPoints.push(close2);
      geoRelationResult.nearestDistance = pdDistance.Value;
    }
    return geoRelationResult;
  }


  isPolygonClosed(shape) {
    let shapeCoordinates = shape.coordinates;
    if (shapeCoordinates != null && shapeCoordinates.length > 2 && shapeCoordinates[0].getLongitude() == shapeCoordinates[shapeCoordinates.length - 1].getLongitude() ||
      (shapeCoordinates[0].getLatitude() == shapeCoordinates[shapeCoordinates.length - 1].getLatitude())) {
      return true;
    }
    return false;
  }

  areaOfPolygon(polygon) {
    let isPolygonClosedManually = false;
    try {
      let coordinates = polygon.coordinates;
      //if polygon is not closed - closed it
      if (!this.isPolygonClosed(polygon)) {
        isPolygonClosedManually = true;
        polygon.coordinates.push(polygon.coordinates[0].clone());
      }
      const polyArr = McCommonUtils.convertKnownCoordinatesToMapcoreCoordinates(coordinates);
      const polygonAreaObj = {};
      this.mapcoreGeometricCalculations.EG2DPolyGonArea(polyArr, polygonAreaObj);
      return polygonAreaObj.Value;
    } finally {
      if (isPolygonClosedManually) {
        polygon.coordinates = polygon.coordinates.slice(0, polygon.coordinates.length - 1);
      }
    }
  }


  /**
   *
   * @param shape1 - first polygon (typeOf Shapes.Polygon)
   * @param shape2 - second polygon (typeOf Shapes.Polygon)
   * @param operation - the operation to check on polygons (typeOf Types.polygonRelationOperations)
   * @return {boolean} - return true if 'operation' match, otherwise return false.
   */
  polygonsRelation(shape1, shape2, operation) {

    function isIntersectByStatus(polygonStatus, crossResult, context) {
      if (polygonStatus.Value && polygonStatus.Value.value == context.polygonsRelationStatuses.SEPARATE_PG.value) {
        if (crossResult.Value.value == context.polygonToPolygonStatus.TANGENT_PL.value || crossResult.Value.value == context.polygonToPolygonStatus.TOUCHES_PL.value) {
          return true;
        }
      } else if (polygonStatus.Value && (polygonStatus.Value.value == context.polygonsRelationStatuses.A_IN_B_PG.value || polygonStatus.Value.value == context.polygonsRelationStatuses.B_IN_A_PG.value)) {
        if (crossResult.Value.value == context.polygonToPolygonStatus.TANGENT_PL.value || crossResult.Value.value == context.polygonToPolygonStatus.TOUCHES_PL.value) {
          return true;
        }
      } else if (polygonStatus.Value && polygonStatus.Value.value == context.polygonsRelationStatuses.SAME_PG.value) {
        if (crossResult.Value.value == context.polygonToPolygonStatus.OVERLAP_PL.value || crossResult.Value.value == context.polygonToPolygonStatus.TANGENT_PL.value) {
          return true;
        }
      } else if ((polygonStatus.Value && polygonStatus.Value.value == context.polygonsRelationStatuses.INTERSECT_PG.value) || crossResult.Value.value == context.polygonToPolygonStatus.INTERSECT_PL.value) {
        return true;
      }
      return false;
    }

    function isContainsByStatus(polygonStatus, context) {
      if (polygonStatus && polygonStatus.Value && polygonStatus.Value.value == context.polygonsRelationStatuses.B_IN_A_PG.value) {
        return true;
      }
      return false;
    }

    let polygonRelationResult = new PolygonRelationResult();
    polygonRelationResult.operationResult = false;

    let isPolygon1ClosedManually = false;
    let isPolygon2ClosedManually = false;
    try {
      if (shape1 == null) {
        logger.error("cant calculate polygonsRelation, shape1 is null or undefined");
      }
      if (shape2 == null) {
        logger.error("cant calculate polygonsRelation, shape2 is null or undefined");
      }
      if (operation == null) {
        logger.error("cant calculate polygonsRelation, operation is null or undefined");
      }

      if (shape1.getPositionType() == geoKind.Polygon.Name && !this.isPolygonClosed(shape1)) {
        isPolygon1ClosedManually = true;
        shape1.coordinates.push(shape1.coordinates[0].clone());
      }
      if (shape2.getPositionType() == geoKind.Polygon.Name && !this.isPolygonClosed(shape2)) {
        isPolygon2ClosedManually = true;
        shape2.coordinates.push(shape2.coordinates[0].clone());
      }


      let polygon1MapcoreVector3d = McCommonUtils.convertKnownCoordinatesToMapcoreCoordinates(shape1.coordinates);
      let polygon2MapcoreVector3d = McCommonUtils.convertKnownCoordinatesToMapcoreCoordinates(shape2.coordinates);

      let crossResult = {};
      let polygonStatus = {};


      let result = null;
      if (shape1.getPositionType() == geoKind.Polygon.Name && shape2.getPositionType() == geoKind.Polyline.Name) {
        if (operation == polygonRelationOperations.contain) {
          let isPolygonContainPolyline = true;
          let shape2Coordinates = shape2.coordinates;
          for (let i = 0; i < shape2Coordinates.length; i++) {
            if (!this.isPolygonContainsPoint(shape1, shape2Coordinates[i])) {
              isPolygonContainPolyline = false;
              break;
            }
          }
          polygonRelationResult.operation = operation;
          if (isPolygonContainPolyline) {
            polygonRelationResult.operationResult = true;
          } else {
            polygonRelationResult.operationResult = false;
          }
          return polygonRelationResult;
        } else {
          result = this.mapcoreGeometricCalculations.EGPolyLinesRelation(polygon1MapcoreVector3d, polygon2MapcoreVector3d, crossResult, 3);
        }
      } else if (shape1.getPositionType() == geoKind.Polygon.Name && shape2.getPositionType() == geoKind.Polygon.Name) {
        result = this.mapcoreGeometricCalculations.EG2DPolyGonsRelation(polygon1MapcoreVector3d, polygon2MapcoreVector3d, crossResult, polygonStatus);
      } else if (shape1.getPositionType() == geoKind.Polyline.Name && shape2.getPositionType() == geoKind.Polyline.Name) {
        result = this.mapcoreGeometricCalculations.EGPolyLinesRelation(polygon1MapcoreVector3d, polygon2MapcoreVector3d, crossResult, 3);
      } else if (shape1.getPositionType() == geoKind.Polyline.Name && shape2.getPositionType() == geoKind.Polygon.Name) {
        result = this.mapcoreGeometricCalculations.EGPolyLinesRelation(polygon1MapcoreVector3d, polygon2MapcoreVector3d, crossResult, 3);
      }


      if (result != null) {
        polygonRelationResult.operation = operation;
        switch (operation) {
          case polygonRelationOperations.contain:
            polygonRelationResult.operationResult = isContainsByStatus(polygonStatus, this);
            return polygonRelationResult;
          case polygonRelationOperations.contained:
            break;
          case polygonRelationOperations.intersect:
            polygonRelationResult.operationResult = isIntersectByStatus(polygonStatus, crossResult, this);
            if (result) { //if intersection points exists
              polygonRelationResult.intersectionPoints = McCommonUtils.convertMapcoreCoordinatesToKnownCoordinates(result);
            }
            return polygonRelationResult;
          case polygonRelationOperations.overlap:
            if (isContainsByStatus(polygonStatus, this) || isIntersectByStatus(polygonStatus, crossResult, this)) {
              polygonRelationResult.operationResult = true;
            }
            return polygonRelationResult;
        }
      }
      return false;
    } catch (exception) {
      logger.error("Error occured in MapcoreGeometricCalculations-polygonsRelation.", exception);
      return false;
    }
  }


  isPolygonContainsPoint(shape, coordinate) {
    let result = false;
    let i;
    let j;

    let pointCoordinates = coordinate;
    let polygonCoordinates = shape.coordinates;
    //close the polygon by adding last point as first one
    polygonCoordinates[polygonCoordinates.length] = polygonCoordinates[0];
    for (i = 0, j = polygonCoordinates.length - 2; i < polygonCoordinates.length - 1; j = i++) {
      if ((polygonCoordinates[i].getLatitude() > pointCoordinates.getLatitude()) != (polygonCoordinates[j].getLatitude() > pointCoordinates.getLatitude()) &&
        (pointCoordinates.getLongitude() < (polygonCoordinates[j].getLongitude() - polygonCoordinates[i].getLongitude()) *
          (pointCoordinates.getLatitude() - polygonCoordinates[i].getLatitude()) / (polygonCoordinates[j].getLatitude() - polygonCoordinates[i].getLatitude()) +
          polygonCoordinates[i].getLongitude())) {
        result = !result;
      }
    }
    //remove last point
    polygonCoordinates = polygonCoordinates.slice(0, polygonCoordinates.length - 1);
    return result;
  }

  /**
   * Check if shape1 contains shape2
   * @param shape1 - the first shape (typeOf Types.BaseGeometry)
   * @param shape2 - the second shape (typeOf Types.BaseGeometry)
   * @return {boolean} - return true if shape1 contains shape2, otherwise return false
   */
  isContains(shape1, shape2) {
    shape1 = this.smoothShapeIfSpline(shape1);
    shape2 = this.smoothShapeIfSpline(shape2);
    let polygonRelationResult = new PolygonRelationResult();
    polygonRelationResult.operationResult = false;
    polygonRelationResult.operation = polygonRelationOperations.contain;
    try {
      let shape1Fallback = shape1.getShapeFallback();
      let shape2Fallback = shape2.getShapeFallback();
      if (shape1Fallback == null) {
        logger.error("shape1 fallback coordinates are null or empty");
        return polygonRelationResult;
      }
      if (shape2Fallback == null) {
        logger.error("shape2 fallback coordinates are null or empty");
        return polygonRelationResult;
      }
      if (shape1Fallback.getPositionType() == geoKind.Polygon.Name && shape2Fallback.getPositionType() == geoKind.Point.Name) {
        polygonRelationResult.operationResult = this.isPolygonContainsPoint(shape1Fallback, shape2Fallback.coordinates[0]);
        return polygonRelationResult;
      }
      return this.polygonsRelation(shape1Fallback, shape2Fallback, polygonRelationOperations.contain);
    } catch (exception) {
      logger.error("Error occurred in MapcoreGeometricCalculations-isContains.", exception);
    }
  }

  /**
   * Check if shape1 overlapped with shape2
   * @param shape1 - the first shape (typeOf Types.BaseGeometry)
   * @param shape2 - the second shape (typeOf Types.BaseGeometry)
   * @return {boolean} - return true if shape1 overlapped with shape2, otherwise return false
   */
  isOverlap(shape1, shape2) {
    shape1 = this.smoothShapeIfSpline(shape1);
    shape2 = this.smoothShapeIfSpline(shape2);
    let polygonRelationResult = new PolygonRelationResult();
    polygonRelationResult.operationResult = false;
    polygonRelationResult.operation = polygonRelationOperations.overlap;
    try {
      let containResult = this.isContains(shape1, shape2);
      let intersectResult = this.isIntersects(shape1, shape2);
      if ((containResult.operation == polygonRelationOperations.contain && containResult.operationResult == true)
        ||
        (intersectResult.operation == polygonRelationOperations.intersect && intersectResult.operationResult == true)) {
        polygonRelationResult.operationResult = true;
        return polygonRelationResult;
      }
    } catch (exception) {
      logger.error("Error occurred in MapcoreGeometricCalculations-isOverlap.", exception);
    }
    return polygonRelationResult;
  }

  /**
   * Check if shape1 intersects with shape2
   * @param shape1 - the first shape (typeOf Types.BaseGeometry)
   * @param shape2 - the second shape (typeOf Types.BaseGeometry)
   * @return {boolean} - return true if shape1 intersects with shape2, otherwise return false
   */
  isIntersects(shape1, shape2) {
    shape1 = this.smoothShapeIfSpline(shape1);
    shape2 = this.smoothShapeIfSpline(shape2);
    let polygonRelationResult = new PolygonRelationResult();
    polygonRelationResult.operation = polygonRelationOperations.intersect;
    polygonRelationResult.operationResult = false;
    try {
      let shape1Fallback = shape1.getShapeFallback();
      let shape2Fallback = shape2.getShapeFallback();
      if (shape1Fallback == null) {
        logger.error("shape1 fallback coordinates are null or empty");
        return polygonRelationResult;
      }
      if (shape2Fallback == null) {
        logger.error("shape2 fallback coordinates are null or empty");
        return polygonRelationResult;
      }
      return this.polygonsRelation(shape1Fallback, shape2Fallback, polygonRelationOperations.intersect);
    } catch (exception) {
      logger.error("Error occurred in MapcoreGeometricCalculations-isIntersects. ", exception);
    }
    return polygonRelationResult;
  }

  isPolySelfIntersection(shape, isPolygon) {
    let polyArr = McCommonUtils.convertKnownCoordinatesToMapcoreCoordinates(shape.coordinates);

    let polyType;
    if (isPolygon) {
      polyType = this.geometricShape.EG_POLYGON;
    } else {
      polyType = this.geometricShape.EG_POLYLINE;
    }

    return this.mapcoreGeometricCalculations.EG2DPolySelfIntersection(polyArr, polyType);
  }

  isPolygonNeedReverse(mapCoreCoordinates) {
    let coordsRet = mapCoreCoordinates;
    const currentDirection = this.mapcoreGeometricCalculations.EG2DPolyGonDirection(mapCoreCoordinates, false);
    let currentDirectionValue;
    if (currentDirection !== undefined) {
      currentDirectionValue = currentDirection.value;
      if (currentDirectionValue === this.polygonDirection.COUNTER_CLOCKWISE.value) {
        coordsRet = [...mapCoreCoordinates].reverse();
      }
    }

    return coordsRet;
  }

  smoothShapeIfSpline(shape) {
    if (IS_SPLINE_FUNCTIONALITY_ENABLED) {
      try {
        function polySmoothing(shape, self) {
          try {
            if (shape) {
              if (shape.isSpline == true) {
                if (shape.coordinates) {
                  let polySmoothInputCoordinates = McCommonUtils.convertKnownCoordinatesToMapcoreCoordinates(shape.coordinates);
                  let geometricShape = undefined;
                  let positionType = shape.getPositionType();
                  switch (positionType) {
                    case (geoKind.Polyline.Name):
                    case (geoKind.TwoPoints.Name):
                    case (geoKind.Arrow.Name):
                    case (geoKind.Corridor.Name):
                      geometricShape = mapcoreCalculations.GEOMETRIC_SHAPE.EG_POLYLINE;
                      break;
                    case (geoKind.Polygon.Name):
                    case (geoKind.Rectangle.Name):
                      geometricShape = mapcoreCalculations.GEOMETRIC_SHAPE.EG_POLYGON;
                      break;
                  }
                  if (geometricShape) {
                    let result = self.mapcoreGeometricCalculations.EG2DPolySmoothingSample(polySmoothInputCoordinates, geometricShape, SPLINE_LEVEL);
                    if (result) {
                      return McCommonUtils.convertMapcoreCoordinatesToKnownCoordinates(result)
                    }
                  } else {
                    logger.error("Cant smooth shape (shape type = " + positionType + ")")
                  }
                } else {
                  logger.error("Input shape is null or undefined in polySmoothing method")
                }
              } else {
                logger.error("input does not mark as spline!")
              }
            } else {
              logger.error("Input shape.coordinates is null or undefined in polySmoothing method")
            }
          } catch (exception) {
            logger.error("Error occurred in method polySmoothing. exception:", exception);
          }
        }

        if (shape) {
          if (shape.isSpline == true) {
            let newShape = shape.clone();
            let smoothCoordinates = polySmoothing(newShape, this);
            if (smoothCoordinates && smoothCoordinates.length > 0) {
              logger.debug("polySmoothing done!");
              newShape.setCoordinates(smoothCoordinates);
              return newShape;
            } else {
              logger.error("smoothShape returned without smooth coordinates")
            }
          }
        } else {
          logger.error("Error occurred in method smoothShape. input is null or undefined!");
        }
      } catch (exception) {
        logger.error("Exception occurred in method smoothShape. exception:", exception);
      }
    }
    return shape;
  }
}

module.exports = {MapcoreGeometricCalculations};
