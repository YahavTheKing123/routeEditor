//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

const {Coordinate} = require("../../../Types/coordinate");
const azimuthTypes = require("../../../Types/azimuthTypes");
const definitions = require("../../../definitions");
const {CoordSysConvertor} = require("../../../Convertors/coordSysConvertor");
/**
 * Created by tc98835 on 08/02/18.
 */
const MC_FACTOR = 100000;
const MC_AZIMUTH_TYPE = azimuthTypes.GEO;
var loadNodeFiles = false;

class McCommonUtils {


  static initMapcoreLibrary(lib) {
    McCommonUtils.mapcoreCalculations = lib;
  }

  /**
   * Init mapcore nodejs files
   */
  static initMapcoreNodeFiles() {
    if (definitions.isNodeEnvironment()) {
      if (loadNodeFiles === false) {
        const path = require('path');
        McCommonUtils.mapcoreCalculations.IMcMapDevice.MapNodeJsDirectory(path.resolve(__dirname, "MapCoreFiles/NodeJsFiles"), "FS");
        loadNodeFiles = true;
      }
    }
  }

  static convertKnownCoordinatesToMapcoreCoordinates(coordinateList) {
    let retVal = [];

    let idx = 0;
    for (let i = 0; i < coordinateList.length; i++) {
      retVal.push(McCommonUtils.convertKnownCoordinateToMapcoreCoordinate(coordinateList[i]));
    }
    return retVal;
  }

  static convertKnownCoordinateToMapcoreCoordinate(coordinate, multMcFactor = true) {
    let retVal = new McCommonUtils.mapcoreCalculations.SMcVector3D();
    let factor = multMcFactor ? MC_FACTOR : 1;
    retVal.x = coordinate.getLongitude() * factor;
    retVal.y = coordinate.getLatitude() * factor;
    retVal.z = coordinate.getAltitude();
    if (retVal.z == null || retVal.z == undefined || isNaN(retVal.z)) {
      retVal.z = 0;
    }
    return retVal;
  }


  static convertMapcoreCoordinatesToKnownCoordinates(coordinateArray) {
    let retVal = [];
    for (let i = 0; i < coordinateArray.length; i++) {
      let coordinate = McCommonUtils.convertMapcoreCoordinateToKnownCoordinate(coordinateArray[i]);
      retVal.push(coordinate);
    }
    return retVal;
  }

  static convertMapcoreCoordinateToKnownCoordinate(coordiante, divideMcFactor = true) {
    let x = coordiante.x;
    let y = coordiante.y;
    let z = coordiante.z;
    if (z == 0) {
      z = undefined;
    }
    let coordinate;
    if (divideMcFactor == true) {
      coordinate = new Coordinate(x / MC_FACTOR, y / MC_FACTOR, z);
    } else {
      coordinate = new Coordinate(x, y, z);
    }
    return coordinate;
  }

  static convertClientAzimuthToMapcoreAzimuth(coordinate, azimuth, datum = GEOGRAPHIC_LIBRARY_DATUM) {
    let retVal = azimuth;
    if (MC_AZIMUTH_TYPE != definitions.azimuthClient) {
      retVal = CoordSysConvertor.convertGridToGeoAzimuth(coordinate, azimuth, datum);
    }
    return retVal;
  }

  static convertMapcoreAzimuthToClientAzimuth(coordinate, azimuth, datum = GEOGRAPHIC_LIBRARY_DATUM) {
    let retVal = azimuth;
    if (MC_AZIMUTH_TYPE != definitions.azimuthClient) {
      retVal = CoordSysConvertor.convertGeoToGridAzimuth(coordinate, azimuth, datum);
    }
    return retVal;
  }
}


module.exports = {McCommonUtils};
