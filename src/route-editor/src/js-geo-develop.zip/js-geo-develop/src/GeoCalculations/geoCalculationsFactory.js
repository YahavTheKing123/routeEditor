//Copyright © 201geographic\geometric6-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

const {geographicLibrary} =require("../Types/geographicLibrary");
const {geometricLibrary} =require("../Types/geometricLibrary");
const {coordSysConvertorLibrary} =require("../Types/coordSysConvertorLibrary");
const {MapcoreGeographicCalculations} =require("./ConcreteImplementations/MapCore/mapcoreGeographicCalculations");
const {MapcoreGeometricCalculations} =require("./ConcreteImplementations/MapCore/mapcoreGeometricCalculations");
const {MapcoreConversionsCalculations} =require("./ConcreteImplementations/MapCore/mapcoreConversionsCalculations");
const Constant =require("../constants");


class GeoCalculationsFactory {

   static async getGeographicCalculations(datumName, library) {
     if (GEOGRAPHIC_LIBRARY == geographicLibrary.mapCore) {
       let lib = new MapcoreGeographicCalculations();
       await lib.init(datumName, library);
       await lib.postInit(datumName);
       return lib;
     }
   }

  static getGeometricCalculations(library) {
    if (GEOMETRIC_LIBRARY == geometricLibrary.mapCore) {
      return new MapcoreGeometricCalculations(library);
    }
    return null;
  }

  static getCoordinateSysConvertor(library) {
    if (COORD_SYS_CONVERTOR_LIBRARY == coordSysConvertorLibrary.mapCore) {
      return new MapcoreConversionsCalculations(library);
    }
    return null;
  }
}
module.exports = {GeoCalculationsFactory};
