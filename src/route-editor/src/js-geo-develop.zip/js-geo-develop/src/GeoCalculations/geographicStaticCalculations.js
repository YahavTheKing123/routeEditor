//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 28/01/2018.
 */
var proj4 = require('./proj4');
var util = require('util');
const {Coordinate} = require('../Types/coordinate');
const {returnTypeEnum} = require("../Types/returnTypeEnum");

var datums = {
  "WGS84": {
    "utm": "+proj=utm +zone=%d +ellps=WGS84 +datum=WGS84 +units=m +no_defs",
    "geo": "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"
  },
  "ED50": {
    "utm": "+proj=longlat +ellps=intl +towgs84=-125,-120,-153,0,0,0,0 +no_defs",
    "geo": "+proj=utm +zone=36 +ellps=intl +towgs84=-125,-120,-153,0,0,0,0 +no_defs"
  }
};


class GeographicStaticCalculations {

  static init() {
    if (!GeographicStaticCalculations.BaseGeometry) {
      GeographicStaticCalculations.BaseGeometry = require("../Types/baseGeometry").BaseGeometry;
      const {Logger} = require('@elbit/logger-server');
      GeographicStaticCalculations.logger = Logger.getLogger("GeographicStaticCalculations");
      GeographicStaticCalculations.geometricStaticCalculations = require("../GeoCalculations/geometricStaticCalculations").GeometricStaticCalculations;
    }
  }


  static conversionsCrs(coord, sourceCrs, destinationCrs) {
    return proj4(sourceCrs, destinationCrs, coord);
  }

  static convertGeoToUtm(coord, sourceDatum, destDatum) {
    return proj4(sourceDatum.geo, util.format(destDatum.utm, 36), coord);
  }

  static convertUtmToGeo(coord, sourceDatum, destDatum) {
    return proj4(util.format(sourceDatum.utm, 36), destDatum.geo, coord);
  }

  /**
   * this method gets 2 coordinates (typeof 'Coordinate') and return vector between them.
   *
   * @param startCoord - first coordinate
   * @param endCoord - second coordinate
   * @return - vector (encapsulate azimuth && distance)
   */
  static vectorFromTwoLocations(startCoordinate, endCoordinate) {
    return GeographicStaticCalculations.BaseGeometry.geographicLibrary.vectorFromTwoLocations(startCoordinate, endCoordinate);
  }

  /**
   *
   * @param shape1 - first shape
   * @param shape2 - second shape
   * @param minDistance - distance from
   * @param maxDistance - distance to
   * @return {boolean} - return true if shape2 is within min distance and max distance from shape1
   */
  static isLocationsWithinDistance(shape1, shape2, minDistance, maxDistance) {
    return GeographicStaticCalculations.BaseGeometry.geographicLibrary.isLocationsWithinDistance(shape1, shape2, minDistance, maxDistance);
  }


  /**
   * Calculate vector's second point from first point, distance and azimuth
   *
   * @param startCoordinate - the starting coordinate (as typeof Coordinate)
   * @param azimuth - azimuth as double
   * @param distance - distance as double
   * @return calculated coordinate (typeof Coordinate)
   */
  static locationFromLocationAndVector(startCoordinate, azimuth, distance, elevetion) {
    return GeographicStaticCalculations.BaseGeometry.geographicLibrary.locationFromLocationAndVector(startCoordinate, azimuth, distance, elevetion);
  }

  /**
   * Get the smallest distance between two geometries
   *
   * @param geometry1
   * @param geometry2
   * @return smallest distance
   */
  static nearestDistanceBetweenGeometries(geometry1, geometry2) {
    try {
      let geoRelationResult = GeographicStaticCalculations.geometricStaticCalculations.nearestDistanceBetweenGeometries(geometry1, geometry2);
      return GeographicStaticCalculations.BaseGeometry.geographicLibrary.nearestDistanceBetweenGeometries(geometry1, geometry2, geoRelationResult);
    } catch (exception) {
      GeographicStaticCalculations.logger.error("Error occurred in method: nearestDistanceBetweenGeometries", exception);
    }
    return null;
  }


  /**
   * Calculate geographic area of shape (type of BaseGeometry)
   * @param geometry - shape to calculate area
   * @return - the area as double, if error occurred - Double.minValue will be return
   */
  static areaOfGeometry(geometry) {
    try {
      return GeographicStaticCalculations.BaseGeometry.geographicLibrary.areaOfGeometry(geometry);
    } catch (exception) {
      GeographicStaticCalculations.logger.error("Error occurred in method: areaOfGeometry", exception);
    }
    return -1;
  }

  /**
   * Expand a shape by input distance
   * @param distance - size of expansion
   * @return {BaseGeometry} - return new expanded shape as (BaseGeometry type)
   */
  static expandShape(shape, distance) {
    return GeographicStaticCalculations.BaseGeometry.geographicLibrary.expandShape(shape, distance);
  }

  /**
   * convert geo to grid azimuth
   * @param coord
   * @param geoAzimuth
   * @returns {*}
   */
  static convertGeoToGridAzimuth(coord, geoAzimuth) {
    return GeographicStaticCalculations.BaseGeometry.geographicLibrary.geoToGridAzimuth(coord, geoAzimuth)
  }


  /**
   * convert grid to geo azimuth
   * @param coord
   * @param gridAzimuth
   * @returns {*}
   */
  static convertGridToGeoAzimuth(coord, gridAzimuth) {
    return GeographicStaticCalculations.BaseGeometry.geographicLibrary.gridToGeoAzimuth(coord, gridAzimuth)
  }


  /**
   * Convert shape to polygon,polyline or point
   * @param geometry - geometry to change
   * @return new object with type Polyline\Polygon or point.
   */
  static toBasicGeometry(geometry) {
    return GeographicStaticCalculations.BaseGeometry.geographicLibrary.toBasicGeometry(geometry, Constants.NUM_POLYGON_POINTS);
  }


  /**
   * Convert shape to polygon,polyline or point
   * @param geometry - geometry to change
   * @param numOfPoint - number of points in new shape
   * @return BaseGeometry object with type Polyline\Polygon or point.
   */
  static toBasicGeometry(geometry, numOfPoint) {
    try {
      return GeographicStaticCalculations.BaseGeometry.geographicLibrary.getPolygon(geometry, numOfPoint);
    } catch (exception) {
      GeographicStaticCalculations.logger.error("Error occurred in method: toBasicGeometry", exception);
    }
    return null;
  }

  /**
   * Return bounding box (rectangle) of baseGeometry shape
   * @param geometry (typeOf BaseGeometry)
   * @return {*} return rectangle as smallest bounding box or null if error
   */
  static getSmallestBoundingRect(geometry) {
    try {
      return GeographicStaticCalculations.BaseGeometry.geographicLibrary.getSmallestBoundingRect(geometry);
    } catch (exception) {
      GeographicStaticCalculations.logger.error("Error occurred in method: getSmallestBoundingRect", exception);
    }
    return null;
  }

  static getMagneticDeclination(coordinate,date = new Date(Date.now())) {
    return GeographicStaticCalculations.BaseGeometry.geographicLibrary.getMagneticDeclination(coordinate, date);
  }

  static initMagneticBrowser(bytesCof, bytesBin) {
    return GeographicStaticCalculations.BaseGeometry.geographicLibrary.initMagneticBrowser(bytesCof, bytesBin);
  }

  /**
   * @azimuthAndDistanceBetweenTwoLocations
   * @param startCoordinate
   * @param endCoordinate
   * @param isUseHeight
   * @returns {-|vector|Vector}
   */
  static azimuthAndDistanceBetweenTwoLocations(startCoordinate, endCoordinate, isUseHeight) {
    return GeographicStaticCalculations.BaseGeometry.geographicLibrary.azimuthAndDistanceBetweenTwoLocations(startCoordinate, endCoordinate, isUseHeight);
  }

  /**
   * @vectorInformationFromTwoLocations
   * The function calculates "vector" between two given location and return object with the vector's
   * parameters.
   * The way the function calculates the parameters depends on whether we want consider the ellipsoid
   * (consideringEllipsoid == true) or not (consideringEllipsoid == false).
   *
   * @Note: In case that consideringEllipsoid isn't a boolean type, by default the function won't
   *        consider the ellipsoid.
   *
   * @Error: in case that one of the coordinates (`startCoord` or `endCoord`) does not have the typical
   *         coordinate structure ({altitude: valueX, latitude: valueY, longitude: valueZ}), the function
   *         will return Null.
   *
   * @param startCoord
   * @param endCoord
   * @param consideringEllipsoid
   * @param isUseHeight - option for azimutAndDistanceBetweeenTwoLocations
   * @returns {-|vector|Vector}
   */
  static vectorInformationFromTwoLocations(startCoord, endCoord, consideringEllipsoid, isUseHeight) {
    let vector;
    let useEllipsoid = (typeof consideringEllipsoid === "boolean") ? consideringEllipsoid : false;
    if (useEllipsoid) {
      vector = this.azimuthAndDistanceBetweenTwoLocations(startCoord, endCoord, isUseHeight);
    } else {
      vector = this.vectorFromTwoLocations(startCoord, endCoord);
    }
    return vector;
  }


  /**
   * This method used as an entry point for external tester
   * @param params - needed params in order to run the method
   * @param serializer - geoSerializer
   * @returns JSON represents the result
   */
  static runGeographicApi(params,serializer) {
    let vector;
    let position;
    let distance;
    let shape;
    let functionToRun;
    let returnAs;
    switch (params.methodName) {
      case "VectorFromTwoLocations":
        let startCoord = new Coordinate(params.startLongitude, params.startLatitude, params.startAltitude);
        let endCoord = new Coordinate(params.endLongitude, params.endLatitude, params.endAltitude);
        return this.vectorFromTwoLocations(startCoord, endCoord);
      case "LocationFromLocationAndVector":
        let coordinate = new Coordinate(params.longitude, params.latitude, params.altitude);
        let azimuth = params.azimuth;
        distance = params.distance;
        let elevetion = params.elevetion;
        return this.locationFromLocationAndVector(coordinate, azimuth, distance, elevetion);
      case "AreaOfGeometry":
        position = params.positionAsBase64;
        shape = serializer.getPosition(position);
        let result = this.areaOfGeometry(shape);
        return {area: result};
      case "ExpandShape":
        position = params.positionAsBase64;
        distance = params.distance;
        shape = serializer.getPosition(position);
        return this.expandShape(shape, distance);
      case "GetSetPosition":
        position = params.position;
        functionToRun = params.functionToRun;
        returnAs = params.returnAs;

        if (returnAs == "BaseGeometry") {
          returnAs = returnTypeEnum.customGeoObject;
        } else if (returnAs == "GeoJson") {
          returnAs = returnTypeEnum.geoJson;
        } else if (returnAs == "GeoJson++") {
          returnAs = returnTypeEnum.geoJsonPlusPlus;
        } else if (returnAs == "GeoJson++Only") {
          returnAs = returnTypeEnum.geoJsonPlusPlusOnly;
        }
        if (functionToRun == "set") {
          return {base64Position: serializer.setPosition(position)};
        } else if (functionToRun == "get") {
          return serializer.getPosition(position,returnAs);
        }
      default:
        return "Method not found";
    }
  }
}

module.exports = {GeographicStaticCalculations, datums};
