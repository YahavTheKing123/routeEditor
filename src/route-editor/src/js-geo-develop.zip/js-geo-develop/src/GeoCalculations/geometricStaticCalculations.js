//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

class GeometricStaticCalculations {

  static init() {
    if (!GeometricStaticCalculations.BaseGeometry) {
      GeometricStaticCalculations.BaseGeometry = require("../Types/baseGeometry").BaseGeometry;
      GeometricStaticCalculations.Coordinate = require("../Types/coordinate").Coordinate;
      const {Logger} = require('@elbit/logger-server');
      GeometricStaticCalculations.logger = Logger.getLogger("GeometricStaticCalculations");
      GeometricStaticCalculations.Vector = require("../Shapes/vector").Vector;
      GeometricStaticCalculations.polygonRelationOperations = require("../Types/polygonRelationOperations").polygonRelationOperations;
    }
  }

  /**
   * Get the vector that connecting two coordinates
   * @param startCoord - first coordinate
   * @param endCoord - second coordinate
   * @return vector that representing the connection between 2 coordinates (contain distance and azimuth)
   */
  static vectorFromTwoLocations(startCoord, endCoord) {
    try {
      let startCoordinateConverted = new GeometricStaticCalculations.Coordinate(startCoord.getLongitude() * 100000, startCoord.getLatitude() * 100000);
      let endCoordinateConverted = new GeometricStaticCalculations.Coordinate(endCoord.getLongitude() * 100000, endCoord.getLatitude() * 100000);

      let distance = Math.hypot(startCoordinateConverted.getLongitude() - endCoordinateConverted.getLongitude()
        , startCoordinateConverted.getLatitude() - endCoordinateConverted.getLatitude());
      let angle = (Math.atan2(endCoordinateConverted.getLongitude() - startCoordinateConverted.getLongitude(), endCoordinateConverted.getLatitude() - startCoordinateConverted.getLatitude()))
        * 180.0 / 3.141592653589793; //to degrees
      if (angle < 0) {
        angle += 360;
      }
      return new GeometricStaticCalculations.Vector(startCoord, endCoord, distance, angle);
    } catch (exception) {
      GeometricStaticCalculations.logger.error("Error occurred in method: vectorFromTwoLocations.", exception);
    }
    return null;
  }

  /**
   * Return end coordinate that resulted by calculating startCoordinate + distance + azimuth
   * @param startCoord - the start coordinate of the vector
   * @param azimuth - the vector's azimuth
   * @param distance - the distance between startCorrdinate to result coordinate
   * @return new coordinate
   */
  static locationFromLocationAndVector(startCoord, azimuth, distance) {
    try {
      let vector = new GeometricStaticCalculations.Coordinate(startCoord.getLongitude() * 100000, startCoord.getLatitude() * 100000);
      let checkedAzimuth = azimuth - 90;
      let rotateVector = this.rotate(new GeometricStaticCalculations.Coordinate(distance, 0), checkedAzimuth);
      vector = this.plus(vector, rotateVector);
      return new GeometricStaticCalculations.Coordinate(vector.getLongitude() / 100000, vector.getLatitude() / 100000, 0);
    } catch (exception) {
      GeometricStaticCalculations.logger.error("Error occurred in method: locationFromLocationAndVector.", exception);
    }
    return null;
  }


  static plus(from, v) {
    return new GeometricStaticCalculations.Coordinate(from.getLongitude() + v.getLongitude(), from.getLatitude() + v.getLatitude());
  }

  static rotate(vectorToRotate, theta) {
    let cot = Math.cos(theta);
    let sit = Math.sin(theta);
    return new GeometricStaticCalculations.Coordinate(vectorToRotate.getLongitude() * cot - vectorToRotate.getLatitude() * sit, vectorToRotate.getLongitude() * sit + vectorToRotate.getLatitude() * cot);
  }

  /**
   * Check if shape1 contained in shape2
   * @param shape1 -shape 1
   * @param shape2 -shape 2
   * @return boolean if shape1 contained in shape2, otherwise return false
   */
  static isContained(shape1, shape2) {
    try {
      let result = GeometricStaticCalculations.BaseGeometry.geometricLibrary.isContains(shape2, shape1);
      if (result.operation == GeometricStaticCalculations.polygonRelationOperations.contained && result.operationResult == true) {
        return true;
      }
    } catch (exception) {
      GeometricStaticCalculations.logger.error("Error occurred in method: IsContained.", exception);
    }
    return false;
  }

  /**
   * Check if shape1 contains shape2
   * @param shape1 -shape 1
   * @param shape2 -shape 2
   * @return boolean true if shape1 contains shape2, otherwise return false
   */
  static isContains(shape1, shape2) {
    try {
      let result = GeometricStaticCalculations.BaseGeometry.geometricLibrary.isContains(shape1, shape2);
      if (result.operation == GeometricStaticCalculations.polygonRelationOperations.contain && result.operationResult == true) {
        return true;
      }
    } catch (exception) {
      GeometricStaticCalculations.logger.error("Error occurred in method: IsContains.", exception);
    }
    return false;
  }

  /**
   * Check if shape1 intersects with shape2
   * @param shape1 -shape 1
   * @param shape2 -shape 2
   * @return Array array of intersection points if shape1 intersects with shape2, otherwise return null
   */
  static isIntersects(shape1, shape2) {
    try {
      let result = GeometricStaticCalculations.BaseGeometry.geometricLibrary.isIntersects(shape1, shape2);
      if (result.operation == GeometricStaticCalculations.polygonRelationOperations.intersect && result.operationResult == true) {
        if (result.intersectionPoints != null && result.intersectionPoints.length > 0) {
          return result.intersectionPoints;
        } else {
          GeometricStaticCalculations.logger.error("Error occurred in method: isIntersects. IsIntersect is true but without intersection points");
        }
      }
    } catch (exception) {
      GeometricStaticCalculations.logger.error("Error occurred in method: isIntersects.", exception);
    }
    return null;
  }

  /**
   * Check if shape1 overlap with shape2
   * @param shape1 -shape 1
   * @param shape2 -shape 2
   * @return boolean true if shape1 overlap with shape2, otherwise return false
   */
  static isOverlap(shape1, shape2) {
    try {
      let result = GeometricStaticCalculations.BaseGeometry.geometricLibrary.isOverlap(shape1, shape2);
      if (result.operation == GeometricStaticCalculations.polygonRelationOperations.overlap && result.operationResult == true) {
        return true;
      }
    } catch (exception) {
      GeometricStaticCalculations.logger.error("Error occurred in method: isOverlap.", exception);
    }
    return false;
  }

  /**
   * Calculate geometric area of shape (type of BaseGeometry)
   * @param polygon - shape to calculate area
   * @return - the area as double, if error occurred - Double.minValue will be return
   */
  static areaOfPolygon(polygon) {
    try {
      return GeometricStaticCalculations.BaseGeometry.geometricLibrary.areaOfPolygon(polygon);
    } catch (exception) {
      GeometricStaticCalculations.logger.error("Error occurred in method: areaOfPolygon.", exception);
    }
    return null;
  }


  /**
   * Get the smallest distance between two geometries
   *
   * @param geometry1
   * @param geometry2
   * @return smallest distance
   */
  static nearestDistanceBetweenGeometries(geometry1, geometry2) {
    try {
      return GeometricStaticCalculations.BaseGeometry.geometricLibrary.nearestDistanceBetweenGeometries(geometry1, geometry2);
    } catch (exception) {
      GeometricStaticCalculations.logger.error("Error occurred in method: nearestDistanceBetweenGeometries.", exception);
    }
    return null;
  }

  static isPolySelfIntersection(shape, isPolygon) {
    try {
      return GeometricStaticCalculations.BaseGeometry.geometricLibrary.isPolySelfIntersection(shape, isPolygon);
    } catch (exception) {
      GeometricStaticCalculations.logger.error("Error occurred in method: isPolySelfIntersection.", exception);
    }
    return null;
  }

  static smoothShapeIfSpline(shape) {
    try {
      return GeometricStaticCalculations.BaseGeometry.geometricLibrary.smoothShapeIfSpline(shape)
    } catch (exception) {
      GeometricStaticCalculations.logger.error("Error occurred in method: smoothShapeIfSpline.", exception);
    }
  }

}

module.exports = {GeometricStaticCalculations};
