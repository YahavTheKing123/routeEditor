//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * @file This file loads 'proj4' library for usage in nodejs environments (CommonJS). proj4's module.exports point to
 * the function itself in pkg.main. This is different however for browser based environments, probably due to a bug in
 * proj4. An alternative [file]{@link ./proj4.shim.js} is presented for browser bundlers to solve this issue.
 * @author Mati O
 */

module.exports = require('proj4');
