//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * @file This file loads 'proj4' library for usage in browser environments (ESM). If a require is made to proj4 in a
 * browser environment, it will return an module object with a 'default' export that points to the function, instead
 * of the function itself like in CommonJS envs. In the past, a technique called interop-default was suggested to
 * replace 'default' with the actual export itself, but nowadays it is less supported and incorrect. Therefore this
 * file will simply return the default field of the module.exports.
 *
 * To decide which file is loaded in which environment 'package.json' contains a 'browser' field to override it.
 * @author Mati O
 */

module.exports = require('proj4').default;
