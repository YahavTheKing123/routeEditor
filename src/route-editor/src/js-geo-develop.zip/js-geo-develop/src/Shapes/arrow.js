//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 30/10/2017.
 */
const {BaseGeometry} = require("../Types/baseGeometry.js");
const {Coordinate} = require("../Types/coordinate");
const {tileCalcKind} = require("../Types/tileCalcKind");
const {geoKind} = require("../Types/geoKind");
const {IntToBytes} = require("../Convertors/intToBytes");
const { Logger } = require ('@elbit/logger-server');
const logger = Logger.getLogger("Arrow");


class Arrow extends BaseGeometry {

  constructor() {
    super();
    this.gap = -1;
    this.headSize = -1;
    this.headAngle = -1;
    this.type=geoKind.Arrow.Name;
    logger.trace("custom geo object ('" + this.getPositionType() + "') created");
  }

  getPositionType()
  {
    return geoKind.Arrow.Name;
  }

  getCenter () {
    return this.getLineBasedCenter();
  }

  static createShape() {
    return new Arrow();
  }


  isEquals(position2) {
    if (position2.getPositionType() == geoKind.Arrow.Name) {
      let result = this.isCoordinatesEquals(position2);
      if (!result) {
        return false;
      }
      return (result &&
        (Math.abs(this.gap - (position2).gap) <= ALTITUDE_DISTANCE_DEVIATION) &&
        (Math.abs(this.headSize - (position2).headSize) <= ALTITUDE_DISTANCE_DEVIATION) &&
        (Math.abs(this.headAngle - (position2).headAngle) <= ALTITUDE_DISTANCE_DEVIATION));
    }
    logger.error("position2 should be with type: " + this.getPositionType());
    return false;
  }


  /**
   *  @deprecated Please use clone() instead
   */
  clone(oldShape) {
    let clonedShape = new Arrow();
    clonedShape = super.cloneCoordinates(oldShape, clonedShape);
    clonedShape.gap = oldShape.gap;
    clonedShape.headSize = oldShape.headSize;
    clonedShape.headAngle = oldShape.headAngle;
    return clonedShape;
  }

  clone() {
    let clonedShape = new Arrow();
    super.copyBaseProperties(clonedShape)
    clonedShape = super.cloneCoordinates(this, clonedShape);
    clonedShape.gap = this.gap;
    clonedShape.headSize = this.headSize;
    clonedShape.headAngle = this.headAngle;
    return clonedShape;
  }

  initFromGeoJson(geoJson) {
    try {
      if (this.isGeoJson(geoJson)) {
        logger.error("GEO JSON NOT IMPLEMENTED");
      } else if (this.isGeoJsonPlusPlus(geoJson)) {
        this.createFromJsonPlusPlus(geoJson);
      } else if (this.isGeoJsonPlusPlusOnly(geoJson)) {
        this.createFromJsonPlusPlus(geoJson);
      }
    }
    catch (exception) {
      logger.error("Error occurred in initFromGeoJson method in Arrow class.", exception);
    }
  }

  createFromJsonPlusPlus(geoJson)
  {
    this.setCoordinates([]);
    this.initCoordinatesFromGeoJsonCoordinates(geoJson.coordinates);
    if (geoJson.gap != null && geoJson.gap != undefined) {
      this.gap = geoJson.gap;
    }
    if (geoJson.headSize != null && geoJson.headSize != undefined) {
      this.headSize = geoJson.headSize;
    }
    if (geoJson.headAngle != null && geoJson.headAngle != undefined) {
      this.headAngle = geoJson.headAngle;
    }
  }


  fromBytes(bufferToRead, idxToStart) {
    try {
      let nextIndex = {value: idxToStart};
      let arrowPtArr = super.readGeoFromBuffer(bufferToRead, nextIndex, 0, true);
      this.coordinates = [];
      for (let i = 0; i < arrowPtArr.length; i++) {
        let coordinate = new Coordinate();
        this.coordinates.push(coordinate);
        coordinate.setLongitude(arrowPtArr[i].getLongitude() / FACTOR);
        coordinate.setLatitude(arrowPtArr[i].getLatitude() / FACTOR);
        if (arrowPtArr[i].getAltitude()) {
          coordinate.setAltitude(arrowPtArr[i].getAltitude() / ALTITUDE_FACTOR);
        }
      }
      this.gap = IntToBytes.fromBytes(bufferToRead, nextIndex);
      this.headSize = IntToBytes.fromBytes(bufferToRead, nextIndex);
      this.headAngle = IntToBytes.fromBytes(bufferToRead, nextIndex) / ORIENTATION_FACTOR;
      //read baseGeometry footers
      this.readFooter(bufferToRead, nextIndex);
      return this;
    }
    catch (exception) {
      logger.error("Error occurred in fromBytes method in Arrow class.", exception);
    }
    return null;
  }

  toBytes() {
    try {
      for (let i = 0; i < this.coordinates.length; i++) {
        this.coordinates[i].setLongitude(Math.round(this.coordinates[i].getLongitude() * FACTOR));
        this.coordinates[i].setLatitude(Math.round(this.coordinates[i].getLatitude() * FACTOR));
        if (this.coordinates[i].getAltitude()) {
          this.coordinates[i].setAltitude(this.coordinates[i].getAltitude() * ALTITUDE_FACTOR);
        }

      }
      let byteArray = super.writeGeoToBuffer(false, this.coordinates, true,tileCalcKind.BY_EXTENT);

      if (this.gap !== undefined) {
        IntToBytes.toBytes(byteArray, {value: byteArray.length}, parseInt(this.gap));
      }
      if (this.headSize !== undefined) {
        IntToBytes.toBytes(byteArray, {value: byteArray.length}, parseInt(this.headSize));
      }
      if (this.headAngle !== undefined) {
        IntToBytes.toBytes(byteArray, {value: byteArray.length}, this.headAngle * ORIENTATION_FACTOR);
      }
      //write baseGeometry footers
      byteArray = this.writeFooter(byteArray);
      return byteArray;
    }
    catch (exception) {
      logger.error("Error occurred in toBytes method in Arrow class.", exception);
    }
    return null;
  }

  /**
   * Serialize the shape to string for CRC calculation
   * Should be identical to jGeo method.
   */
  toStringForCrc(){
    return Coordinate.toStringForCrc(this.coordinates);
  }
}

module.exports = {Arrow};
