//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 30/10/2017.
 */
const {BaseGeometry} = require("../Types/baseGeometry.js");
const {Coordinate} = require("../Types/coordinate");
const {tileCalcKind} = require("../Types/tileCalcKind");
const {geoKind} = require("../Types/geoKind");
const {IntToBytes} = require("../Convertors/intToBytes");
const { Logger } = require ('@elbit/logger-server');
const logger = Logger.getLogger("Circle");

class Circle extends BaseGeometry {

  constructor() {
    super();
    this.type=geoKind.Circle.Name;
    logger.trace("custom geo object ('" + this.getPositionType() + "') created");
  }

  getCenter () {
    if (this.coordinates != null && this.coordinates.length > 0)
      return this.coordinates[0];
  }

  static createShape() {
    return new Circle();
  }


  isEquals(position2) {
    if (position2.getPositionType() == geoKind.Circle.Name) {
      let result = this.isCoordinatesEquals(position2);
      if (!result) {
        return false;
      }
      return (result &&
        (Math.abs(this.radius - (position2).radius) <= ALTITUDE_DISTANCE_DEVIATION));
    }
    logger.error("position2 should be with type: " + this.getPositionType());
    return false;
  }

  getPositionType()
  {
    return geoKind.Circle.Name;
  }

  /**
   * @deprecated Please use clone() instead
   */
  clone(oldShape) {
    let clonedShape = new Circle();
    clonedShape = super.cloneCoordinates(oldShape, clonedShape);
    clonedShape.radius = oldShape.radius;
    return clonedShape;
  }

  clone() {
    let clonedShape = new Circle();
    super.copyBaseProperties(clonedShape)
    clonedShape = super.cloneCoordinates(this, clonedShape);
    clonedShape.radius = this.radius;
    return clonedShape;
  }


  initFromGeoJson(geoJson) {
    try {
      if (this.isGeoJson(geoJson)) {
        logger.error("GEO JSON NOT IMPLEMENTED");
      } else if (this.isGeoJsonPlusPlus(geoJson)) {
        this.createFromJsonPlusPlus(geoJson);
      } else if (this.isGeoJsonPlusPlusOnly(geoJson)) {
        this.createFromJsonPlusPlus(geoJson);
      }
    }
    catch (exception) {
      logger.error("Error occurred in initFromGeoJson method in Circle class.", exception);
    }
  }


  createFromJsonPlusPlus(geoJson)
  {
    this.setCoordinates([]);
    this.initCoordinatesFromGeoJsonCenter(geoJson.centerPoint);
    if (geoJson.radius != null && geoJson.radius != undefined) {
      this.radius = geoJson.radius;
    }
  }


  fromBytes(bufferToRead, idxToStart) {
    try {
      let nextIndex = {value: idxToStart};
      let rectanglePtArr = super.readGeoFromBuffer(bufferToRead, nextIndex, NUM_OF_POINTS, false);
      let centerPoint = new Coordinate();
      centerPoint.setLongitude(rectanglePtArr[0].getLongitude() / FACTOR);
      centerPoint.setLatitude(rectanglePtArr[0].getLatitude() / FACTOR);
      if (rectanglePtArr[0].getAltitude()) {
        centerPoint.setAltitude(rectanglePtArr[0].getAltitude() / ALTITUDE_FACTOR);
      }
      this.coordinates = [];
      this.coordinates.push(centerPoint);
      this.radius = IntToBytes.fromBytes(bufferToRead, nextIndex);
      //read baseGeometry footers
      this.readFooter(bufferToRead, nextIndex);
      return this;
    }
    catch (exception) {
      logger.error("Error occurred in fromBytes method in Circle class.", exception);
    }
    return null;
  }


  toBytes() {
    try {
      let circlePtArr = new Array(1);
      let centerPoint = this.coordinates[0];
      centerPoint.setLongitude(Math.round(centerPoint.getLongitude() * FACTOR));
      centerPoint.setLatitude(Math.round(centerPoint.getLatitude() * FACTOR));
      if (centerPoint.getAltitude()) {
        centerPoint.setAltitude(centerPoint.getAltitude() * ALTITUDE_FACTOR);
      }
      circlePtArr[0] = centerPoint;

      let byteArray = super.writeGeoToBuffer(true, circlePtArr, false,tileCalcKind.BY_EXTENT);
      if (this.radius !== undefined) {
        IntToBytes.toBytes(byteArray, {value: byteArray.length}, parseInt(this.radius));
      }
      //write baseGeometry footers
      byteArray = this.writeFooter(byteArray);
      return byteArray;
    }
    catch (exception) {
      logger.error("Error occurred in toBytes method in Circle class.", exception);
    }
    return null;
  }

  /**
   * Serialize the shape to string for CRC calculation
   * Should be identical to jGeo method.
   */
  toStringForCrc(){
    return `${this.getCenter().toStringForCrc()};${Math.floor(this.radius).toString()}`;
  }

}

module.exports = {Circle};
