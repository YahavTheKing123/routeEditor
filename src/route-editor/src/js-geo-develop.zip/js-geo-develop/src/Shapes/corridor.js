//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 30/10/2017.
 */
const {BaseGeometry} = require("../Types/baseGeometry.js");
const {Coordinate} = require("../Types/coordinate");
const {tileCalcKind} = require("../Types/tileCalcKind");
const {geoKind} = require("../Types/geoKind");
const {IntToBytes} = require("../Convertors/intToBytes");
const { Logger } = require ('@elbit/logger-server');
const logger = Logger.getLogger("Corridor");

class Corridor extends BaseGeometry {

  constructor() {
    super();
    this.radius = -1;
    this.type=geoKind.Corridor.Name;
    logger.trace("custom geo object ('" + this.getPositionType() + "') created");
  }

  getCenter () {
    return this.getLineBasedCenter();
  }

  static createShape() {
    return new Corridor();
  }


  isEquals(position2) {
    if (position2.getPositionType() == geoKind.Corridor.Name) {
      let result = this.isCoordinatesEquals(position2);
      if (!result) {
        return false;
      }
      return (result &&
        (Math.abs(this.radius - (position2).radius) <= ALTITUDE_DISTANCE_DEVIATION));
    }
    logger.error("position2 should be with type: " + this.getPositionType());
    return false;
  }

  getPositionType()
  {
    return geoKind.Corridor.Name;
  }

  /**
   * @deprecated Please use clone() instead
   */
  clone(oldShape) {
    let clonedShape = new Corridor();
    clonedShape = super.cloneCoordinates(oldShape, clonedShape);
    clonedShape.radius = oldShape.radius;
    return clonedShape;
  }

  clone() {
    let clonedShape = new Corridor();
    super.copyBaseProperties(clonedShape)
    clonedShape = super.cloneCoordinates(this, clonedShape);
    clonedShape.radius = this.radius;
    return clonedShape;
  }

  initFromGeoJson(geoJson) {
    try {
      if (this.isGeoJson(geoJson)) {
        logger.error("GEO JSON NOT IMPLEMENTED");
      } else if (this.isGeoJsonPlusPlus(geoJson)) {
        this.createFromJsonPlusPlus(geoJson);
      } else if (this.isGeoJsonPlusPlusOnly(geoJson)) {
        this.createFromJsonPlusPlus(geoJson);
      }
    }
    catch (exception) {
      logger.error("Error occurred in initFromGeoJson method in Corridor class.", exception);
    }
  }

  createFromJsonPlusPlus(geoJson)
  {
    this.setCoordinates([]);
    this.initCoordinatesFromGeoJsonCoordinates(geoJson.coordinates);
    if (geoJson.radius != null && geoJson.radius != undefined) {
      this.radius = geoJson.radius;
    }
  }


  fromBytes(bufferToRead, idxToStart) {
    try {
      let nextIndex = {value: idxToStart};
      let corridorPtArr = super.readGeoFromBuffer(bufferToRead, nextIndex, 0, true);
      this.coordinates = [];
      for (let i = 0; i < corridorPtArr.length; i++) {
        let coordinate = new Coordinate();
        this.coordinates.push(coordinate);
        coordinate.setLongitude(corridorPtArr[i].getLongitude() / FACTOR);
        coordinate.setLatitude(corridorPtArr[i].getLatitude() / FACTOR);
        if (corridorPtArr[i].getAltitude()) {
          coordinate.setAltitude(corridorPtArr[i].getAltitude() / ALTITUDE_FACTOR);
        }
      }
      this.radius = IntToBytes.fromBytes(bufferToRead, nextIndex);
      //read baseGeometry footers
      this.readFooter(bufferToRead, nextIndex);
      return this;
    }
    catch (exception) {
      logger.error("Error occurred in fromBytes method in Corridor class.", exception);
    }
    return null;
  }


  toBytes() {
    try {
      for (let i = 0; i < this.coordinates.length; i++) {
        this.coordinates[i].setLongitude(Math.round(this.coordinates[i].getLongitude() * FACTOR));
        this.coordinates[i].setLatitude(Math.round(this.coordinates[i].getLatitude() * FACTOR));
        if (this.coordinates.length > 2) {
          this.coordinates[i].setAltitude(this.coordinates[i].getAltitude() * ALTITUDE_FACTOR);
        }

      }
      let byteArray = super.writeGeoToBuffer(false, this.coordinates, true,tileCalcKind.BY_EXTENT);

      if (this.radius !== undefined) {
        IntToBytes.toBytes(byteArray, {value: byteArray.length}, parseInt(this.radius));
      }
      //write baseGeometry footers
      byteArray = this.writeFooter(byteArray);
      return byteArray;
    }
    catch (exception) {
      logger.error("Error occurred in toBytes method in Corridor class.", exception);
    }
    return null;
  }

  /**
   * Serialize the shape to string for CRC calculation
   * Should be identical to jGeo method.
   */
  toStringForCrc(){
    return Coordinate.toStringForCrc(this.coordinates);
  }
}

module.exports = {Corridor};
