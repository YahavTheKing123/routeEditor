//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 29/10/2017.
 */
const {Polygon} = require("./polygon.js");
const {geoKind} = require("../Types/geoKind");
const {Coordinate} = require("../Types/coordinate");
const { Logger } = require ('@elbit/logger-server');
const logger = Logger.getLogger("GeoCamera");

class GeoCamera extends Polygon {
    constructor() {
      super();
      this.type=geoKind.GeoCamera.Name;
      logger.trace("custom geo object ('" + this.getPositionType() + "') created");
    }

  getPositionType() {
    return geoKind.GeoCamera.Name;
  }

  getCenter () {
    if (this.coordinates != null && this.coordinates.length > 0)
      return this.coordinates[0];
  }

  static createShape() {
    return new GeoCamera();
  }


  isEquals(position2) {
    if (position2.getPositionType() == geoKind.GeoCamera.Name) {
      return this.isCoordinatesEquals(position2);
    }
    logger.error("position2 should be with type: " + this.getPositionType());
    return false;
  }

  /**
   * @deprecated Please use clone() instead
   */
  clone(oldShape) {
    let clonedShape = new GeoCamera();
    clonedShape = super.cloneCoordinates(oldShape, clonedShape);
    return clonedShape;
  }

  clone() {
    let clonedShape = new GeoCamera();
    super.copyBaseProperties(clonedShape)
    clonedShape = super.cloneCoordinates(this, clonedShape);
    return clonedShape;
  }

  getSightPolygon()
  {
    try {
      return this.coordinates.slice(2);
    }
    catch (exception) {
      logger.error("Error occurred in getSightPolygon method in GeoCamera class.", exception);
    }
    return null;
  }

  getSightPoint() {
    try {
      return this.coordinates[1];
    }
    catch (exception) {
      logger.error("Error occurred in getSightPoint method in GeoCamera class, Exception=" + exception);
    }
    return null;
  }

  getCameraPosition() {
    try {
      return this.coordinates[0];
    }
    catch (exception) {
      logger.error("Error occurred in getCameraPosition method in GeoCamera class.", exception);
    }
    return null;
  }

  initFromGeoJson(geoJson) {
    try {
      if (this.isGeoJson(geoJson)) {
        logger.error("GEO JSON NOT IMPLEMENTED");
      } else if (this.isGeoJsonPlusPlus(geoJson)) {
        this.createFromJsonPlusPlus(geoJson);
      } else if (this.isGeoJsonPlusPlusOnly(geoJson)) {
        this.createFromJsonPlusPlus(geoJson);
      }
    }
    catch (exception) {
      logger.error("Error occurred in initFromGeoJson method in GeoCamera class.", exception);
    }
  }

  createFromJsonPlusPlus(geoJson)
  {
    this.setCoordinates([]);
    this.initCoordinatesFromGeoJsonCenter(geoJson.cameraPosition);
    this.initCoordinatesFromGeoJsonCenter(geoJson.sightPosition);
    this.initCoordinatesFromGeoJsonCoordinates(geoJson.sightPolygon[0]);
  }

  /**
   * Serialize the shape to string for CRC calculation
   * Should be identical to jGeo method.
   */
  toStringForCrc(){
    return Coordinate.toStringForCrc(this.coordinates);
  }
}

module.exports = {GeoCamera};
