//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 26/10/2017.
 */
const {BaseGeometry} = require("../Types/baseGeometry.js");
const {Coordinate} = require("../Types/coordinate");
const {tileCalcKind} = require("../Types/tileCalcKind");
const {geoKind} = require("../Types/geoKind");
const { Logger } = require ('@elbit/logger-server');
const logger = Logger.getLogger("Point");

class Point extends BaseGeometry {

  constructor() {
    super();
    this.type=geoKind.Point.Name;
    logger.trace("custom geo object ('" + this.getPositionType() + "') created");
  }

  getPositionType() {
    return geoKind.Point.Name;
  }

  static createShape() {
    return new Point();
  }

  /**
   * @deprecated Please use clone() instead
   */
  clone(oldShape) {
    let clonedShape = new Point();
    clonedShape = super.cloneCoordinates(oldShape, clonedShape);
    return clonedShape;
  }

  clone() {
    let clonedShape = new Point();
    super.copyBaseProperties(clonedShape)
    clonedShape = super.cloneCoordinates(this, clonedShape);
    return clonedShape;
  }

  getCenter() {
    if (this.coordinates != null && this.coordinates.length > 0)
      return this.coordinates[0];
  }

  isEquals(position2) {
    if (position2.getPositionType() == geoKind.Point.Name) {
      return this.isCoordinatesEquals(position2);
    }
    logger.error("position2 should be with type: " + this.getPositionType());
    return false;
  }

  initFromGeoJson(geoJson) {
    try {
      if (this.isGeoJson(geoJson)) {
        this.setCoordinates([]);
        if (geoJson.geometry != null && geoJson.geometry != undefined) {
          this.initCoordinatesFromGeoJsonCenter(geoJson.geometry.coordinates);
        }
      } else if (this.isGeoJsonPlusPlus(geoJson)) {
        this.setCoordinates([]);
        if (geoJson.geometry != null && geoJson.geometry != undefined) {
          this.initCoordinatesFromGeoJsonCenter(geoJson.geometry.coordinates);
        }
      } else if (this.isGeoJsonPlusPlusOnly(geoJson)) {
        this.setCoordinates([]);
        if (geoJson.coordinates != null && geoJson.coordinates != undefined) {
          this.initCoordinatesFromGeoJsonCenter(geoJson.coordinates);
        }
      }
    }
    catch (exception) {
      logger.error("Error occurred in initFromGeoJson method in Point class.", exception);
    }
  }


  fromBytes(bufferToRead, idxToStart) {
    try {
      let nextIndex = {value: idxToStart};
      let ptArr = super.readGeoFromBuffer(bufferToRead, nextIndex, NUM_OF_POINTS, false);

      let coordinate = ptArr[POINT_IDX];
      coordinate.setLongitude(coordinate.getLongitude() / FACTOR);
      coordinate.setLatitude(coordinate.getLatitude() / FACTOR);
      if (coordinate.getAltitude()) {
        coordinate.setAltitude(coordinate.getAltitude() / ALTITUDE_FACTOR);
      }
      this.coordinates = [];
      this.coordinates.push(coordinate);
      //read baseGeometry footers
      this.readFooter(bufferToRead, nextIndex);
      return this;
    }
    catch (exception) {
      logger.error("Error occurred in fromBytes method in Point class.", exception);
    }
    return null;
  }


  toBytes() {
    try {
      let ptArr = new Array(NUM_OF_POINTS);
      let coordinate = this.coordinates[0];
      coordinate.setLongitude(Math.round(coordinate.getLongitude() * FACTOR));
      coordinate.setLatitude(Math.round(coordinate.getLatitude() * FACTOR));
      if (coordinate.getAltitude()) {
        coordinate.setAltitude(coordinate.getAltitude() * ALTITUDE_FACTOR);
      }
      ptArr[POINT_IDX] = coordinate;//same as calling this but in BswCoordBType representation
      let byteArray = super.writeGeoToBuffer(true, ptArr, false, tileCalcKind.BY_POINTS);
      //write baseGeometry footers
      byteArray = this.writeFooter(byteArray);
      return byteArray;
    }
    catch (exception) {
      logger.error("Error occurred in toBytes method in Point class.", exception);
    }
    return null;
  }
}

module.exports = {Point};
