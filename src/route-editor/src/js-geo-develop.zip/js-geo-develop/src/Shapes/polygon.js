//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 25/10/2017.
 */
const {BaseGeometry} = require("../Types/baseGeometry.js");
const {Coordinate} = require("../Types/coordinate");
const {tileCalcKind} = require("../Types/tileCalcKind");
const {geoKind} = require("../Types/geoKind");
const { Logger } = require ('@elbit/logger-server');
const logger = Logger.getLogger("Polygon");


class Polygon extends BaseGeometry {
  constructor() {
    super();
    this.type=geoKind.Polygon.Name;
    logger.trace("custom geo object ('" + this.getPositionType() + "') created");
  }

  getPositionType() {
    return geoKind.Polygon.Name;
  }


  getCenter() {
    let retVal = null;

    if (this.coordinates != null && this.coordinates.length > 2) {
      let lon = 0;
      let lat = 0;

      for (let i = 0; i < this.coordinates.length; i++) {
        lon += this.coordinates[i].getLongitude();
        lat += this.coordinates[i].getLatitude();
      }
      retVal = new Coordinate();
      retVal.setLongitude(lon / this.coordinates.length);
      retVal.setLatitude(lat / this.coordinates.length);
    }

    return retVal;
  }

  static createShape() {
    return new Polygon();
  }


  isEquals(position2) {
    if (position2.getPositionType() == geoKind.Polygon.Name) {
      return this.isCoordinatesEquals(position2);
    }
    logger.error("position2 should be with type: " + this.getPositionType());
    return false;
  }

  /**
   * @deprecated Please use clone() instead
   */
  clone(oldShape) {
    let clonedShape = new Polygon();
    clonedShape = super.cloneCoordinates(oldShape, clonedShape);
    return clonedShape;
  }

  clone() {
    let clonedShape = new Polygon();
    super.copyBaseProperties(clonedShape)
    clonedShape = super.cloneCoordinates(this, clonedShape);
    return clonedShape;
  }

  initFromGeoJson(geoJson) {
    try {
      if (this.isGeoJson(geoJson)) {
        this.setCoordinates([]);
        if (geoJson.geometry != null && geoJson.geometry != undefined) {
          let geometryCoordinate = geoJson.geometry.coordinates;
          for (let i = 0; i < geometryCoordinate.length; i++) {
            let innerArray = geometryCoordinate[i];
            this.initCoordinatesFromGeoJsonCoordinates(innerArray);
          }
        }
      } else if (this.isGeoJsonPlusPlus(geoJson)) {
        this.setCoordinates([]);
        if (geoJson.geometry != null && geoJson.geometry != undefined) {
          let geometryCoordinate = geoJson.geometry.coordinates;
          for (let i = 0; i < geometryCoordinate.length; i++) {
            let innerArray = geometryCoordinate[i];
            this.initCoordinatesFromGeoJsonCoordinates(innerArray);
          }
        }
      } else if (this.isGeoJsonPlusPlusOnly(geoJson)) {
        this.setCoordinates([]);
        if (geoJson.coordinates != null && geoJson.coordinates != undefined) {
          let geometryCoordinate = geoJson.coordinates;
          for (let i = 0; i < geometryCoordinate.length; i++) {
            let innerArray = geometryCoordinate[i];
            this.initCoordinatesFromGeoJsonCoordinates(innerArray);
          }
        }
      }
    }
    catch (exception) {
      logger.error("Error occurred in initFromGeoJson method in Polygon class.", exception);
    }
  }


  fromBytes(bufferToRead, idxToStart) {
    try {
      let nextIndex = {value: idxToStart};
      let coordinates = super.readGeoFromBuffer(bufferToRead, nextIndex, 0, true);
      this.coordinates = [];
      for (let i = 0; i < coordinates.length; i++) {
        coordinates[i].setLongitude(coordinates[i].getLongitude() / FACTOR);
        coordinates[i].setLatitude(coordinates[i].getLatitude() / FACTOR);
        if (coordinates[i].getAltitude()) {
          coordinates[i].setAltitude(coordinates[i].getAltitude() / ALTITUDE_FACTOR);
        }
        this.coordinates.push(coordinates[i]);
      }
      this.readFooter(bufferToRead, nextIndex);
      return this;
    }
    catch(exception) {
      logger.error("Error occurred in fromBytes method in "+ this.getPositionType() +" class.", exception);
    }
    return null;
  }

  toBytes() {
    try {
      for (let i = 0; i < this.coordinates.length; i++) {
        this.coordinates[i].setLongitude(Math.round(this.coordinates[i].getLongitude() * FACTOR));
        this.coordinates[i].setLatitude(Math.round(this.coordinates[i].getLatitude() * FACTOR));
        if (this.coordinates[i].getAltitude()) {
          this.coordinates[i].setAltitude(this.coordinates[i].getAltitude() * ALTITUDE_FACTOR);
        }
      }
      let byteArray = super.writeGeoToBuffer(false, this.coordinates, true, tileCalcKind.BY_EXTENT);
      //write baseGeometry footers
      byteArray = this.writeFooter(byteArray);
      return byteArray;

    }
    catch(exception) {
      logger.error("Error occurred in toBytes method in "+ this.getPositionType()+" class.", exception);
    }
    return null;
  }

  /**
   * Serialize the shape to string for CRC calculation
   * Should be identical to jGeo method.
   */
  toStringForCrc(){
    return Coordinate.toStringForCrc(this.coordinates);
  }
}

module.exports={Polygon};

