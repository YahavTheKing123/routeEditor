//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 29/10/2017.
 */
const {BaseGeometry} = require("../Types/baseGeometry.js");
const {Coordinate} = require("../Types/coordinate");
const {tileCalcKind} = require("../Types/tileCalcKind");
const {geoKind} = require("../Types/geoKind");
const { Logger } = require ('@elbit/logger-server');
const logger = Logger.getLogger("Polyline");

class Polyline extends BaseGeometry {
  constructor() {
    super();
    this.type=geoKind.Polyline.Name;
    logger.trace("custom geo object ('" + this.getPositionType() + "') created");
  }


  getPositionType() {
    return geoKind.Polyline.Name;
  }

  getCenter() {
    return this.getLineBasedCenter();
  }

  static createShape() {
    return new Polyline();
  }


  isEquals(position2) {
    if (position2.getPositionType() == geoKind.Polyline.Name) {
      return this.isCoordinatesEquals(position2);
    }
    logger.error("position2 should be with type: " + this.getPositionType());
    return false;
  }

  /**
   * @deprecated Please use clone() instead
   */
  clone(oldShape) {
    let clonedShape = new Polyline();
    clonedShape = super.cloneCoordinates(oldShape, clonedShape);
    return clonedShape;
  }

  clone() {
    let clonedShape = new Polyline();
    super.copyBaseProperties(clonedShape)
    clonedShape = super.cloneCoordinates(this, clonedShape);
    return clonedShape;
  }

  initFromGeoJson(geoJson) {
    try {
      if (this.isGeoJson(geoJson)) {
        this.setCoordinates([]);
        if (geoJson.geometry != null && geoJson.geometry != undefined) {
          this.initCoordinatesFromGeoJsonCoordinates(geoJson.geometry.coordinates);
        }
      } else if (this.isGeoJsonPlusPlus(geoJson)) {
        this.setCoordinates([]);
        if (geoJson.geometry != null && geoJson.geometry != undefined) {
          this.initCoordinatesFromGeoJsonCoordinates(geoJson.geometry.coordinates);
        }
      } else if (this.isGeoJsonPlusPlusOnly(geoJson)) {
        this.setCoordinates([]);
        if (geoJson.coordinates != null && geoJson.coordinates != undefined) {
          this.initCoordinatesFromGeoJsonCoordinates(geoJson.coordinates);
        }
      }
    }
    catch (exception) {
      logger.error("Error occurred in initFromGeoJson method in Polyline class.", exception);
    }
  }


  fromBytes(bufferToRead, idxToStart) {
    try {
      let nextIndex = {value: idxToStart}
      let coordinates = super.readGeoFromBuffer(bufferToRead, nextIndex, 0, true);
      this.coordinates = [];
      for (let i = 0; i < coordinates.length; i++) {
        coordinates[i].setLongitude(coordinates[i].getLongitude() / FACTOR);
        coordinates[i].setLatitude(coordinates[i].getLatitude() / FACTOR);
        if (coordinates[i].getAltitude()) {
          coordinates[i].setAltitude(coordinates[i].getAltitude() / ALTITUDE_FACTOR);
        }
        this.coordinates.push(coordinates[i]);
      }
      this.readFooter(bufferToRead, nextIndex);
      return this;
    }
    catch (exception) {
      logger.error("Error occurred in fromBytes method in Polyline class.", exception);
    }
    return null;
  }


  toBytes() {
    try {
      for (let i = 0; i < this.coordinates.length; i++) {
        this.coordinates[i].setLongitude(Math.round(this.coordinates[i].getLongitude() * FACTOR));
        this.coordinates[i].setLatitude(Math.round(this.coordinates[i].getLatitude() * FACTOR));
        if (this.coordinates[i].getAltitude()) {
          this.coordinates[i].setAltitude(this.coordinates[i].getAltitude() * ALTITUDE_FACTOR);
        }
      }
      let byteArray = super.writeGeoToBuffer(false, this.coordinates, true, tileCalcKind.BY_EXTENT);
      //write baseGeometry footers
      byteArray = this.writeFooter(byteArray);
      return byteArray;
    }
    catch (exception) {
      logger.error("Error occurred in toBytes method in Polyline class.", exception);
    }

  }

  /**
   * Serialize the shape to string for CRC calculation
   * Should be identical to jGeo method.
   */
  toStringForCrc(){
    return Coordinate.toStringForCrc(this.coordinates);
  }
}

module.exports = {Polyline};
