//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 30/10/2017.
 */
const {BaseGeometry} = require("../Types/baseGeometry.js");
const {Coordinate} = require("../Types/coordinate");
const {tileCalcKind} = require("../Types/tileCalcKind");
const {geoKind} = require("../Types/geoKind");
const {IntToBytes} = require("../Convertors/intToBytes");
const { Logger } = require ('@elbit/logger-server');
const logger = Logger.getLogger("Rectangle");

class Rectangle extends BaseGeometry {

  constructor() {
    super();
    this.width = -1;
    this.height = -1;
    this.type=geoKind.Rectangle.Name;
    this.orientation = -1;
    logger.trace("custom geo object ('" + this.getPositionType() + "') created");
  }

  getCenter () {
    if (this.coordinates != null && this.coordinates.length > 0)
      return this.coordinates[0];
  }

  static createShape() {
    return new Rectangle();
  }


  isEquals(position2) {
    if (position2.getPositionType() == geoKind.Rectangle.Name) {
      let result = this.isCoordinatesEquals(position2);
      if (!result) {
        return false;
      }
      return (result &&
        (Math.abs(this.width - (position2).width) <= ALTITUDE_DISTANCE_DEVIATION) &&
        (Math.abs(this.height - (position2).height) <= ALTITUDE_DISTANCE_DEVIATION) &&
        (Math.abs(this.orientation - (position2).orientation) <= ALTITUDE_DISTANCE_DEVIATION));
    }
    logger.error("position2 should be with type: " + this.getPositionType());
    return false;
  }

  getPositionType()
  {
    return geoKind.Rectangle.Name;
  }

  /**
   * @deprecated Please use clone() instead
   */
  clone(oldShape) {
    let clonedShape = new Rectangle();
    clonedShape = super.cloneCoordinates(oldShape, clonedShape);
    clonedShape.width = oldShape.width;
    clonedShape.height = oldShape.height;
    clonedShape.orientation = oldShape.orientation;
    return clonedShape;
  }

  clone() {
    let clonedShape = new Rectangle();
    super.copyBaseProperties(clonedShape)
    clonedShape = super.cloneCoordinates(this, clonedShape);
    clonedShape.width = this.width;
    clonedShape.height = this.height;
    clonedShape.orientation = this.orientation;
    return clonedShape;
  }

  initFromGeoJson(geoJson) {
    try {
      if (this.isGeoJson(geoJson)) {
        logger.error("GEO JSON NOT IMPLEMENTED");
      } else if (this.isGeoJsonPlusPlus(geoJson)) {
        this.createFromJsonPlusPlus(geoJson);
      } else if (this.isGeoJsonPlusPlusOnly(geoJson)) {
        this.createFromJsonPlusPlus(geoJson);
      }
    }
    catch (exception) {
      logger.error("Error occurred in initFromGeoJson method in Rectangle class.", exception);
    }
  }

  createFromJsonPlusPlus(geoJson)
  {
    this.setCoordinates([]);
    this.initCoordinatesFromGeoJsonCenter(geoJson.centerPoint);
    if (geoJson.height != null && geoJson.height != undefined) {
      this.height = geoJson.height;
    }
    if (geoJson.width != null && geoJson.width != undefined) {
      this.width = geoJson.width;
    }
    if (geoJson.orientation != null && geoJson.orientation != undefined) {
      this.orientation = geoJson.orientation;
    }
  }


  fromBytes(bufferToRead, idxToStart) {
    try {
      let nextIndex = {value: idxToStart};
      let rectanglePtArr = super.readGeoFromBuffer(bufferToRead, nextIndex, NUM_OF_POINTS, false);
      let centerPoint = new Coordinate();
      centerPoint.setLongitude(rectanglePtArr[0].getLongitude() / FACTOR);
      centerPoint.setLatitude(rectanglePtArr[0].getLatitude() / FACTOR);
      if (rectanglePtArr[0].getAltitude()) {
        centerPoint.setAltitude(rectanglePtArr[0].getAltitude() / ALTITUDE_FACTOR);
      }
      this.coordinates = [];
      this.coordinates.push(centerPoint);
      this.width = IntToBytes.fromBytes(bufferToRead, nextIndex);
      this.height = IntToBytes.fromBytes(bufferToRead, nextIndex);
      this.orientation = IntToBytes.fromBytes(bufferToRead, nextIndex) /  ORIENTATION_FACTOR;
      //read baseGeometry footers
      this.readFooter(bufferToRead, nextIndex);
      return this;
    }
    catch (exception) {
      logger.error("Error occurred in fromBytes method in Rectangle class.", exception);
    }
    return null;
  }

  toBytes() {
    try {
      let rectangleArr = new Array(1);
      let centerPoint = this.coordinates[0];
      centerPoint.setLongitude(Math.round(centerPoint.getLongitude() * FACTOR));
      centerPoint.setLatitude(Math.round(centerPoint.getLatitude() * FACTOR));
      if (centerPoint.getAltitude()) {
        centerPoint.setAltitude(centerPoint.getAltitude() * ALTITUDE_FACTOR);
      }
      rectangleArr[0] = centerPoint;

      let byteArray = super.writeGeoToBuffer(true, rectangleArr, false,tileCalcKind.BY_EXTENT);
      if (this.width !== undefined) {
        IntToBytes.toBytes(byteArray, {value: byteArray.length}, parseInt(this.width));
      }
      if (this.height !== undefined) {
        IntToBytes.toBytes(byteArray, {value: byteArray.length}, parseInt(this.height));
      }
      if (this.orientation !== undefined) {
        IntToBytes.toBytes(byteArray, {value: byteArray.length}, this.orientation * ORIENTATION_FACTOR);
      }
      //write baseGeometry footers
      byteArray = this.writeFooter(byteArray);
      return byteArray;
    }
    catch (exception) {
      logger.error("Error occurred in toBytes method in Rectangle class.", exception);
    }
    return null;
  }

  /**
   * Serialize the shape to string for CRC calculation
   * Should be identical to jGeo method.
   */
  toStringForCrc(){
    return `${this.getCenter().toStringForCrc()};${Math.floor(this.height).toString()};${Math.floor(this.width).toString()};${Math.floor(this.orientation).toString()}`;
  }
}

module.exports = {Rectangle};
