//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 06/11/2017.
 */
const {BaseGeometry} = require("../Types/baseGeometry.js");
const {Coordinate} = require("../Types/coordinate");
const {tileCalcKind} = require("../Types/tileCalcKind");
const {geoKind} = require("../Types/geoKind");
const {IntToBytes} = require("../Convertors/intToBytes");
const { Logger } = require ('@elbit/logger-server');
const logger = Logger.getLogger("Sector");

class Sector extends BaseGeometry {

  constructor() {
    super();
    this.minimumRadius = -1;
    this.maximumRadius = -1;
    this.fromAngle = -1;
    this.toAngle = -1;
    this.type=geoKind.Sector.Name;
    logger.trace("custom geo object ('" + this.getPositionType() + "') created");
  }

  getCenter () {
    if (this.coordinates != null && this.coordinates.length > 0)
      return this.coordinates[0];
  }

  static createShape() {
    return new Sector();
  }


  isEquals(position2) {
    if (position2.getPositionType() == geoKind.Sector.Name) {
      let result = this.isCoordinatesEquals(position2);
      if (!result) {
        return false;
      }
      return (result &&
        (Math.abs(this.minimumRadius - (position2).minimumRadius) <= ALTITUDE_DISTANCE_DEVIATION) &&
        (Math.abs(this.maximumRadius - (position2).maximumRadius) <= ALTITUDE_DISTANCE_DEVIATION) &&
        (Math.abs(this.fromAngle - (position2).fromAngle) <= ALTITUDE_DISTANCE_DEVIATION) &&
        (Math.abs(this.toAngle - (position2).toAngle) <= ALTITUDE_DISTANCE_DEVIATION));
    }
    logger.error("position2 should be with type: " + this.getPositionType());
    return false;
  }

  getPositionType()
  {
    return geoKind.Sector.Name;
  }

  /**
   * @deprecated Please use clone() instead
   */
  clone(oldShape) {
    let clonedShape = new Sector();
    clonedShape = super.cloneCoordinates(oldShape, clonedShape);
    clonedShape.minimumRadius = oldShape.minimumRadius;
    clonedShape.maximumRadius = oldShape.maximumRadius;
    clonedShape.fromAngle = oldShape.fromAngle;
    clonedShape.toAngle = oldShape.toAngle;
    return clonedShape;
  }

  clone() {
    let clonedShape = new Sector();
    super.copyBaseProperties(clonedShape)
    clonedShape = super.cloneCoordinates(this, clonedShape);
    clonedShape.minimumRadius = this.minimumRadius;
    clonedShape.maximumRadius = this.maximumRadius;
    clonedShape.fromAngle = this.fromAngle;
    clonedShape.toAngle = this.toAngle;
    return clonedShape;
  }

  initFromGeoJson(geoJson) {
    try {
      if (this.isGeoJson(geoJson)) {
        logger.error("GEO JSON NOT IMPLEMENTED");
      } else if (this.isGeoJsonPlusPlus(geoJson)) {
        this.createFromJsonPlusPlus(geoJson);
      } else if (this.isGeoJsonPlusPlusOnly(geoJson)) {
        this.createFromJsonPlusPlus(geoJson);
      }
    }
    catch (exception) {
      logger.error("Error occurred in initFromGeoJson method in Sector class.", exception);
    }
  }

  createFromJsonPlusPlus(geoJson)
  {
    this.setCoordinates([]);
    this.initCoordinatesFromGeoJsonCenter(geoJson.centerPoint);
    if (geoJson.minimumRadius != null && geoJson.minimumRadius != undefined) {
      this.minimumRadius = geoJson.minimumRadius;
    }
    if (geoJson.maximumRadius != null && geoJson.maximumRadius != undefined) {
      this.maximumRadius = geoJson.maximumRadius;
    }
    if (geoJson.fromAngle != null && geoJson.fromAngle != undefined) {
      this.fromAngle = geoJson.fromAngle;
    }
    if (geoJson.toAngle != null && geoJson.toAngle != undefined) {
      this.toAngle = geoJson.toAngle;
    }
  }


  fromBytes(bufferToRead, idxToStart) {
    try {
      let nextIndex = {value: idxToStart};
      let sectorArr = super.readGeoFromBuffer(bufferToRead, nextIndex, NUM_OF_POINTS, false);

      let centerPoint = new Coordinate();
      centerPoint.setLongitude(sectorArr[0].getLongitude() / FACTOR);
      centerPoint.setLatitude(sectorArr[0].getLatitude() / FACTOR);
      if (sectorArr[0].getAltitude()) {
        centerPoint.setAltitude(sectorArr[0].getAltitude() / ALTITUDE_FACTOR);
      }
      this.coordinates = [];
      this.coordinates.push(centerPoint);
      this.minimumRadius = IntToBytes.fromBytes(bufferToRead, nextIndex);
      this.maximumRadius = IntToBytes.fromBytes(bufferToRead, nextIndex);
      this.fromAngle = IntToBytes.fromBytes(bufferToRead, nextIndex) / ORIENTATION_FACTOR;
      this.toAngle = IntToBytes.fromBytes(bufferToRead, nextIndex) / ORIENTATION_FACTOR;
      this.readFooter(bufferToRead, nextIndex);
      return this;
    }
    catch (exception) {
      logger.error("Error occurred in fromBytes method in Sector class.", exception);
    }
    return null;
  }

  toBytes() {
    try {
      let sectorArray = new Array(1);
      let centerPoint = this.coordinates[0];
      centerPoint.setLongitude(Math.round(centerPoint.getLongitude() * FACTOR));
      centerPoint.setLatitude(Math.round(centerPoint.getLatitude() * FACTOR));
      if (centerPoint.getAltitude()) {
        centerPoint.setAltitude(centerPoint.getAltitude() * ALTITUDE_FACTOR);
      }
      sectorArray[0] = centerPoint;

      let byteArray = super.writeGeoToBuffer(true, sectorArray, false,tileCalcKind.BY_EXTENT);
      if (this.minimumRadius !== undefined) {
        IntToBytes.toBytes(byteArray, {value: byteArray.length}, parseInt(this.minimumRadius));
      }
      if (this.maximumRadius !== undefined) {
        IntToBytes.toBytes(byteArray, {value: byteArray.length}, parseInt(this.maximumRadius));
      }
      if (this.fromAngle !== undefined) {
        IntToBytes.toBytes(byteArray, {value: byteArray.length}, this.fromAngle * ORIENTATION_FACTOR);
      }
      if (this.toAngle !== undefined) {
        IntToBytes.toBytes(byteArray, {value: byteArray.length}, this.toAngle * ORIENTATION_FACTOR);
      }
      //write baseGeometry footers
      byteArray = this.writeFooter(byteArray);
      return byteArray;
    }
    catch (exception) {
      logger.error("Error occurred in toBytes method in Sector class.", exception);
    }
    return null;
  }

  /**
   * Serialize the shape to string for CRC calculation
   * Should be identical to jGeo method.
   */
  toStringForCrc(){
    return `${this.getCenter().toStringForCrc()};${Math.floor(this.fromAngle).toString()};${Math.floor(this.toAngle).toString()};${Math.floor(this.minimumRadius).toString()};${Math.floor(this.maximumRadius).toString()}`;
  }
}

module.exports = {Sector};
