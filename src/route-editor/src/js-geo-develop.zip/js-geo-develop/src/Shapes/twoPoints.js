const {Polyline} = require("./polyline.js");
const {geoKind} = require("../Types/geoKind");
const {Coordinate} = require("../Types/coordinate");
const { Logger } = require ('@elbit/logger-server');
const logger = Logger.getLogger("TwoPoints");

class TwoPoints extends Polyline {

  constructor() {
    super();
    this.type=geoKind.TwoPoints.Name;
    logger.trace("custom geo object ('" + this.getPositionType() + "') created");
  }

  getPositionType()
  {
    return geoKind.TwoPoints.Name;
  }

  static createShape() {
    return new TwoPoints();
  }


  isEquals(position2) {
    if (position2.getPositionType() == geoKind.TwoPoints.Name) {
      return this.isCoordinatesEquals(position2);
    }
    logger.error("position2 should be with type: " + this.getPositionType());
    return false;
  }

  /**
   * @deprecated Please use clone() instead
   */
  clone(oldShape) {
    let clonedShape = new TwoPoints();
    clonedShape = super.cloneCoordinates(oldShape, clonedShape);
    return clonedShape;
  }

  clone() {
    let clonedShape = new TwoPoints();
    clonedShape = super.cloneCoordinates(this, clonedShape);
    return clonedShape;
  }

  fromBytes(bufferToRead, idxToStart) {
    try {
      let nextIndex = {value: idxToStart};
      let coordinates = super.readGeoFromBuffer(bufferToRead, nextIndex, 2, true);
      this.coordinates = [];
      for (let i = 0; i < coordinates.length; i++) {
        coordinates[i].setLongitude(coordinates[i].getLongitude() / FACTOR);
        coordinates[i].setLatitude(coordinates[i].getLatitude() / FACTOR);
        if (coordinates[i].getAltitude()) {
          coordinates[i].setAltitude(coordinates[i].getAltitude() / ALTITUDE_FACTOR);
        }
        this.coordinates.push(coordinates[i]);
      }
      this.readFooter(bufferToRead, nextIndex);
      return this;
    }
    catch (exception) {
      logger.error("Error occurred in fromBytes method in Polyline class.", exception);
    }
    return null;
  }

  /**
   * Serialize the shape to string for CRC calculation
   * Should be identical to jGeo method.
   */
  toStringForCrc(){
    return Coordinate.toStringForCrc(this.coordinates);
  }
}

module.exports = {TwoPoints};
