//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 28/01/2018.
 */
class Vector {

  constructor(startCoordinate, endCoordinate, length, azimuth, elevation) {
    this.startCoordinate = startCoordinate;
    this.endCoordinate = endCoordinate;
    this.distance = length;
    this.azimuth = azimuth;
    this.elevation = elevation;
  }

  static createShape() {
    return new Vector();
  }


  /**
   *
   * @return start point as Coordinate type
   */
  getStartPoint() {
    if (this.startCoordinate == null || this.startCoordinate == undefined) {
      return undefined;
    }
    return this.startCoordinate;
  }

  /**
   * Set start point coordinate
   *
   * @param coordinate - input coordinate (typeOf Coordinate)
   */
  setStartPoint(coordinate) {
    this.startCoordinate = coordinate.clone();
  }

  /**
   *
   * @return end point as Coordinate type
   */
  getEndPoint() {
    if (this.endCoordinate == null || this.endCoordinate == undefined) {
      return undefined;
    }
    return this.endCoordinate;
  }

  /**
   * Set end point coordinate
   *
   * @param coordinate - input coordinate (typeOf Coordinate)
   */
  setEndPoint(coordinate) {
    this.endCoordinate = coordinate.clone();
  }

  /**
   *
   * @return calculated azimuth between start and end points
   */
  getAzimuth() {
    if (this.azimuth == null || this.azimuth == undefined) {
      return undefined;
    }
    return this.azimuth;
  }

  /**
   *
   * @return calculated elevation between start and end points
   */
  getElevation() {
    if (this.elevation == null || this.elevation == undefined) {
      return undefined;
    }
    return this.elevation;
  }

  /**
   * Set vector azimuth
   *
   * @param azimuth - azimuth to set
   */
  setAzimuth(azimuth) {
    this.azimuth = azimuth;
  }

  /**
   * Set vector elevation
   *
   * @param elevation - elevation to set
   */
  setElevation(elevation) {
    this.elevation = elevation;
  }

  /**
   *
   * @return calculated distance between start end end point
   */
  getDistance() {
    if (this.distance == null || this.distance == undefined) {
      return undefined;
    }
    return this.distance;
  }

  /**
   * Set vector distance
   *
   * @param distance - distance to set
   */
  setDistance(distance) {
    this.distance = distance;
  }


}

module.exports = {Vector};
