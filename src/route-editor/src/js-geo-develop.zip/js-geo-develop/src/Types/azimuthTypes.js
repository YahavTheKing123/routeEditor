//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

var azimuthTypes = Object.freeze({
  GEO: 1,
  GRID: 2,
  UNDEFINED: -1,
});
module.exports = azimuthTypes;
