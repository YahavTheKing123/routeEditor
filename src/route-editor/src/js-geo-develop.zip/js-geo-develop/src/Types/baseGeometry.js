//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 25/10/2017.
 */
const {IntToBytes} =require("../Convertors/intToBytes");
const {Coordinate} =require("./coordinate");
const {geoKind} =require("./geoKind");
const {tileCalcKind} =require("./tileCalcKind");
const { Logger } = require ('@elbit/logger-server');
const logger = Logger.getLogger("BaseGeometry");
const {GeometricStaticCalculations}=require("../GeoCalculations/geometricStaticCalculations");
const {GeographicStaticCalculations}=require("../GeoCalculations/geographicStaticCalculations");

 class BaseGeometry {

   constructor() {
     this.isCustomGeoObject = true;
     this.coordinates = null;
     this.isSpline = false;
   }

   getIsSpline() {
     return this.isSpline;
   }

   setIsSpline(splineValue) {
     this.isSpline = splineValue;
   }

   copyBaseProperties(copyToObject) {
     copyToObject.isSpline = this.getIsSpline();
   }

   getSmoothShapeIfSpline() {
     if (GeometricStaticCalculations && this.getIsSpline() == true) {
       return GeometricStaticCalculations.smoothShapeIfSpline(this)
     }
   }

   getShapeFallback() {
     if (this.getPositionType() != geoKind.Point.Name && this.getPositionType() != geoKind.Polygon.Name && this.getPositionType() != geoKind.Polyline.Name) {
       return GeographicStaticCalculations.toBasicGeometry(this, NUM_POLYGON_POINTS);
     }
     else {
       return this;
     }
   }

   /**
    * Returns the geometric distance from another geometry, it calculates the distance between two centers.
    *
    * @param shape2
    * @return Geometric distance.
    */
   getGegraphicVectorFromTwoLocations(shape2) {
     let vec = GeographicStaticCalculations.vectorFromTwoLocations(this.getCenter(), shape2.getCenter());
     return vec;
   }

   /**
    * Returns the geometric distance from another geometry, it calculates the distance between two centers.
    *
    * @param shape2
    * @return Geometric distance.
    */
   getGeometricDistance(shape2) {
     let vec = GeometricStaticCalculations.vectorFromTwoLocations(this.getCenter(), shape2.getCenter());
     return vec.getDistance();
   }

   /**
    * Check if this shape contained by the input shape
    * @param shape - input shape to check
    * @return boolean if your shape contains the input shape, otherwise return false
    */
   isContained(shape) {
     return GeometricStaticCalculations.isContains(shape, this);
   }

   /**
    * Check if this shape contains the input shape
    * @param shape - input shape to check
    * @return boolean if your shape is contained by the input shape, otherwise return false
    */
   isContains(shape) {
     try {
       return GeometricStaticCalculations.isContains(this, shape);
     } catch (exception) {
       return false;
     }
   }

   /**
    * Check is this shape intersects with the input shape
    * @param shape - input shape to check
    * @return array of intersection points if your shape is intersecting with the input shape, otherwise return null
    */
   isIntersects(shape) {
     try {
       return GeometricStaticCalculations.isIntersects(this, shape);
     } catch (exception) {

     }
     return null;
   }

   /**
    * Check if this shape contains the input shape or if this shape intersects with the input shape
    * @param shape - input shape to check
    * @return boolean if overlap occurs, otherwise return false
    */
   isOverlap(shape) {
     try {
       return GeometricStaticCalculations.isOverlap(this, shape);
     } catch (exception) {
       return false;
     }
   }

   /**
    * calculate the nearest geographic distance between this shape and input shape
    * @param shape - the input shape
    * @return the calculated distance as double
    */
   getNearestDistance(shape) {
     try {
       let result = GeographicStaticCalculations.nearestDistanceBetweenGeometries(this, shape);
       return result.nearestDistance;
     } catch (exception) {
       return -1;
     }
   }

   /**
    * calculate the geographic area of this shape
    * @return the calculated area as double
    */
   getArea() {
     try {
       return GeographicStaticCalculations.areaOfGeometry(this);
     } catch (exception) {
       return -1;
     }
   }

   /**
    * Expand this shape by input distance
    * @param distance - size of expansion
    * @return {BaseGeometry} - return new expanded shape as (BaseGeometry type)
    */
   expandShape(distance) {
     return GeographicStaticCalculations.expandShape(this,distance);
   }

   isWithinDistance(shape,minDistance,maxDistance) {
     return GeographicStaticCalculations.isLocationsWithinDistance(this, shape, minDistance, maxDistance);
   }

   isCoordinatesEquals(position2) {
     if (position2 == null || !this.getPositionType() == position2.getPositionType()) {
       return false;
     }
     let position1Coordinate = this.coordinates;
     let position2Coordinate = position2.coordinates;

     if (((position1Coordinate == null || position1Coordinate == undefined) && (position2Coordinate != null && position2Coordinate != undefined)) ||
       ((position2Coordinate == null || position2Coordinate == undefined) && (position1Coordinate != null && position1Coordinate != undefined)) ||
       (position1Coordinate.length != position2Coordinate.length) ||
       position1Coordinate.length == 0) {
       return false;
     }

     for (let i = 0; i < position1Coordinate.length; i++) {
       let isEqual = position1Coordinate[i].equals(position2Coordinate[i]);
       if (isEqual == false) {
         return false;
       }
     }
     return true;
   }

   getPositionType() {
     return "";
   }

   getCenter() {
     return null;
   }

   setCoordinates (coordinates) {
     this.coordinates = coordinates;
   }

   /**
    * Returns the center coordinate for line based geometries.
    * @return Center coordinate.
    */
   getLineBasedCenter() {
     let retVal = null;
     if (this.coordinates != null && this.coordinates.length > 1) {
       let len = this.coordinates.length;
       if (len % 2 == 1) {
         retVal = new Coordinate(this.coordinates[Math.floor(len / 2)].getLongitude(), this.coordinates[Math.floor(len / 2)].getLatitude());
       }
       else {
         let first = this.coordinates[Math.floor(len / 2) - 1];
         let second = this.coordinates[Math.floor(len / 2)];
         if (first != null && second != null) {
           retVal = new Coordinate((first.getLongitude() + second.getLongitude()) / 2, (first.getLatitude() + second.getLatitude()) / 2, (first.getAltitude() + second.getAltitude()) / 2);
         }
       }
     }
     return retVal;
   }

   cloneCoordinates(oldShape, clonedShape) {
     if (oldShape.coordinates && oldShape.coordinates.length > 0) {
       clonedShape.coordinates = [];
       for (let i = 0; i < oldShape.coordinates.length; i++) {
         clonedShape.coordinates.push(new Coordinate());
         clonedShape.coordinates[i].setLongitude(oldShape.coordinates[i].longitude);
         clonedShape.coordinates[i].setLatitude(oldShape.coordinates[i].latitude);
         clonedShape.coordinates[i].setAltitude(oldShape.coordinates[i].altitude);
       }
       return clonedShape;
     }
     else {
       logger.error("Cannot clone " + this.getPositionType());
     }
   }

   isGeoJsonPlusPlusOnly(geoJson) {
     if (geoJson != null && geoJson != undefined) {
       if (geoJson.shape != null && geoJson.geometry == null) {
         return true;
       }
     }
     return false;
   }

   isGeoJsonPlusPlus(geoJson) {
     if (geoJson != null && geoJson != undefined) {
       if (geoJson.shape != null && geoJson.geometry != null) {
         return true;
       }
     }
     return false;
   }

   isGeoJson(geoJson) {
     if (geoJson != null && geoJson != undefined) {
       if (geoJson.shape == null && geoJson.geometry != null) {
         return true;
       }
     }
     return false;
   }

   initCoordinatesFromGeoJsonCenter(coordinate) {
     if (coordinate != null && coordinate != undefined) {
       let coord = new Coordinate();
       coord.setLongitude(coordinate[0]);
       coord.setLatitude(coordinate[1]);
       if (coordinate.length > 2) {
         coord.setAltitude(coordinate[2])
       }
       this.coordinates[this.coordinates.length] = coord
     }
   }

   initCoordinatesFromGeoJsonCoordinates(coordinates) {
     if (this.coordinates==null || this.coordinates==undefined)
     {
       this.coordinates=[];
     }
     for (let i = 0; i < coordinates.length; i++) {
       let coordinate = new Coordinate();
       this.coordinates.push(coordinate);
       coordinate.setLongitude(coordinates[i][0]);
       coordinate.setLatitude(coordinates[i][1]);
       if (coordinates[i][2]) {
         coordinate.setAltitude(coordinates[i][2]);
       }
     }
   }

   validateCoordinates() {
     let errors = [];
     try {
       if (!this.coordinates) {
         errors.push("coordinates array is undefined.")
       }
       else {
         for (let i = 0; i < this.coordinates.length; i++) {
           if (!this.coordinates[i].getLongitude() && this.coordinates[i].getLongitude() !== 0) {
             errors.push("coordinates longitude is undefined.")
           }
           if (!this.coordinates[i].getLatitude() && this.coordinates[i].getLatitude() !== 0) {
             errors.push("coordinates latitude is undefined.")
           }
         }
       }
     }
     catch (exception) {
       let message = "Error occurred in validateCoordinates method in BaseGeometry class, Exception=" + exception;
       logger.error(message);
       errors.push(message);
     }
     return errors;
   }


   writeGeoToBuffer(isFixedPointsNum, geoPoints, isDeltaCalculation, kind) {
     try {
       let firstByte = this.convertBswGeoKindEnumToByte(this.getPositionType());
       let firstByteObj = {value: firstByte};
       let calcTileKind = (kind == tileCalcKind.BY_POINTS);

       let ptIdx = 0;

       let isZAware = geoPoints[ptIdx++].isZAware;
       while (isZAware == false && ptIdx < geoPoints.length) {
         isZAware = geoPoints[ptIdx].isZAware;
         ptIdx++;
       }

       //get the total number of bytes needed for this geometry shape
       //let geoBytesSize = this.calcGeoByteNum(geoPoints, isZAware, isFixedPointsNum);
       this.setHeaderAttribute(firstByteObj, isZAware, calcTileKind, isFixedPointsNum);
       let byteBuffer = [];// new Array(geoBytesSize);
       let idxToStartObj = {value: 0};
       byteBuffer[idxToStartObj.value] = firstByteObj.value;
       idxToStartObj.value++;

       //if the geometry doesn't have a fixed number of points - write it down
       if (isFixedPointsNum == false) {//there is a need for an int
         //write the number of points to the buffer
         IntToBytes.toBytes(byteBuffer, idxToStartObj, geoPoints.length);
       }

       if (isDeltaCalculation) {
         let deltaGeo = [];
         deltaGeo.push(geoPoints[0]);
         for (let i = 1; i < geoPoints.length; i++) {
           let deltaCoordinate = new Coordinate();
           deltaGeo.push(deltaCoordinate);
           deltaCoordinate.setLongitude(geoPoints[i].getLongitude() - geoPoints[i - 1].getLongitude());
           deltaCoordinate.setLatitude(geoPoints[i].getLatitude() - geoPoints[i - 1].getLatitude());
           if (geoPoints[i].getAltitude() && geoPoints[i - 1].getAltitude()) {
             deltaCoordinate.setAltitude(geoPoints[i].getAltitude() - geoPoints[i - 1].getAltitude());
           }
           if (geoPoints[i].getAltitude() && !geoPoints[i - 1].getAltitude()) {
             deltaCoordinate.setAltitude(geoPoints[i - 1].getAltitude());
           }
           if (!geoPoints[i].getAltitude() && geoPoints[i - 1].getAltitude()) {
             deltaCoordinate.setAltitude(0 - geoPoints[i - 1].getAltitude());
           }
         }
         //send the points to be converted
         for (let i = 0; i < deltaGeo.length; i++) {
           deltaGeo[i].toBytes(byteBuffer, idxToStartObj, isZAware, true);
         }
       }
       else {
         //send the points to be converted
         for (ptIdx = 0; ptIdx < geoPoints.length; ptIdx++) {
           geoPoints[ptIdx].toBytes(byteBuffer, idxToStartObj, isZAware, false);
         }
       }
       return byteBuffer;
     }
     catch (exception) {
       logger.error("Error occurred in writeGeoToBuffer method in BaseGeometry class.", exception);
     }
   }


   /**
    * Read the base class footer and increase the index value accordingly
    * @param bufferToRead - buffer to read
    * @param nextIndex - index pointed to next value to read
    */
   readFooter(bufferToRead, nextIndex) {
     if (bufferToRead != null && bufferToRead.length > 0 && (bufferToRead[0] & 16) == 16) { //check bit number 5 is turned on in first byte
       this.setIsSpline(false);
       if ((bufferToRead[nextIndex.value++] & 128) == 128) { //check if bit number 8 is turn on
         this.setIsSpline(true);
       }
     }
   }


   /**
    * write the baseGeometry footer
    * @param byteBuffer - byteArray to start writing the footers
    */
   writeFooter(byteBuffer) {
     if (IS_FOOTER_NEEDED == true) {
       let lastIndex = byteBuffer.length;
       let header = 0;
       if (this.getIsSpline() == true) {
         header = header | 128 //10000000
       }
       byteBuffer[lastIndex++] = header;
     }
     return byteBuffer;
   }

   setHeaderAttribute(header, isZAware, calcTileKind, fixedPointsNum) {
     try {
       //checking if the zAware flag is turned on
       if (isZAware == true) {//the flag is on
         //adding the flag
         header.value |= Z_AWARE_BIT_FLAG;
       }
       //checking if the geo is defined by points
       if (calcTileKind == true) {//by points
         header.value |= TILE_CALC_KIND_BIT_FLAG;
       }
       //check if the geo needs an extra int for the number of points
       if (fixedPointsNum == true) {//need an extra int
         header.value |= FIXED_POINTS_NUM_BIT_FLAG;
       }
       //turn on bit 5 (now we are working with footers)
       if (IS_FOOTER_NEEDED)
         header.value |= FOOTER_NEEDED_FLAG;
     }
     catch (exception) {
       logger.error("Error occurred in setHeaderAttribute method in BaseGeometry class.", exception);
     }
   }


   calcGeoByteNum(geoPoints, isZAware, fixedPointsNum) {
     try {
       let geoBytesSize = 0;
       //calculating the number of byte needed for the conversion
       geoBytesSize = geoPoints.length * this.sizeInBytes(isZAware);

       //check if the geo needs an extra int for the number of points
       if (fixedPointsNum == false) {//need an extra int
         geoBytesSize += SIZE_OF_INT;
       }
       return geoBytesSize;
     }
     catch (exception) {
       logger.error("Error occurred in calcGeoByteNum method in BaseGeometry class.", exception);
     }
   }

   sizeInBytes(isZAware) {
     try {
       //4 bytes for each coordinate is enough to save the coordinate and take the first bit to sing
       let ptSizeInBytes = (SIZE_OF_INT * 2);//////SIZE_OF_DOUBLE * 2;
       //check if the point has a defined altitude
       if (isZAware == true) {
         ptSizeInBytes += SIZE_OF_INT;
       }
       return ptSizeInBytes;
     }
     catch (exception) {
       logger.error("Error occurred in sizeInBytes method in BaseGeometry class.", exception);
     }
   }

   /**
    * Get the geometry extent, this will return an object with a { min, max } values.
    *
    * * @return An object with {min, max} if valid, else undefined.
    */
   getExtent() {
     let retVal = undefined;

     let posType = this.getPositionType();
     let coords = undefined;
     switch (posType) {
       case geoKind.Point.Name:
         retVal = {min: this.coordinates[0], max: this.coordinates[0]};
         break;
       case geoKind.Polygon.Name:
       case geoKind.Polyline.Name:
       case geoKind.Arrow.Name:
       case geoKind.Corridor.Name:
       case geoKind.TwoPoints.Name:
         coords = this.coordinates;
         break;

       default:
         let geo = this.getShapeFallback();
         if (geo && geo.coordinates && geo.coordinates.length > 0) {
           coords = geo.coordinates;
         }
         break;
     }

     if (coords) {
       let min = new Coordinate(Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER);
       let max = new Coordinate(Number.MIN_SAFE_INTEGER, Number.MIN_SAFE_INTEGER);

       for (let i = 0; i < coords.length; i++) {
         let currCoord = coords[i];

         if (currCoord.getLongitude() < min.getLongitude()) {
           min.setLongitude(currCoord.getLongitude());
         }
         if (currCoord.getLatitude() < min.getLatitude()) {
           min.setLatitude(currCoord.getLatitude());
         }
         if (currCoord.getLongitude() >= max.getLongitude()) {
           max.setLongitude(currCoord.getLongitude());
         }
         if (currCoord.getLatitude() >= max.getLatitude()) {
           max.setLatitude(currCoord.getLatitude());
         }
       }

       retVal = {min: min, max: max};
     }

     return retVal;
   }


   convertBswGeoKindEnumToByte(kind) {
     try {
       return (Math.round(Math.log2(geoKind[kind].value)));
     }
     catch (exception) {
       logger.error("Error occurred in convertBswGeoKindEnumToByte method in BaseGeometry class.", exception);
     }
   }


   readGeoFromBuffer(bufferToRead, idxToStartObj, expectedPointsNum, isDeltaCalculation) {

     try {
       let firstByte = bufferToRead[idxToStartObj.value++];
       let isZAware = ((firstByte & Z_AWARE_BIT_FLAG) == Z_AWARE_BIT_FLAG) ?
         true :
         false;

       //extracting from the first byte whether the geo has
       //defined altitude
       let isGeoByPoints = ((firstByte & TILE_CALC_KIND_BIT_FLAG) == TILE_CALC_KIND_BIT_FLAG) ?
         true :
         false;

       //extracting from the first byte whether the geo has
       //an extra int for the number of points passed
       let fixedPointsNum = ((firstByte & FIXED_POINTS_NUM_BIT_FLAG) == FIXED_POINTS_NUM_BIT_FLAG) ?
         true :
         false;

       if (fixedPointsNum == false) {//read the number of points the geo has
         expectedPointsNum = IntToBytes.fromBytes(bufferToRead, idxToStartObj, false);
         if (expectedPointsNum > MAX_NUMBER_OF_COORDINATES) {
           logger.error("Number of coordinates exceeded " + MAX_NUMBER_OF_COORDINATES + " !!! cant deserialze position");
           return [];
         }
       }

       //extracting the points from the buffer to bswPoint
       let geoPoints = [];// = new Coordinate[expectedPointsNum];
       for (let ptIdx = 0; ptIdx < expectedPointsNum; ptIdx++) {
         var coordinate = new Coordinate();
         geoPoints.push(coordinate);
         coordinate.fromBytes(bufferToRead, idxToStartObj, isZAware, isDeltaCalculation);
       }
       if (isDeltaCalculation) {
         for (let ptIdx = 1; ptIdx < geoPoints.length; ptIdx++) {
           geoPoints[ptIdx].setLongitude(geoPoints[ptIdx - 1].getLongitude() + geoPoints[ptIdx].getLongitude());
           geoPoints[ptIdx].setLatitude(geoPoints[ptIdx - 1].getLatitude() + geoPoints[ptIdx].getLatitude());
           geoPoints[ptIdx].setAltitude(geoPoints[ptIdx - 1].getAltitude() + geoPoints[ptIdx].getAltitude());
         }
       }
       return geoPoints;
     }
     catch (exception) {
       logger.error("Error occurred in readGeoFromBuffer method in BaseGeometry class.", exception);
     }
   }

   /**
    * Serialize the shape to string for CRC calculation
    * Should be identical to jGeo method.
    */
   toStringForCrc(){
     let center = this.getCenter();
     if(center)
      return center.toStringForCrc();
     else
       return null;
   }

 }
BaseGeometry.geographicLibrary={};
BaseGeometry.geometricLibrary={};

module.exports = {BaseGeometry};
