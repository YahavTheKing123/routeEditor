//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

const {IntToBytes} =require("../Convertors/intToBytes");
const { Logger } = require ('@elbit/logger-server');
const logger = Logger.getLogger("BngCoordinate");
const {Coordinate}=require("./coordinate");

class BngCoordinate extends Coordinate{

  constructor(longitude,latitude,altitude,squareFirst,squareSecond) {
    super(longitude,latitude,altitude);
    this.setSquareFirst(squareFirst);
    this.setSquareSecond(squareSecond);


  }


  clone() {
    let result = new BngCoordinate(this.getLongitude(), this.getLatitude(), this.getAltitude(),this.getSquareFirst(),
      this.getSquareSecond());
    return result;
  }


  /**
   * Square First
   * @return SquareFirst.
   */
  getSquareFirst() {
    return this.squareFirst;
  }

  /**
   * Square First
   */
  setSquareFirst(squareFirst) {
    this.squareFirst = squareFirst;
  }

  /**
   * Square Second
   * @return Square Second.
   */
  getSquareSecond() {
    return this.squareSecond;
  }

  /**
   * Square Second
   */
  setSquareSecond(squareSecond) {
    this.squareSecond = squareSecond;
  }



  fromBytes(bufferToRead, idxToStartObj, isZAware, isDeltaCalculation) {
  }


  toBytes(bufferToWrite, idxToStartObj, isZAware, isDeltaCalculation) {

  }

}

module.exports={BngCoordinate};
