//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

var coordSysConvertorLibrary= Object.freeze({
  undefined:0,
  mapCore:1
});
module.exports = {coordSysConvertorLibrary};
