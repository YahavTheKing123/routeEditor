//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

const {IntToBytes} =require("../Convertors/intToBytes");
const { Logger } = require ('@elbit/logger-server');
const logger = Logger.getLogger("Coordinate");

class Coordinate {

  constructor(longitude,latitude,altitude) {
    this.setLongitude(longitude);
    this.setLatitude(latitude);
    if (altitude) {
      this.setAltitude(altitude);
    }
  }

  static createCoordinate(longitude,latitude,altitude) {
    return new Coordinate(longitude, latitude, altitude)
  }

  static createCoordinate() {
    return new Coordinate()
  }

  clone() {
    let result = new Coordinate(this.getLongitude(), this.getLatitude(), this.getAltitude());
    return result;
  }

  /**
   * @deprecated
   * @param coordinate
   * @return {*}
   */
  cloneCoordinate(coordinate) {
    let result;
    if (coordinate != null && coordinate != undefined) {
      result = new Coordinate(coordinate.getLongitude(), coordinate.getLatitude(), coordinate.getAltitude())
    }
    return result;
  }

  /**
   * Longitude field, x in some systems.
   * @return Value in Geo Degrees.
   */
  getLongitude() {
    return this.longitude;
  }

  /**
   * Longitude field, x in some systems.
   */
  setLongitude(longitude) {
    this.longitude = longitude;
  }

  /**
   * Latitude field, y in some systems.
   * @return Value in Geo Degrees.
   */
  getLatitude() {
    return this.latitude;
  }

  /**
   * Latitude field, y in some systems.
   */
  setLatitude(latitude) {
    this.latitude = latitude;
  }

  /**
   * Altitude field, z in some systems.
   * @return Value in meters.
   */
  getAltitude() {
    return this.altitude;
  }

  /**
   * Altitude field, z in some systems.
   */
  setAltitude(altitude) {
    this.altitude = altitude;
  }


  get isZAware() {
    //if the altitude is undefined than enforce the zAware to be false
    if (this.getAltitude() == undefined) {
      return false;
    }
    return true;
  }

  set isZAware(value) {
    if (!value) {
      this.setAltitude(undefined);
    }
  }



  fromBytes(bufferToRead, idxToStartObj, isZAware, isDeltaCalculation) {
    try {
      this.setAltitude(undefined);
      this.setLongitude(IntToBytes.fromBytes(bufferToRead, idxToStartObj, isDeltaCalculation));
      this.setLatitude(IntToBytes.fromBytes(bufferToRead, idxToStartObj, isDeltaCalculation));
      if (isZAware == true) {
        this.setAltitude(IntToBytes.fromBytes(bufferToRead, idxToStartObj, isDeltaCalculation));
      }
    }
    catch (exception) {
      logger.error("Error occurred in fromBytes method in Coordinate class.", exception);
    }
  }


  equals(secondCoordinate)
  {
    function checkDistanceDifference(first, second, availableDeviation) {
      if (first != null && first != undefined && second != null && second != undefined) {
        let diff = Math.abs(first - second);
        if (diff >= availableDeviation) {
          return false;
        }
      }
      else {
        logger.error("Cant compare distance - one of the coordinates are equal to DOUBLE.MIN_VALUE (not initialized)");
        return false;
      }
      return true;
    }

    if (!secondCoordinate)
    {
      logger.error("Error occurred in toBytes method in Coordinate class. secondCoordinate is null or undefined")
      return false;
    }

    let isEqual=true;
    let first = this.getLongitude();
    let second = secondCoordinate.getLongitude();
    if (!checkDistanceDifference(first, second, LATITUDE_LONGITUDE_DISTANCE_DEVIATION)) {
      isEqual= false;
    }
    first = this.getLatitude();
    second = secondCoordinate.getLatitude();
    if (!checkDistanceDifference(first, second, LATITUDE_LONGITUDE_DISTANCE_DEVIATION)) {
      isEqual= false;
    }
    first = this.getAltitude();
    second = secondCoordinate.getAltitude();
    //if system work without altitude ignore it
    if ((first == null || first == undefined) &&
      (second == null || second == undefined)) {

    }
    else if (!checkDistanceDifference(first, second, ALTITUDE_DISTANCE_DEVIATION)) {
      isEqual= false;
    }
    return isEqual;
  }

  toBytes(bufferToWrite, idxToStartObj, isZAware, isDeltaCalculation) {
    try {
      // entering X to the byte array
      IntToBytes.toBytes(bufferToWrite, idxToStartObj, this.getLongitude(), isDeltaCalculation);

      // entering Y to the byte array
      IntToBytes.toBytes(bufferToWrite, idxToStartObj, this.getLatitude(), isDeltaCalculation);

      // if there is a legit entering Z to the byte array
      if (isZAware == true) {
        IntToBytes.toBytes(bufferToWrite, idxToStartObj, this.getAltitude(), isDeltaCalculation);
      }
      this.isZAware = isZAware;
    }
    catch (exception) {
      logger.error("Error occurred in toBytes method in Coordinate class.", exception);
    }
  }

  /**
   * Serialize the coordinate to string for CRC calculation
   * @returns {string}
   */
  toStringForCrc(){
    let z = "UNDEF";
    if (this.isZAware) {
      z = Math.floor(this.getAltitude()).toString();
    }
    let longitude = Coordinate.convertDegreeToStringForCrs(this.getLongitude());
    let latitude = Coordinate.convertDegreeToStringForCrs(this.getLatitude());
    return `${longitude},${latitude},${z}`;
  }

  /**
   * Serialize the coordinates array to string for CRC calculation
   * @returns {string}
   */
  static toStringForCrc(coordinates) {
    if(!coordinates || coordinates.length==0)
      return null;
    let s = "";
    for (let i = 0; i < coordinates.length; i++) {
      s += coordinates[i].toStringForCrc();
      s += ";";
    }
    return s;
  }

  /**
   * convert degree from coordinate to crc string - "12.34567" or "-12.34567"
   * Identical to function in jGeo, should get the same results!
   * @param num
   * @returns {string}
   */
  static convertDegreeToStringForCrs(degree) {
    const stringLength = 8;
    const degreePositive = Math.abs(degree);
    let numStr = degreePositive.toString();
    if (numStr.length > stringLength) {
      numStr = numStr.slice(0, stringLength);
    } else if (numStr.length < stringLength) {
      const zeroToAdd = stringLength - numStr.length;
      for (let i = 0; i < zeroToAdd; i++) {
        numStr += "0";
      }
    }

    if (degree < 0 ) {
      numStr = "-" + numStr;
    }
    return numStr;
  }


}

module.exports={Coordinate: Coordinate};
