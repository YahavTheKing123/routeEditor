//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

const datums = Object.freeze({
  UNDEFINED: -1,
  WGS84: 0,
  ED50: 1,
  OSGB:2,
  IRIS:3
});
module.exports = {datums};
