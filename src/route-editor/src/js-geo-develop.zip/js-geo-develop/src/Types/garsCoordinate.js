//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.


const { Logger } = require ('@elbit/logger-server');
const logger = Logger.getLogger("GarsCoordinate");

class GarsCoordinate{

  constructor(minute) {
    this.setMinute(minute);
  }


  clone() {
    return  new GarsCoordinate(this.getMinute());
  }


  /**
   * Square First
   * @return SquareFirst.
   */
  getMinute() {
    return this.minute;
  }

  /**
   * Square First
   */
  setMinute(minute) {
    this.minute = minute;
  }


  fromBytes(bufferToRead, idxToStartObj, isZAware, isDeltaCalculation) {
  }


  toBytes(bufferToWrite, idxToStartObj, isZAware, isDeltaCalculation) {

  }

}

module.exports={GarsCoordinate};
