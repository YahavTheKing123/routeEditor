//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 25/10/2017.
 */


var geoKind =
  {
    Point: {value: 1, Name: "Point"},
    Polyline: {value: 2, Name: "Polyline"},
    Polygon: {value: 4, Name: "Polygon"},
    Ellipse: {value: 16, Name: "Ellipse"},
    Circle: {value: 32, Name: "Circle"},
    Sector: {value: 64, Name: "Sector"},
    TwoPoints: {value: 128, Name: "TwoPoints"},
    Arc: {value: 256, Name: "Arc"},
    Arrow: {value: 512, Name: "Arrow"},
    Rectangle: {value: 1024, Name: "Rectangle"},
    GeoCamera: {value: 2048, Name: "GeoCamera"},
    Corridor: {value: 8192, Name: "Corridor"},
  };


module.exports = {geoKind};
