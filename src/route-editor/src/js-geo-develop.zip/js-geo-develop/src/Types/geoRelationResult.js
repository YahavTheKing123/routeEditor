//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

class GeoRelationResult {
  constructor() {
    this.intersectionPoints = null;
    this.nearestDistance = null;
  }
}

module.exports = {GeoRelationResult};
