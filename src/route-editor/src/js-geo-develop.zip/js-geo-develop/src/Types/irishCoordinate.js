//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

const {IntToBytes} =require("../Convertors/intToBytes");
const { Logger } = require ('@elbit/logger-server');
const logger = Logger.getLogger("BngCoordinate");
const {Coordinate}=require("./coordinate");

class IrishCoordinate extends Coordinate{

  constructor(longitude,latitude,altitude,letter) {
    super(longitude,latitude,altitude);
    this.setLetter(letter);

  }


  clone() {
    let result = new BngCoordinate(this.getLongitude(), this.getLatitude(), this.getAltitude(),this.getLetter());
    return result;
  }


  /**
   * Square First
   * @return SquareFirst.
   */
  getLetter() {
    return this.letter;
  }

  /**
   * Square First
   */
  setLetter(letter) {
    this.letter = letter;
  }


  fromBytes(bufferToRead, idxToStartObj, isZAware, isDeltaCalculation) {
  }


  toBytes(bufferToWrite, idxToStartObj, isZAware, isDeltaCalculation) {

  }

}

module.exports={IrishCoordinate};
