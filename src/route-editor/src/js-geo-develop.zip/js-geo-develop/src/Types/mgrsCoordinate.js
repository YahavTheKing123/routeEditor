//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

const {IntToBytes} =require("../Convertors/intToBytes");
const { Logger } = require ('@elbit/logger-server');
const logger = Logger.getLogger("MgrsCoordinate");
const {Coordinate}=require("./coordinate");

class MgrsCoordinate extends Coordinate{

  constructor(longitude,latitude,altitude,squareFirst,squareSecond,band,zone) {
    super(longitude,latitude,altitude);
    this.setSquareFirst(squareFirst);
    this.setSquareSecond(squareSecond);
    this.setBand(band);
    this.setZone(zone);

  }


  clone() {
    let result = new MgrsCoordinate(this.getLongitude(), this.getLatitude(), this.getAltitude(),this.getSquareFirst(),
      this.getSquareSecond(),this.getBand(),this.getZone());
    return result;
  }


  /**
   * Square First
   * @return SquareFirst.
   */
  getSquareFirst() {
    return this.squareFirst;
  }

  /**
   * Square First
   */
  setSquareFirst(squareFirst) {
    this.squareFirst = squareFirst;
  }

  /**
   * Square Second
   * @return Square Second.
   */
  getSquareSecond() {
    return this.squareSecond;
  }

  /**
   * Square Second
   */
  setSquareSecond(squareSecond) {
    this.squareSecond = squareSecond;
  }

  /**
   * Band
   * @return Band.
   */
  getBand() {
    return this.band;
  }

  /**
   * Square First
   */
  setBand(band) {
    this.band = band;
  }

  /**
   * Zone
   * @return SquareFirst.
   */
  getZone() {
    return this.zone;
  }

  /**
   * Square First
   */
  setZone(zone) {
    this.zone = zone;
  }



  fromBytes(bufferToRead, idxToStartObj, isZAware, isDeltaCalculation) {
    try {
      this.setAltitude(undefined);
      this.setLongitude(IntToBytes.fromBytes(bufferToRead, idxToStartObj, isDeltaCalculation));
      this.setLatitude(IntToBytes.fromBytes(bufferToRead, idxToStartObj, isDeltaCalculation));
      if (isZAware == true) {
        this.setAltitude(IntToBytes.fromBytes(bufferToRead, idxToStartObj, isDeltaCalculation));
      }
    }
    catch (exception) {
      logger.error("Error occurred in fromBytes method in Coordinate class.", exception);
    }
  }


  toBytes(bufferToWrite, idxToStartObj, isZAware, isDeltaCalculation) {
    try {
      // entering X to the byte array
      IntToBytes.toBytes(bufferToWrite, idxToStartObj, this.getLongitude(), isDeltaCalculation);

      // entering Y to the byte array
      IntToBytes.toBytes(bufferToWrite, idxToStartObj, this.getLatitude(), isDeltaCalculation);

      // if there is a legit entering Z to the byte array
      if (isZAware == true) {
        IntToBytes.toBytes(bufferToWrite, idxToStartObj, this.getAltitude(), isDeltaCalculation);
      }
      this.isZAware = isZAware;
    }
    catch (exception) {
      logger.error("Error occurred in toBytes method in Coordinate class.", exception);
    }
  }

}

module.exports={MgrsCoordinate};
