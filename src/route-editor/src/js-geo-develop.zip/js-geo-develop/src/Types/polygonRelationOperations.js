//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

var polygonRelationOperations= Object.freeze({
  undefined:0,
  contain:1,
  contained:2,
  intersect:3,
  overlap:4
});
module.exports = {polygonRelationOperations};
