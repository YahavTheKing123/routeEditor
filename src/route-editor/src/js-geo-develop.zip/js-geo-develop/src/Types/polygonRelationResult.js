//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

class PolygonRelationResult {
  constructor() {
    this.operation = null;
    this.operationResult = null
    this.intersectionPoints = null;
  }
}

module.exports = {PolygonRelationResult};
