//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

var returnTypeEnum = Object.freeze({
  customGeoObject: 0,
  geoJson: 1,
  geoJsonPlusPlus: 2,
  geoJsonPlusPlusOnly: 3
});
module.exports = {returnTypeEnum};
