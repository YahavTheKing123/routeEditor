//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

/**
 * Created by tc34837 on 26/10/2017.
 */
var tileCalcKind=
    {
        BY_EXTENT: 0,
        BY_POINTS: 1
    };
module.exports = {tileCalcKind};
