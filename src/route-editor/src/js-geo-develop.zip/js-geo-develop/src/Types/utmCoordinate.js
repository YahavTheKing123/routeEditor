//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

const {Coordinate} = require("./coordinate");

class UtmCoordinate extends Coordinate {

  constructor(longitude, latitude, altitude, zone) {
    super(longitude, latitude, altitude);
    this.setZone(zone);

  }


  clone() {
    let result = new UtmCoordinate(this.getLongitude(), this.getLatitude(), this.getAltitude(), this.getZone());
    return result;
  }


  /**
   * Zone
   * @return SquareFirst.
   */
  getZone() {
    return this.zone;
  }

  /**
   * Square First
   */
  setZone(zone) {
    this.zone = zone;
  }

}

module.exports = {UtmCoordinate};
