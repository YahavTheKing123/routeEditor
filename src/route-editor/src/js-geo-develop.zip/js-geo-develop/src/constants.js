//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

const {geographicLibrary} = require("./Types/geographicLibrary");
const {geometricLibrary} = require("./Types/geometricLibrary");
const {coordSysConvertorLibrary} = require("./Types/coordSysConvertorLibrary");
const {datums} = require("./Types/datums");
const azimuthTypes = require("./Types/azimuthTypes");

/**
 * Created by tc34837 on 07/11/2017.
 */
global.Z_AWARE_BIT_FLAG = 128;
global.TILE_CALC_KIND_BIT_FLAG = 64;
global.FIXED_POINTS_NUM_BIT_FLAG = 32;
global.FOOTER_NEEDED_FLAG = 16;
global.IS_FOOTER_NEEDED = true;
global.SIZE_OF_INT = 4;
global.SECOND_BYTE = 1;
global.THIRD_BYTE = 2;
global.FOURTH_BYTE = 3;
global.ONE_BYTE_OFFSET = 8;
global.TWO_BYTE_OFFSET = 16;
global.THREE_BYTE_OFFSET = 24;
global.FOUR_BYTE_OFFSET = 32;
global.TWO_BYTES_LOWER_RANGE = 0;
global.TWO_BYTES_UPPER_RANGE_MINUS_TWO_BIT = 16383;
global.NUM_OF_POINTS = 1;
global.POINT_IDX = 0;
global.Z_AWARE_BIT_FLAG = 128;// turning on the last bit
global.TILE_CALC_KIND_BIT_FLAG = 64;// turning on the 7th bit
global.FIXED_POINTS_NUM_BIT_FLAG = 32;// turning on the 6th bit
global.isDebugEnabled = false;
global.FACTOR = 1000000;
global.ALTITUDE_FACTOR = 100;
global.ORIENTATION_FACTOR = 1000;
global.LATITUDE_LONGITUDE_DISTANCE_DEVIATION = 0.000001;
global.ALTITUDE_DISTANCE_DEVIATION = 0.01;
global.GEOGRAPHIC_LIBRARY = geographicLibrary.mapCore;
global.GEOMETRIC_LIBRARY = geometricLibrary.mapCore;
global.COORD_SYS_CONVERTOR_LIBRARY = coordSysConvertorLibrary.mapCore;
global.GEOGRAPHIC_LIBRARY_DATUM = datums.WGS84;
global.AZIMUTH_JSGEO = azimuthTypes.GEO;
global.NUM_POLYGON_POINTS = 64;
global.SPLINE_LEVEL = process.env.SPLINE_LEVEL? process.env.SPLINE_LEVEL: 5;
global.IS_GEO_LIBRARY_NEEDED = JSON.parse(process.env.IS_GEO_LIBRARY_NEEDED || false);
global.MAX_NUMBER_OF_COORDINATES = process.env.MAX_NUMBER_OF_COORDINATES? process.env.MAX_NUMBER_OF_COORDINATES: 5000;
global.IS_GEO_VALIDATION_FAIL_EXECUTION = JSON.parse(process.env.IS_GEO_VALIDATION_FAIL_EXECUTION || false);
global.IS_GEO_VALIDATION_ACTIVE = JSON.parse(process.env.IS_GEO_VALIDATION_ACTIVE ? process.env.IS_GEO_VALIDATION_ACTIVE : true);
global.IS_SPLINE_FUNCTIONALITY_ENABLED = JSON.parse(process.env.IS_SPLINE_FUNCTIONALITY_ENABLED ? process.env.IS_SPLINE_FUNCTIONALITY_ENABLED : true);
