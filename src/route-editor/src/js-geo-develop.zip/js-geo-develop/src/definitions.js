const azimuthTypes = require('./Types/azimuthTypes');

const {Logger} = require('@elbit/logger-server');
const {CoordSysConvertor} = require("./Convertors/coordSysConvertor");
const logger = Logger.getLogger("GeoHelper");
const Constant = require("./constants");

class Definitions {
  constructor() {
    this.setAzimuthTypeFromEnv(process.env.AZIMUTH_TYPE);
  }

  setAzimuthType(azimuth) {
    this.azimuthClient = azimuth;
    console.log("set azimuth type: " + this.azimuthClient);
  }

  setAzimuthTypeFromEnv(azimuth) {
    if (azimuth !== undefined) {
      azimuth = azimuth.toString().toLocaleLowerCase();
      switch (azimuth) {
        case "geo":
          this.azimuthClient = azimuthTypes.GEO;
          break;
        case "grid":
          this.azimuthClient = azimuthTypes.GRID;
          break;
        default:
          break;
      }
    } else {
      this.azimuthClient = azimuthTypes.GRID;
    }
    console.log("set azimuth type: " + this.azimuthClient);
  }

  getAzimuthClient() {
    return this.azimuthClient;
  }

  isNodeEnvironment(){
    return Object.prototype.toString.call(global.process) === '[object process]';
  }
}

let definitions = new Definitions();
module.exports = definitions;
