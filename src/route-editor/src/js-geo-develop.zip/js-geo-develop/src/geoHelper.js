const {crc8} = require('crc');
const {crc16} = require('crc');
const {crc32} = require('crc');
const {CustomGeoConverter} = require("./Convertors/customGeoConverter");
const {Logger} = require('@elbit/logger-server');
const logger = Logger.getLogger("GeoHelper");

class GeoHelper {

  static isGeoJsonObject(value) {
    if ((typeof value) == "object" &&
      ((value.type != null && value.type != undefined) || (value.Feature != null && value.Feature != undefined)) //if geoJson
      && !GeoHelper.isCustomGeoObject(value)) //if its NOT CustomGeoObject
    {
      return true;
    }
    return false;
  }

  static isGeoJsonPlusPlusObject(value) {
    if ((typeof value) == "object" &&
      (value.shape != null && value.shape != undefined)  //if geoJson++
      && !GeoHelper.isCustomGeoObject(value)) {  //if its NOT CustomGeoObject
      return true;
    }
    return false;
  }

  static isCustomGeoObject(value) {
    if (value.isCustomGeoObject != null && value.isCustomGeoObject != undefined) {
      return true;
    }
    return false;
  }


  static isAnyGeoJsonString(value) {
    if (((typeof value) == "string") && value.indexOf('{') == 0)//if start with '{' -> its geoJson\geoJson++ as string
    {
      return true;
    }
    return false;
  }

  static isBaseGeometryString(value) {
    if (((typeof value) == "string") && value.indexOf('{') == 0)//if start with '{' -> its geoJson\geoJson++ as string
    {
      let geometry = JSON.parse(value);
      if (geometry.isCustomGeoObject)
        return true;
    }
    return false;
  }

  static convertGeoJsonToBaseGeometryShape(input) {
    logger.trace("Starting conversion to baseGeometry");
    // inputs can be:
    // base64 -- return as is.
    // geoJson/geoJson++/geoJson++only as string - return as BaseGeometry
    // geoJson/geoJson++/geoJson++only as object - return as BaseGeometry
    // null - return null
    // baseGeometry - return as BaseGeometry
    function addFeatureToGeoJson(input) {
      input.geometry = {};
      input.geometry.type = input.type;
      input.geometry.coordinates = input.coordinates;
      input.type = "Feature";

      //some shapes using coordinates as actual geoJson++only property so for these cases we will not delete it.
      if (input.shape) {
        let shape = input.shape.toLowerCase();
        if (!(shape == "arrow" || shape == "corridor" || shape == "point" || shape == "polygon" || shape == "linestring")) {
          delete input.coordinates;
        }
      }
      return input;
    }

    let result;
    try {
      if (input == null || input == undefined) {
        logger.error("Cant convert to baseGeometry shapinput is null or undefined!");
        return null;
      }

      if (((typeof input) == "string")) {
        if (input.indexOf('{') != 0) {//if base64 string
          return input;
        } else {
          input = JSON.parse(input)
        }
      }


      if (input.isCustomGeoObject) { //if its already baseGeometry - return it
        return input;
      }

      //if geoJson\geoJson++ arrive without geometry property, change it to our supported format ( {type:feature + geometry:{type:point\polygon\polyline , coordinates:...}})
      if (!input.geometry &&
        input.type && input.coordinates &&
        ((input.type.toLowerCase() === "Point".toLowerCase()) ||
          (input.type.toLowerCase() === "Polygon".toLowerCase()) ||
          (input.type.toLowerCase() === "LineString".toLowerCase()))) {
        input = addFeatureToGeoJson(input);
      }

      //take shape\type in order to convert from correct shape
      let type = undefined;
      if (input.shape) {
        type = input.shape;
      } else {
        type = input.geometry.type;
      }

      if (type) {
        result = CustomGeoConverter.convertToBaseGeometryShape(type, input)
      } else {
        logger.error("type/shape properties not exists, conversion not done.")
      }

    } catch (exception) {
      logger.error("Error occurred in GeoHelper.convertToSetPositionInputToBaseGeometry.", exception);
    }
    return result;
  }

  static convertCoordinatesArrayToGeoJsonCoordinates(coordinates) {
    let result;
    try {
      if (coordinates != null && coordinates != undefined) {
        result = [];
        for (let i = 0; i < coordinates.length; i++) {
          result[i] = [];
          result[i].push(coordinates[i].longitude);
          result[i].push(coordinates[i].latitude);
          result[i].push(coordinates[i].altitude);
        }
      } else {
        logger.error("Input should be coordinate array (taken from BaseGeometry class)");
      }
    } catch (exception) {
      logger.error("Error occurred in GeoHelper.convertCoordinatesArrayToGeoJsonCoordinates.", exception);
    }
    return result;
  }

  /**
   * Calculate crc for center of base geometry
   * Identical to function in jGeo, should get the same results!
   * @param baseGeo
   * @returns {null|*}
   */
  static calculateStringCrc4Geo(baseGeo) {
    if(!baseGeo)
      return null;
    let crcStr = baseGeo.toStringForCrc();
    //console.log(crcStr);
    return GeoHelper.calculateStringCrc(crcStr);
  }

  /**
   * Calculate crc for center of base geometry
   * Identical to function in jGeo, should get the same results!
   * @param baseGeo
   * @returns {null|*}
   */
  static calculateLongCrc4Geo(baseGeo) {
    if(!baseGeo)
      return 0;
    let crcStr = baseGeo.toStringForCrc();
    //console.log(crcStr);
    return GeoHelper.calculateLongCrc(crcStr);
  }

  /**
   * Calculate crc for any string
   * @param baseGeo
   * @returns {null|*}
   */
  static calculateStringCrc(str) {
    if(!str)
      return null;
    if(str.length<30)
      return crc8(str).toString(16);
    else if(str.length<100)
      return crc16(str).toString(16);
    else
      return crc32(str).toString(16);
  }

  /**
   * Calculate crc for any string
   * @param baseGeo
   * @returns {null|*}
   */
  static calculateLongCrc(str) {
    if(!str)
      return 0;
    if(str.length<30)
      return crc8(str);
    else if(str.length<100)
      return crc16(str);
    else
      return crc32(str);
  }

  /**
   * validate crc are equals
   * @param crcOld
   * @param crcNew
   * @returns {boolean}
   */
  static validateCrc(crcOld, crcNew) {
    return crcOld === crcNew;
  }

  //********************************************************
  // Old position CRC calculation methods, left for backwards compatibility

  /**
   * Calculate crc for center of base geometry
   * @param baseGeo
   * @returns {null|*}
   */
  static calculateCrc(baseGeo) {
    const center = baseGeo.getCenter();
    if (center) {
      let z = "UNDEF";
      if (center.isZAware) {
        z = center.getAltitude().toString();
      }
      const longitude = this.convertDegreeToStringForCrs(center.getLongitude());
      const latitude = this.convertDegreeToStringForCrs(center.getLatitude());
      const crcStr = `${longitude},${latitude},${z}`;
      return crc8(crcStr).toString(16);
    } else {
      logger.error("CalculateCrc failed - no center")
    }
    return null;
  }

  /**
   * convert degree from coordinate to crc string - "12.34567" or "-12.34567"
   * @param num
   * @returns {string}
   */
  static convertDegreeToStringForCrs(degree) {
    const stringLength = 8;
    const degreePositive = Math.abs(degree);
    let numStr = degreePositive.toString();
    if (numStr.length > stringLength) {
      numStr = numStr.slice(0, stringLength);
    } else if (numStr.length < stringLength) {
      const zeroToAdd = stringLength - numStr.length;
      for (let i = 0; i < zeroToAdd; i++) {
        numStr += "0";
      }
    }

    if (degree < 0 ) {
      numStr = "-" + numStr;
    }
    return numStr;
  }

  //********************************************************

}



module
  .exports = {GeoHelper};
