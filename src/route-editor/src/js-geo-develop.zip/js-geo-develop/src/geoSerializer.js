//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

const {GeoJsonConverter} = require("./Convertors/geoJsonConverter");
const {CustomGeoConverter} = require("./Convertors/customGeoConverter");
const {Polygon} = require("./Shapes/polygon");
const {BaseGeometry} = require("./Types/baseGeometry");
const {Polyline} = require("./Shapes/polyline");
const {Point} = require("./Shapes/point");
const {Circle} = require("./Shapes/circle");
const {Ellipse} = require("./Shapes/ellipse");
const {Rectangle} = require("./Shapes/rectangle");
const {Sector} = require("./Shapes/sector");
const {Coordinate} = require("./Types/coordinate");
const {Corridor} = require("./Shapes/corridor");
const {Arrow} = require("./Shapes/arrow");
const {Arc} = require("./Shapes/arc");
const {GeoCamera} = require("./Shapes/geoCamera");
const {TwoPoints} = require("./Shapes/twoPoints");
const {geoKind} = require("./Types/geoKind");
const {returnTypeEnum} = require("./Types/returnTypeEnum");
const {Logger} = require('@elbit/logger-server');
const logger = Logger.getLogger("GeoSerializer");
const Constant = require("./constants");
const {UrlSafeEncoding} = require('@elbit/helper');
const {GeoHelper} = require('./geoHelper');
const {validator}=require("@elbit/position-validator");

let positionToCustomGeoCache = {};
let last5Positions = [];
logger.info("global.IS_GEO_LIBRARY_NEEDED = "+ global.IS_GEO_LIBRARY_NEEDED);
logger.info("global.IS_GEO_VALIDATION_FAIL_EXECUTION = "+ global.IS_GEO_VALIDATION_FAIL_EXECUTION);
logger.info("global.IS_GEO_VALIDATION_ACTIVE = "+ global.IS_GEO_VALIDATION_ACTIVE);

class GeoSerializer {

  static getPositionToCustomGeoCache() {
    return positionToCustomGeoCache;
  }

  static getLast5() {
    return last5Positions;
  }

  /**
   * @deprecated Use setPosition instead!
   * this methof serializae position object to base64 string
   * message - can be inner geo object (Polygon,Point,etc...) OR GeoJson object\string
   * returnAsBase64 - indicates if output should be byteArray or base64 (default)
   */
  static serialize(message, returnAsBase64) {
    try {
      if (returnAsBase64 == undefined) {
        returnAsBase64 = true;
      }
      if (message) {
        this.setCorrectPrototype(message);
        let isValid = GeoSerializer.validateData(message);
        if (isValid == false  && IS_GEO_VALIDATION_FAIL_EXECUTION == true) {
          return null;
        }
        //here we have messageAsObject as valid custom geo object
        let clonedMessage = message.clone();
        let byteArray = clonedMessage.toBytes();
        if (returnAsBase64) {
          //make base64 safe-base64 for url
          let validUrlBase64 = UrlSafeEncoding.encodeToUrlSafe(byteArray);
          return validUrlBase64;
        } else {
          return byteArray;
        }
      }
    } catch (exception) {
      logger.error("Error occurred in serialize method in GeoSerializer class.", exception);
    }
  }


  static setCorrectPrototype(message) {
    if (message != undefined && message != null) {
      if (message.type != undefined && message.type != null) {
        switch (message.type) {
          case geoKind.Point.Name: {
            if (message.__proto__ != Point.prototype) {
              message.__proto__ = Point.prototype;
            }
            break;
          }
          case geoKind.Polygon.Name: {
            if (message.__proto__ != Polygon.prototype) {
              message.__proto__ = Polygon.prototype;
            }
            break;
          }
          case geoKind.Polyline.Name: {
            if (message.__proto__ != Polyline.prototype) {
              message.__proto__ = Polyline.prototype;
            }
            break;
          }
          case geoKind.Ellipse.Name: {
            if (message.__proto__ != Ellipse.prototype) {
              message.__proto__ = Ellipse.prototype;
            }
            break;
          }
          case geoKind.Circle.Name: {
            if (message.__proto__ != Circle.prototype) {
              message.__proto__ = Circle.prototype;
            }
            break;
          }
          case geoKind.Rectangle.Name: { //GeoJson++
            if (message.__proto__ != Rectangle.prototype) {
              message.__proto__ = Rectangle.prototype;
            }
            break;
          }
          case geoKind.Sector.Name: { //GeoJson++
            if (message.__proto__ != Sector.prototype) {
              message.__proto__ = Sector.prototype;
            }
            break;
          }
          case geoKind.Corridor.Name: { //GeoJson++
            if (message.__proto__ != Corridor.prototype) {
              message.__proto__ = Corridor.prototype;
            }
            break;
          }
          case geoKind.Arrow.Name: { //GeoJson++
            if (message.__proto__ != Arrow.prototype) {
              message.__proto__ = Arrow.prototype;
            }
            break;
          }
          case geoKind.Arc.Name: { //GeoJson++
            if (message.__proto__ != Arc.prototype) {
              message.__proto__ = Arc.prototype;
            }
            break;
          }
          case geoKind.GeoCamera.Name: { //GeoJson++
            if (message.__proto__ != GeoCamera.prototype) {
              message.__proto__ = GeoCamera.prototype;
            }
            break;
          }
          case geoKind.TwoPoints.Name: { //GeoJson++
            if (message.__proto__ != TwoPoints.prototype) {
              message.__proto__ = TwoPoints.prototype;
            }
            break;
          }
        }


        if (message.coordinates != undefined && message.coordinates != null) {
          for (let i = 0; i < message.coordinates.length; i++) {
            if (message.coordinates[i].__proto__ != Coordinate.prototype) {
              message.coordinates[i].__proto__ = Coordinate.prototype;
            }

          }
        }
      }
    }
  }


  /**
   * @deprecated Use getPosition instead!
   * geometryAsByteArrayOrBase64 - can be inner geo object (Polygon,Point,etc...) OR geoJson
   * returnType (type of returnTypeEnum)- indicates the requested return type (can be customGeoObject,GeoJson,GeoJson++ or GeoJsonOnly)
   * inputAsBase64 - base64 string that represents the position.
   */
  static deserialize(geometryAsByteArrayOrBase64, returnType, inputAsBase64) {

    function fromBytes(bufferToRead, currIdx) {

      function getGeoEnumType(firstByte) {
        try {
          //read bits 1-4 to reveal geoKind
          var geoKindPart = (firstByte & 15); //00001111
          return Math.pow(2, geoKindPart);
        } catch (exception) {
          logger.error("Error occurred in getGeoEnumType method in GeoSerializer class.", exception);
        }
      }

      try {
        let retGeometry;
        let firstByte = bufferToRead[currIdx];
        var geoKindIdentifier = getGeoEnumType(firstByte);
        if (geoKindIdentifier) {
          //call correct child according to first byte
          switch (geoKindIdentifier) {
            case geoKind.Point.value: {
              retGeometry = new Point().fromBytes(bufferToRead, currIdx);
              break;
            }
            case geoKind.Circle.value: {
              retGeometry = new Circle().fromBytes(bufferToRead, currIdx);
              break;
            }
            case geoKind.Rectangle.value: {
              retGeometry = new Rectangle().fromBytes(bufferToRead, currIdx);
              break;
            }
            case geoKind.Sector.value: {
              retGeometry = new Sector().fromBytes(bufferToRead, currIdx);
              break;
            }
            case geoKind.Corridor.value: {
              retGeometry = new Corridor().fromBytes(bufferToRead, currIdx);
              break;
            }
            case geoKind.Arrow.value: {
              retGeometry = new Arrow().fromBytes(bufferToRead, currIdx);
              break;
            }
            case geoKind.Arc.value: {
              retGeometry = new Arc().fromBytes(bufferToRead, currIdx);
              break;
            }
            case geoKind.Polygon.value: {
              retGeometry = new Polygon().fromBytes(bufferToRead, currIdx);
              break;
            }
            case geoKind.Polyline.value: {
              retGeometry = new Polyline().fromBytes(bufferToRead, currIdx);
              break;
            }
            case geoKind.Ellipse.value: {
              retGeometry = new Ellipse().fromBytes(bufferToRead, currIdx);
              break;
            }
            case geoKind.GeoCamera.value: {
              retGeometry = new GeoCamera().fromBytes(bufferToRead, currIdx);
              break;
            }
            case geoKind.TwoPoints.value: {
              retGeometry = new TwoPoints().fromBytes(bufferToRead, currIdx);
              break;
            }
          }
        } else {
          logger.error("geoKindIdentifier is null or undefined.");
        }
        return retGeometry;
      } catch (exception) {
        logger.error("Error occurred in fromBytes method in GeoSerializer class.", exception);
      }
    }

    try {
      if (inputAsBase64 == undefined) {
        inputAsBase64 = true;
      }

      if (geometryAsByteArrayOrBase64) {
        if (inputAsBase64) {
          geometryAsByteArrayOrBase64 = UrlSafeEncoding.decodeFromUrlSafe(geometryAsByteArrayOrBase64);
        }
        let innerShape = fromBytes(geometryAsByteArrayOrBase64, 0);
        if (returnType != returnTypeEnum.customGeoObject) {
          return GeoJsonConverter.convertToGeoJson(innerShape, returnType);
        } else {
          return innerShape;
        }
      } else {
        logger.error("byte array is null or undefined, cant serialize");
      }
    } catch (exception) {
      logger.error("Error occurred in deserialize method in GeoSerializer class.", exception);
    }
  }

  /**
   * This method get position as string\object and return result per user request
   * @param positionInput - the position as geoJson\geoJson++\geoJson++Only. type can be string or object
   * @param returnType (type of returnTypeEnum)- indicates the return result type,
   * @return {will return customGeoObject,GeoJson,GeoJson++ or GeoJsonOnly. according to returnType parameter}
   */
  static deserializePosition(positionInput, returnType) {
    try {
      if (returnType == null || returnType == undefined) {
        returnType = returnTypeEnum.customGeoObject;
      }
      if (!positionInput) {
        let stackTrace = "not available";
        try {
          stackTrace = new Error().stack;
        } catch (e) {
          logger.error("Could not load stack trace.")
        }
        logger.error("deserializePosition method in GeoSerializer class failed - input is null or undefined, stack trace: " + stackTrace);
        return null;
      }

      //if input is CustomGeoObject, return it as user requested
      if (positionInput instanceof BaseGeometry) {
        //cast the result to what user requested in 'returnType' params
        if (returnType != returnTypeEnum.customGeoObject) {
          return GeoJsonConverter.convertToGeoJson(positionInput, returnType);
        } else {
          return positionInput;
        }
      }
      //if its base64 we need to deserialize
      if (((typeof positionInput) == "string") && positionInput.indexOf('{') != 0) {
        //if its base64 string, we need to deserialize it
      }
      else {
        //if its geoJson\geoJson++\geoJson++Only input (can be string or object), we will try to convert it to baseGeometry without deserialize
        let result = GeoHelper.convertGeoJsonToBaseGeometryShape(positionInput);
        if (result) {
          if (result.isCustomGeoObject) { //if the input comes as baseGeometry object, not baseGeometry class (can happen if someone enter baseGeometry as input to query and then it will arrive as object and not BaseGeometry class)
            this.setCorrectPrototype(result);
          }
          //cast the result to what user requested in 'returnType' params
          if (returnType != returnTypeEnum.customGeoObject) {
            return GeoJsonConverter.convertToGeoJson(result, returnType);
          } else {
            return result;
          }
        } else {
          logger.error("deserializePosition method in GeoSerializer class failed - conversion returned " + result);
          return null;
        }
      }

      ////////
      //if we geo here = the input is base64 and need to de-serialized
      ////////

      //handle cache collection
      let positionCache = this.getPositionToCustomGeoCache();
      if (positionCache[returnType] && positionCache[returnType][positionInput]) {
        if (returnType == returnTypeEnum.customGeoObject) {
          return positionCache[returnType][positionInput].clone();
        } else {
          return positionCache[returnType][positionInput];
        }
      }
      let shape = this.deserialize(positionInput, returnType, true);
      let isValid = GeoSerializer.validateData(shape);
      if (isValid == false && IS_GEO_VALIDATION_FAIL_EXECUTION == true) {
        return null;
      }
      if (!positionCache[returnType]) {
        positionCache[returnType] = {};
      }
      positionCache[returnType][positionInput] = shape;

      //handle 'last 5' mechanism
      let last5Collection = this.getLast5();
      if (!last5Collection[returnType]) {
        last5Collection[returnType] = [];
      }
      last5Collection[returnType].push(positionInput);
      if (last5Collection[returnType].length > 5) { //if more then 5 after push --> cut the first from last5Collection and delete it from cache
        delete positionCache[returnType][last5Collection[returnType][0]];
        last5Collection[returnType].splice(0, 1);
      }
      if (returnType == returnTypeEnum.customGeoObject) {
        return shape.clone();
      }
      return shape;
    } catch (exception) {
      logger.error("deserializePosition method in GeoSerializer class failed.", exception);
    }
  }

  static validateData(objectToValidate) {
    if (IS_GEO_VALIDATION_ACTIVE) {
      try {
        logger.trace("validate position started");
        let result = validator.validateData(objectToValidate, {shouldPrintExtraData: true});
        if (result) {
          if (result.internalError) {
            logger.error("Internal Validation errors: " + JSON.stringify(result.internalError, null, 4));
            return false;
          }
          if (result.schemaValidationErrors) {
            logger.error("Schema Validation Errors: " + JSON.stringify(result.schemaValidationErrors, null, 4));
            return false;
          }
        } else {
          logger.error("validation result returned as null or undefined!");
          return false;
        }
      } catch (e) {
        logger.error("Exception occurred in validateData method. Exception: " + e);
        return false;
      } finally {
        logger.trace("validate position finished successfully");
        return true;
      }
    } else {
      return true;
    }
  }

  /**
   * This method get position as base64 string or as CustomGeoObject and return it as base64 representation.
   * @param positionObject - the position as base64 string or as CustomGeoObject
   * @return {base64 string}
   */
  static serializePosition(positionObject) {
    try {
      let base64;
      if (!positionObject)
      {
        let stackTrace = "not available";
        try {
          stackTrace = new Error().stack;
        } catch (e) {
          logger.error("Could not load stack trace.")
        }
        logger.error("serializePosition method in GeoSerializer class failed - input is null or undefined, stack trace: " + stackTrace);
        return null;
      }
      positionObject = GeoHelper.convertGeoJsonToBaseGeometryShape(positionObject);
      if (positionObject) {
        if (((typeof positionObject) == "string") && positionObject.indexOf('{') != 0) { //if not start with '{' -> its base64 string (already serialized)
          base64 = positionObject;
        } else {
          base64 = this.serialize(positionObject, true);
        }
      } else {
        logger.error("serializePosition method in GeoSerializer class failed - conversion returned null or undefined");
        return null;
      }

      //remove any occurrences from cache so next time user call getPosition, it will be calculated and not return dirty value from cache
      let positionCache = this.getPositionToCustomGeoCache();
      let returnType = undefined;
      if (positionCache[returnTypeEnum.geoJson] && positionCache[returnTypeEnum.geoJson][base64]) {
        returnType = returnTypeEnum.geoJson;
        delete positionCache[returnTypeEnum.geoJson][base64];
      }
      if (positionCache[returnTypeEnum.geoJsonPlusPlus] && positionCache[returnTypeEnum.geoJsonPlusPlus][base64]) {
        returnType = returnTypeEnum.geoJsonPlusPlus;
        delete positionCache[returnTypeEnum.geoJsonPlusPlus][base64];
      }
      if (positionCache[returnTypeEnum.customGeoObject] && positionCache[returnTypeEnum.customGeoObject][base64]) {
        returnType = returnTypeEnum.customGeoObject;
        delete positionCache[returnTypeEnum.customGeoObject][base64];
      }

      if (returnType != null && returnType != undefined) {
        //handle 'last 5' mechanism
        let last5Collection = this.getLast5();
        var index = last5Collection[returnType].indexOf(base64);    // <-- Not supported in <IE9
        if (index !== -1) {
          last5Collection[returnType].splice(index, 1);
        }
      }
      return base64;
    } catch (exception) {
      logger.error("serializePosition method in GeoSerializer class failed.", exception);
    }
  }

  /**
   * @deprecated Use deserializePosition instead!!!!!
   */
  static getPosition(positionInput, returnType) {
    return this.deserializePosition(positionInput, returnType);
  }

  /**
   * @deprecated Use serializePosition instead!!!!!
   */
  static setPosition(positionObject) {
    return this.serializePosition(positionObject);
  }

  /**
   * Gets object with updated altitude accordonvering to user preferences
   * @param point
   * @returns {{measurementUnit: null, value: null, toString: (function(): string)}}
   */
  static getUserDefinedAltitude(point, heightType = Enum.fieldType.altitude) {
    let userPreferences = {value: null, shortName: null};

    if (point && point.altitude) {
      let field = point.altitude;
      let type = heightType.toLowerCase();
      userPreferences = DisplayDataHandler.buildBtypeMembers({field: {value: field, type: type}});
    }

    return {
      measurementUnit: userPreferences.shortName,
      value: userPreferences.value,
      toString: function userDefinedAltitudeToString() {
        return PositionConverterUtils.userDefinedAltitudeToString(this);
      },
    };
  }

  /**
   * converts string position of the shape "geometery_type ((coordinate1, coordinate2, coordinate3))"
   * @param stringPosition
   */
  static WktToEcixBase64(stringPosition, maxNumOfCoordinates, xMin, yMin, xMax, yMax) {
    try {
      let base64position = null;
      let checkMBR = (xMin && yMin && xMax && yMax);
      let cutIndex = stringPosition.indexOf("(");
      let geometryType = stringPosition.slice(0,cutIndex);
      let tokens = geometryType.split("Z");
      geometryType = tokens.length>1 ? tokens[0].slice(0, tokens[0].length - 1) : tokens[0];
      let typeToCheck = (geometryType === "MULTIPOINT" || geometryType === "MULTILINESTRING" || geometryType === "LINESTRING");
      checkMBR = typeToCheck && checkMBR;
      let stringCoordinates = stringPosition.slice(cutIndex);
      while (stringCoordinates.charAt(0) == '(' && stringCoordinates.charAt(1) == '(') {
        stringCoordinates = stringCoordinates.slice(1, stringCoordinates.length - 1);
      }
      let coordinates = [];
      /*            for (int i=0; i<stringCoordinates.length(); i++){
                      char current = stringCoordinates.charAt(i);
                      if (current=='('){
                          //start of shape
                          continue;
                      }
                      else if (current==')'){
                          //end of shape
                          continue;
                      }
                      else if (current==','){
                          //end of coordinate

                      }
                      else if(current==' '){
                          //end of x|y|z

                      }
                  }*/
      let numOfCoordinates = 0;
      while (stringCoordinates.charAt(0) == '(' && (!maxNumOfCoordinates || (maxNumOfCoordinates != null && numOfCoordinates < maxNumOfCoordinates))) {
        let endOfShapeIndex = stringCoordinates.length;
        let shapeStringCoordinates = stringCoordinates;
        while (shapeStringCoordinates.charAt(0) == '(') {
          endOfShapeIndex = stringCoordinates.indexOf(")");
          shapeStringCoordinates = stringCoordinates.slice(1, endOfShapeIndex); //support multi shape
        }
        let stringCoordinatesTokens = shapeStringCoordinates.split(",");
        if (stringCoordinatesTokens  && stringCoordinatesTokens.length > 0) {
          for (let strCoordinate of stringCoordinatesTokens) {
            if (strCoordinate.charAt(0) == ' ') strCoordinate = strCoordinate.slice(1);
            let coordinateTokens = strCoordinate.split(" ");
            let coordinate = [];
            let coordinateInMBR = true;
            let coordinateIndex = 0;
            for (let coordinateToken of coordinateTokens) {
              let c = coordinateToken;
              if (checkMBR) {
                switch (coordinateIndex) {
                  case 0:
                    //x coordinate
                    coordinateInMBR = coordinateInMBR && (c >= xMin && c <= xMax);
                    break;
                  case 1:
                    //y coordinate
                    coordinateInMBR = coordinateInMBR && (c >= yMin && c <= yMax);
                    break;
                  case 2:
                    //z coordinate
                    coordinateInMBR = coordinateInMBR && true;
                    break;
                }
              }
              coordinateIndex++;
              if (!coordinateInMBR) {
                break;
              }
              coordinate.push(c);
            }
            if (coordinate) {
              if (!checkMBR || (checkMBR && (coordinate.length == coordinateTokens.length) && typeToCheck)) {
                numOfCoordinates++;
                coordinates.push(new Coordinate(...coordinate));
              }
            }
          }
        }
        if (endOfShapeIndex + 3 < stringCoordinates.length) {
          stringCoordinates = stringCoordinates.slice(endOfShapeIndex + 3);
        } else {
          break;
        }
      }
      let shape = null;
      if (coordinates.length > 0) {
        switch (geometryType) {
          case "MULTIPOLYGON":
          case "POLYGON":
            shape = new Polygon(coordinates);
            shape.setCoordinates(coordinates);
            break;
          case "MULTIPOINT":
          case "POINT":
            shape = new Point(coordinates[0]);
            shape.setCoordinates(coordinates);
            break;
          case "MULTILINESTRING":
          case "LINESTRING":
            shape = new Polyline(coordinates);
            shape.setCoordinates(coordinates);
            break;
          default:
            logger.error("WktToEcixBase64: shape {} is not supported", geometryType);
            return null;
        }
        if (shape) {
          base64position = GeoSerializer.setPosition(shape);
        }
      }
      return base64position;

    } catch (ex) {
      logger.error("WktToEcixBase64:{}", ex);
    }
    return null;
  }

}

module.exports = {GeoSerializer};


