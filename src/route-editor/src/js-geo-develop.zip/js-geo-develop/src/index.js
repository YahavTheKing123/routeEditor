
//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.
  const {GeoSerializer} = require('./geoSerializer');
  const {BaseGeometry} = require('./Types/baseGeometry');
  const {Polyline} = require("./Shapes/polyline");
  const {Point} = require("./Shapes/point");
  const {Polygon} = require("./Shapes/polygon");
  const {Coordinate} = require("./Types/coordinate");
  const {MgrsCoordinate} = require("./Types/mgrsCoordinate");
  const {BngCoordinate} = require("./Types/bngCoordinate");
  const {IrishCoordinate} = require("./Types/irishCoordinate");
  const {UtmCoordinate} = require("./Types/utmCoordinate");
  const {GarsCoordinate} = require("./Types/garsCoordinate");
  const {geoKind} = require("./Types/geoKind");
  const {returnTypeEnum} = require("./Types/returnTypeEnum");
  const {GeoHelper} = require("./geoHelper");
  const {Ellipse} = require("./Shapes/ellipse");
  const {Circle} = require("./Shapes/circle");
  const {Rectangle} = require("./Shapes/rectangle");
  const {Sector} = require("./Shapes/sector");
  const {Arrow} = require("./Shapes/arrow");
  const {Arc} = require("./Shapes/arc");
  const {GeoCamera} = require("./Shapes/geoCamera");
  const {Corridor} = require("./Shapes/corridor");
  const {TwoPoints} = require("./Shapes/twoPoints");
  const {UnitsConv} = require("./Convertors/unitsConv");
  const {CustomGeoConverter} = require("./Convertors/customGeoConverter");
  let azimuthTypes = require("./Types/azimuthTypes");
  let definitions = require("./definitions");
  const {Logger} = require('@elbit/logger-server');
  const logger = Logger.getLogger("index");
  const {datums} = require("./Types/datums");
  const coordinateSystemEnum = require("./Convertors/coordSysConvertor").coordinateSystemEnum;


//If its node js service - initialize mapcore as 3rd party libraries, otherwise use old 3rd party libraries.
  var isNodeEnvironment = Object.prototype.toString.call(global.process) === '[object process]';
  let geographicCalculations = require("./GeoCalculations/geographicStaticCalculations").GeographicStaticCalculations;
  let geometricCalculations = require("./GeoCalculations/geometricStaticCalculations").GeometricStaticCalculations;
  geographicCalculations.init();
  geometricCalculations.init();
  let coordSysConvertor = require("./Convertors/coordSysConvertor").CoordSysConvertor;

  let datumsTypes = require("./GeoCalculations/geographicStaticCalculations").datums;
  if (isNodeEnvironment && IS_GEO_LIBRARY_NEEDED) {
    loadGeoLibraries();
  }


  async function loadGeoLibraries(library) {
    logger.info("Initializing mapcore as 3rd party geo libraries");
    const {GeoCalculationsFactory} = require("./GeoCalculations/geoCalculationsFactory");
    BaseGeometry.geographicLibrary = await GeoCalculationsFactory.getGeographicCalculations(GEOGRAPHIC_LIBRARY_DATUM, library);
    BaseGeometry.geometricLibrary = GeoCalculationsFactory.getGeometricCalculations(library);
    coordSysConvertor.coordSysConvLibrary = GeoCalculationsFactory.getCoordinateSysConvertor(library);
    logger.info("Initialize Geo libraries finished successfully");
  }


  module.exports = {
    geo: {
      datums: datumsTypes,
      datumsTypes: datums,
      geographicCalculations: geographicCalculations,
      geometricCalculations: geometricCalculations,
      coordSysConvertor: coordSysConvertor,
      coordinateSystemEnum: coordinateSystemEnum,
      serializer: GeoSerializer,
      coordinate: Coordinate,
      coordinateTypes: {
        mgrsCoordinate: MgrsCoordinate,
        utmCoordinate: UtmCoordinate,
        bngCoordinate: BngCoordinate,
        irishCoordinate: IrishCoordinate,
        garsCoordinate: GarsCoordinate
      },
      baseGeometry: BaseGeometry,
      shapes: {
        point: Point,
        polyline: Polyline,
        polygon: Polygon,
        ellipse: Ellipse,
        circle: Circle,
        arc: Arc,
        arrow: Arrow,
        sector: Sector,
        rectangle: Rectangle,
        geoCamera: GeoCamera,
        corridor: Corridor,
        twoPoints: TwoPoints
      },

      geoKind: geoKind,
      returnTypeEnum: returnTypeEnum,
      geoHelper: GeoHelper,
      unitsConv: UnitsConv,
      customGeoConverter: CustomGeoConverter,
      azimuthTypes: azimuthTypes,
      definitions: definitions
    }, loadGeoLibraries
  };
