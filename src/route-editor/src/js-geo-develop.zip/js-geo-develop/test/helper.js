//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
class Helper {
    static waitMs(timeToWaitMs) {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve, reject) => {
                var startMs = new Date().getTime();
                var timer = setInterval(() => {
                    var currentMs = new Date().getTime();
                    if (currentMs - startMs >= timeToWaitMs) {
                        clearInterval(timer);
                        resolve();
                    }
                }, 10);
            });
        });
    }
}
exports.Helper = Helper;
//# sourceMappingURL=TestsHelper.js.map