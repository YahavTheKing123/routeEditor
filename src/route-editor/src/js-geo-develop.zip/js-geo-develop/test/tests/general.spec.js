//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.
require('../../src/constants');
global.IS_GEO_LIBRARY_NEEDED = true;
const {geo} = require('../../src/index');
const {Logger} = require('@elbit/logger-server');
const logger = Logger.getLogger("tests - general");
const Coordinate = geo.coordinate;
const Point = geo.shapes.point;
const Polyline = geo.shapes.polyline;
const Polygon = geo.shapes.polygon;
const Ellipse = geo.shapes.ellipse;
const Circle = geo.shapes.circle;
const Arc = geo.shapes.arc;
const Arrow = geo.shapes.arrow;
const Sector = geo.shapes.sector;
const Rectangle = geo.shapes.rectangle;
const GeoCamera = geo.shapes.geoCamera;
const Corridor = geo.shapes.corridor;
const TwoPoints = geo.shapes.twoPoints;
const UnitsConv = geo.unitsConv;
const coordSysConvertor = geo.coordSysConvertor;
const MgrsCoordinate = geo.coordinateTypes.mgrsCoordinate;
const UtmCoordinate = geo.coordinateTypes.utmCoordinate;
var assert = require('assert');
const {Helper} = require('../helper');


describe('General calculations tests:', function () {

  it("Waiting for geo library asyc load1",async function () {
    await Helper.waitMs(1500)
  });

  it("Waiting for geo library asyc load2",async function () {
    await Helper.waitMs(1500)
  });

  it("Waiting for geo library asyc load2",async function () {
    await Helper.waitMs(1500)
  });

  it("Waiting for geo library asyc load4",async function () {
    await Helper.waitMs(1500)
  });

  it("should test 'Check coord sys conv' functionality:", function () {
    testCoordSysConversion()
  });

  it("should test 'CheckIsEquals' functionality:", function () {
    testCheckIsEquals()
  });

  it("should test 'testCentersOfGeos' functionality:", function () {
    testCentersOfGeos()
  });

  it("should test 'crc' functionality:", function () {
    testCrc()
  });

  it("should test shape creation functionality:", function () {
    testShapeCreation()
  });

});


function testShapeCreation() {
  assert.equal(Point.createShape() instanceof Point,true);
  assert.equal(Polyline.createShape() instanceof Polyline,true);
  assert.equal(Polygon.createShape() instanceof Polygon,true);
  assert.equal(Ellipse.createShape() instanceof Ellipse,true);
  assert.equal(Circle.createShape() instanceof Circle,true);
  assert.equal(Arc.createShape() instanceof Arc,true);
  assert.equal(Arrow.createShape() instanceof Arrow,true);
  assert.equal(Sector.createShape() instanceof Sector,true);
  assert.equal(Rectangle.createShape() instanceof Rectangle,true);
  assert.equal(GeoCamera.createShape() instanceof GeoCamera,true);
  assert.equal(Corridor.createShape() instanceof Corridor,true);
  assert.equal(TwoPoints.createShape() instanceof TwoPoints,true);
}


function testCrc() {
  // Test identical to jGeo tests/CrcCalcTest.java test and should give the same results!
  let point1, point2;

  logger.info("\n\n Testing CRC calculation:");
  let rectangle1 = new Rectangle();
  rectangle1.width = 3008.8295898;
  rectangle1.height = 600;
  rectangle1.orientation = 30;
  rectangle1.coordinates = [];
  rectangle1.coordinates.push(new Coordinate());
  rectangle1.coordinates[0].setLongitude(34.8348126);
  rectangle1.coordinates[0].setLatitude(32.1440598);
  rectangle1.coordinates[0].setAltitude(56.835886);

  let crc1 = geo.geoHelper.calculateStringCrc4Geo(rectangle1);
  console.log("rectangle 1 CRC ", crc1)
  assert.equal(crc1, "4e0e");

  let rectangle2 = new Rectangle();
  rectangle2.width = 3008.8295898;
  rectangle2.height = 600;
  rectangle2.orientation = 30;
  rectangle2.coordinates = [];
  rectangle2.coordinates.push(new Coordinate());
  rectangle2.coordinates[0].setLongitude(34.8348126);
  rectangle2.coordinates[0].setLatitude(32.1440598);
  rectangle2.coordinates[0].setAltitude(56.835886);

  let crc2 = geo.geoHelper.calculateStringCrc4Geo(rectangle2);

  //check equals
  assert.equal(geo.geoHelper.validateCrc(crc1, crc2), true);

  logger.info("\n\n Testing not equals:");

  rectangle1.width = 3008.8295898;
  rectangle1.height = 600;
  rectangle1.orientation = 30;
  rectangle1.coordinates = [];
  rectangle1.coordinates.push(new Coordinate());
  rectangle1.coordinates[0].setLongitude(34.8348126);
  rectangle1.coordinates[0].setLatitude(32.1440598);
  rectangle1.coordinates[0].setAltitude(56.835886);

  crc1 = geo.geoHelper.calculateStringCrc4Geo(rectangle1);

  rectangle2 = new Rectangle();
  rectangle2.width = 3008.8295898;
  rectangle2.height = 600;
  rectangle2.orientation = 30;
  rectangle2.coordinates = [];
  rectangle2.coordinates.push(new Coordinate());
  rectangle2.coordinates[0].setLongitude(34.8748126);
  rectangle2.coordinates[0].setLatitude(32.1440598);
  rectangle2.coordinates[0].setAltitude(56.835886);

  crc2 = geo.geoHelper.calculateStringCrc4Geo(rectangle2);
  console.log("rectangle 2 CRC ", crc2)
  assert.equal(crc2, "ce04");

  //check not equals
  assert.equal(geo.geoHelper.validateCrc(crc1, crc2), false);

  logger.info("\n\n Testing degrees are more and less seven digits");

  point1 = new Point();
  point1.coordinates = [];
  point1.coordinates.push(new Coordinate());
  point1.coordinates[0].setLongitude(34.874);
  point1.coordinates[0].setLatitude(32.1440598);
  point1.coordinates[0].setAltitude(56.835886);

  crc1 = geo.geoHelper.calculateStringCrc4Geo(point1);
  console.log("point 1 CRC ", crc1)
  assert.equal(crc1, "f3");

  point2 = new Point();
  point2.coordinates = [];
  point2.coordinates.push(new Coordinate());
  point2.coordinates[0].setLongitude(34.874000000000000000);
  point2.coordinates[0].setLatitude(32.1440598);
  point2.coordinates[0].setAltitude(56.835886);

  crc2 = geo.geoHelper.calculateStringCrc4Geo(point2);
  assert.equal(geo.geoHelper.validateCrc(crc1, crc2), true);

  logger.info("\n\n Testing position without altitude");

  point1 = new Point();
  point1.coordinates = [];
  point1.coordinates.push(new Coordinate());
  point1.coordinates[0].setLongitude(34.874);
  point1.coordinates[0].setLatitude(32.1440598);

  crc1 = geo.geoHelper.calculateStringCrc4Geo(point1);
  console.log("point 2 CRC ", crc1)
  assert.equal(crc1, "1d");

  point2 = new Point();
  point2.coordinates = [];
  point2.coordinates.push(new Coordinate());
  point2.coordinates[0].setLongitude(34.874000000000000000);
  point2.coordinates[0].setLatitude(32.1440598);
  point2.coordinates[0].setAltitude(0);

  crc2 = geo.geoHelper.calculateStringCrc4Geo(point2);

  assert.equal(geo.geoHelper.validateCrc(crc1, crc2), false);

  logger.info("\n\n Testing negative positions");

  point1 = new Point();
  point1.coordinates = [];
  point1.coordinates.push(new Coordinate());
  point1.coordinates[0].setLongitude(34.567908);
  point1.coordinates[0].setLatitude(32.1440598);
  point1.coordinates[0].setAltitude(10);

  crc1 = geo.geoHelper.calculateStringCrc4Geo(point1);
  console.log("point 3 CRC ", crc1)
  assert.equal(crc1, "f1");

  point2 = new Point();
  point2.coordinates = [];
  point2.coordinates.push(new Coordinate());
  point2.coordinates[0].setLongitude(-34.567908);
  point2.coordinates[0].setLatitude(-32.1440598);
  point2.coordinates[0].setAltitude(-10);

  crc2 = geo.geoHelper.calculateStringCrc4Geo(point2);
  console.log("point 3 negative CRC ", crc2)
  assert.equal(crc2, "61");

  assert.equal(geo.geoHelper.validateCrc(crc1, crc2), false);

  logger.info("\n\n Testing hardcoded crc for the future - to see if the crc library return same values");

  point1 = new Point();
  point1.coordinates = [];
  point1.coordinates.push(new Coordinate());
  point1.coordinates[0].setLongitude(34.87499);
  point1.coordinates[0].setLatitude(32.1440598);
  point1.coordinates[0].setAltitude(19);

  crc1 = geo.geoHelper.calculateStringCrc4Geo(point1);
  console.log("point 4 CRC ", crc1)
  crc2 = "7a";
  assert.equal(geo.geoHelper.validateCrc(crc1, crc2), true);

  let polygon1 = new Polygon();
  polygon1.coordinates = [];
  polygon1.coordinates.push(new Coordinate(34.952524, 32.790281));
  polygon1.coordinates.push(new Coordinate(34.973724, 32.789127));
  polygon1.coordinates.push(new Coordinate(34.972952, 32.777581));
  polygon1.coordinates.push(new Coordinate(34.952009, 32.777509));
  crc1 = geo.geoHelper.calculateStringCrc4Geo(polygon1);
  console.log("polygon 1 CRC ", crc1);
  assert.equal(crc1, "77d4");

  let polyline1 = new Polyline();
  polyline1.coordinates = polygon1.coordinates;
  crc1 = geo.geoHelper.calculateStringCrc4Geo(polyline1);
  console.log("polyline 1 CRC ", crc1);
  assert.equal(crc1, "77d4");

  let circle1 = new Circle();
  circle1.radius = 1000.5;
  circle1.coordinates = [];
  circle1.coordinates.push(new Coordinate());
  circle1.coordinates[0].setLongitude(34.874);
  circle1.coordinates[0].setLatitude(32.1440598);
  circle1.coordinates[0].setAltitude(56.835886);
  crc1 = geo.geoHelper.calculateStringCrc4Geo(circle1);
  console.log("circle 1 CRC ", crc1);
  assert.equal(crc1, "71");

  let ellipse1 = new Ellipse();
  ellipse1.horizontalRadius = 1000.5;
  ellipse1.verticalRadius = 500;
  ellipse1.orientation = 30;
  ellipse1.coordinates = circle1.coordinates;
  crc1 = geo.geoHelper.calculateStringCrc4Geo(ellipse1);
  console.log("ellipse 1 CRC ", crc1);
  assert.equal(crc1, "7a4a");

  let arc1 = new Arc();
  arc1.radius = 1000.5;
  arc1.fromAngle = 30;
  arc1.toAngle = 60;
  arc1.coordinates = circle1.coordinates;
  crc1 = geo.geoHelper.calculateStringCrc4Geo(arc1);
  console.log("arc 1 CRC ", crc1);
  assert.equal(crc1, "992b");

  let arrow1 = new Arrow();
  arrow1.coordinates = polygon1.coordinates;
  crc1 = geo.geoHelper.calculateStringCrc4Geo(arrow1);
  console.log("arrow 1 CRC ", crc1);
  assert.equal(crc1, "77d4");

  let corridor1 = new Corridor();
  corridor1.coordinates = polygon1.coordinates;
  crc1 = geo.geoHelper.calculateStringCrc4Geo(corridor1);
  console.log("corridor 1 CRC ", crc1);
  assert.equal(crc1, "77d4");

  let geocamera1 = new GeoCamera();
  geocamera1.coordinates = polygon1.coordinates;
  crc1 = geo.geoHelper.calculateStringCrc4Geo(geocamera1);
  console.log("geocamera 1 CRC ", crc1);
  assert.equal(crc1, "77d4");

  let sector1 = new Sector();
  sector1.minimumRadius = 1000;
  sector1.maximumRadius = 2000;
  sector1.fromAngle = 30;
  sector1.toAngle = 60;
  sector1.coordinates = circle1.coordinates;
  crc1 = geo.geoHelper.calculateStringCrc4Geo(sector1);
  console.log("sector 1 CRC ", crc1);
  assert.equal(crc1, "93eb");

  let twopoints1 = new TwoPoints();
  twopoints1.coordinates = []; // first two coordinates of polygon above
  twopoints1.coordinates.push(new Coordinate(34.952524, 32.790281));
  twopoints1.coordinates.push(new Coordinate(34.973724, 32.789127));
  crc1 = geo.geoHelper.calculateStringCrc4Geo(twopoints1);
  console.log("twopoints 1 CRC ", crc1);
  assert.equal(crc1, "97ce");

  // Polyline with 100 points, for crc32
  let polyline2 = new Polyline();
  polyline2.coordinates = [];
  for(var i=0;i<100;i++)
    polyline2.coordinates.push(new Coordinate(34.952524 + i * 0.00001, 32.790281 + i * 0.00001));
  crc1 = geo.geoHelper.calculateStringCrc4Geo(polyline2);
  console.log("polyline 2 100 points CRC ", crc1);
  assert.equal(crc1, "aaf3f19");
}


function testCheckIsEquals() {
  let point1 = new Point();
  point1.coordinates = [];
  point1.coordinates.push(new Coordinate())
  point1.coordinates[0].setLongitude(34.85412);
  point1.coordinates[0].setLatitude(-32.1440598);
  point1.coordinates[0].setAltitude(11.435);

  let point2 = point1.clone();
  point2.coordinates[0].setLatitude(-32.1440599);
  let resultPoint = point1.isEquals(point2);


  let rectangle1 = new Rectangle();
  rectangle1.width = 3008.8295898;
  rectangle1.height = 600;
  rectangle1.orientation = 30;
  rectangle1.coordinates = [];
  rectangle1.coordinates.push(new Coordinate());
  rectangle1.coordinates[0].setLongitude(34.8348126);
  rectangle1.coordinates[0].setLatitude(32.1440598);
  rectangle1.coordinates[0].setAltitude(56.835886);

  let rectangle2 = rectangle1.clone();
  rectangle2.coordinates[0].setLatitude(32.144059);
  rectangle2.height = 600;
  let resultRectangle = rectangle1.isEquals(rectangle2);

  let coordinateOnlyCheck = rectangle2.coordinates[0].equals(rectangle1.coordinates[0]);
  assert.equal(resultPoint, true);
  assert.equal(resultRectangle, true);
  assert.equal(coordinateOnlyCheck, true);
}


function testCentersOfGeos() {
  logger.info("\n\n Testing CenterPoint:");

  let point = new Point();
  point.coordinates = [];
  point.coordinates.push(new Coordinate(35.0583694143859, 32.1368905136927));
  let center = point.getCenter();
  logger.info("Testing Point:");
  assert.equal(center.getLongitude(), 35.0583694143859);
  assert.equal(center.getLatitude(), 32.1368905136927);


  logger.info("Testing Polygon (test1):");
  let polygon = new Polygon();
  polygon.coordinates = [];
  polygon.coordinates.push(new Coordinate(34.9738552130111, 32.1812299140711));
  polygon.coordinates.push(new Coordinate(35.5083425196793, 32.236738767119));
  polygon.coordinates.push(new Coordinate(35.5752964970671, 31.9443158402374));
  center = polygon.getCenter();
  assert.equal(Math.abs(center.getLongitude() - 35.3524980765858) < 0.00000001, true);
  assert.equal(Math.abs(center.getLatitude() - 32.1207615071425) < 0.00000001, true);


  logger.info("Testing Polygon (test2):");
  polygon = new Polygon();
  polygon.coordinates = [];
  polygon.coordinates.push(new Coordinate(35.1838732446463, 32.0604838522863));
  polygon.coordinates.push(new Coordinate(35.4402440298575, 32.0908134317867));
  polygon.coordinates.push(new Coordinate(35.4305156741687, 31.9746454197379));
  polygon.coordinates.push(new Coordinate(35.2033299560239, 31.9706396262189));
  center = polygon.getCenter();
  assert.equal(Math.abs(center.getLongitude() - 35.3144907261741) < 0.00000001, true);
  assert.equal(Math.abs(center.getLatitude() - 32.0241455825075) < 0.00000001, true);


  logger.info("Testing Polyline (test1):");
  let polyline = new Polyline();
  polyline.coordinates = [];
  polyline.coordinates.push(new Coordinate(34.3699221797908, 31.1604052350835));
  polyline.coordinates.push(new Coordinate(35.7289988223965, 33.3522494283054));
  polyline.coordinates.push(new Coordinate(35.7356609628014, 31.4868501149251));

  center = polyline.getCenter();
  assert.equal(Math.abs(center.getLongitude() - 35.7289988223965) < 0.00000001, true);
  assert.equal(Math.abs(center.getLatitude() - 33.3522494283054) < 0.00000001, true);


  logger.info("Testing Polyline (test2):");
  polyline = new Polyline();
  polyline.coordinates = [];
  polyline.coordinates.push(new Coordinate(35.1657460068017, 32.1239594818065));
  polyline.coordinates.push(new Coordinate(35.2059758707501, 32.1242475237919));
  polyline.coordinates.push(new Coordinate(35.2075120946717, 32.1052367527614));
  polyline.coordinates.push(new Coordinate(35.1617134190074, 32.1049487107761));

  center = polyline.getCenter();
  assert.equal(Math.abs(center.getLongitude() - 35.2067439827109) < 0.00000001, true);
  assert.equal(Math.abs(center.getLatitude() - 32.1147421382766) < 0.00000001, true);


  logger.info("Testing Conversions:");
  let deg = 1;
  assert.equal(UnitsConv.degToMils(deg) == 17.777777778, true);
  assert.equal(UnitsConv.milsToDeg(UnitsConv.degToMils(deg)) - 1 < 0.0001, true);

}


function testCoordSysConversion() {
// TODO: write tests
  logger.info("\n\n Testing Coordinate sys conversion:");

  logger.info("\n\n Testing Mgrs:");
  let coord = new Coordinate(35.10222, 32.62722, 0);
  let mgrsCoord = coordSysConvertor.convertGeoToMgrs(coord);
  coord = coordSysConvertor.convertMgrsToGeo(mgrsCoord);

  //mgrsCoord = new MgrsCoordinate(97221,11913,0,"X","B","S",36);
  //coord = coordSysConvertor.convertMgrsToGeo(mgrsCoord);

  logger.info("\n\n Testing Utm:");
  coord = new Coordinate(35.10222, 32.62722, 30);
  let utm = coordSysConvertor.convertGeoToUtm(coord);
  coord = coordSysConvertor.convertUtmToGeo(utm);


  logger.info("\n\n Testing Utm:");
  coord = new Coordinate(34.86584, 32.35450, 0);
  let geoAzimiuth = 319.67501840;
  let gridAzimuth = coordSysConvertor.convertGeoToGridAzimuth(coord, geoAzimiuth);
  geoAzimiuth = coordSysConvertor.convertGridToGeoAzimuth(coord, gridAzimuth);

  logger.info("\n\n Testing S42:");
  coord = new Coordinate(35.10222, 32.62722, 0);
  let s42Coord = coordSysConvertor.convertGeoToS42(coord);
  coord = coordSysConvertor.convertS42ToGeo(s42Coord);


  logger.info("\n\n Finish Testing Coordinate sys conversion:");
}
