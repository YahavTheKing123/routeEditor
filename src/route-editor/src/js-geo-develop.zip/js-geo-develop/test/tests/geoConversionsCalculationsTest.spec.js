require('../../src/constants');
global.IS_GEO_LIBRARY_NEEDED = true;
const {geo} = require('../../src/index');
const {Logger} = require('@elbit/logger-server');
const logger = Logger.getLogger("tests - general");
const Coordinate = geo.coordinate;
const coordSysConvertor = geo.coordSysConvertor;
const datums = geo.datumsTypes;
const MgrsCoordinate = geo.coordinateTypes.mgrsCoordinate;
const BngCoordinate = geo.coordinateTypes.bngCoordinate;
const IrishCoordinate = geo.coordinateTypes.irishCoordinate;
const UtmCoordinate = geo.coordinateTypes.utmCoordinate;
const GarsCoordinate = geo.coordinateTypes.garsCoordinate;
var assert = require('chai').assert;
const {Helper} = require('../helper');

describe('General calculations tests:', function () {

  it("Waiting for geo library asyc load1",async function () {
    await Helper.waitMs(1500)
  });

  it("Waiting for geo library asyc load2",async function () {
    await Helper.waitMs(1500)
  });

  it("Waiting for geo library asyc load2",async function () {
    await Helper.waitMs(1500)
  });

  it("Waiting for geo library asyc load4",async function () {
    await Helper.waitMs(1500)
  });

  it("should test gars Test functionality:", function () {
    geoToGarsTest();
    garsToGeoTest();
  });
  it("should test Bng Test functionality:", function () {
    geoToBngTest();
    bngToGeoTest();
  });

  it("should test 'geoToMgrsTest' functionality:", function () {
    geoToMgrsTest()
  });

  it("should test 'mgrsToGeoTest' functionality:", function () {
    mgrsToGeoTest()
  });
  it("should test 'geoToUtmTest' functionality:", function () {
    geoToUtmTest()
  });
  it("should test 'geoToUtmNagtiveTest' functionality:", function () {
    //geoToUtmNagtiveTest()
  });
  it("should test 'utmToGeoTest' functionality:", function () {
    utmToGeoTest()
  });
  it("should test 'geoToS42Test' functionality:", function () {
    geoToS42Test()
  });
  it("should test 's42ToGeoTest' functionality:", function () {
    s42ToGeoTest()
  });
  it("should test irish  convert functionality:", function () {
    geoToIrishWorldTest();
    irishWorldToGeoTest();
  });
  it("should test dd to  convert functionality:", function () {
    ddToDdm();
    ddToDms();
    dmsToDdmTest();
    dmsToDdTest();
    ddmToDdTest()
  });

});

function ddToDdm() {
  let dd, result, excepted;
  dd = 164.754167;

  result = coordSysConvertor.ddToDm(dd);
  excepted = {d: 164, m: 45.25};
  assert.equal(excepted.d,result.d);
  assert.closeTo(excepted.m,result.m,0.0001);

  dd = -77.508333;
  result = coordSysConvertor.ddToDm(dd);
  excepted = {d: -77, m: 30.5};
  assert.equal(excepted.d,result.d);
  assert.closeTo(excepted.m,result.m,0.0001);

}

function ddToDms() {
  let dd, result, excepted;
  dd = 164.754167;

  result = coordSysConvertor.ddToDms(dd);
  excepted = {d: 164, m: 45,s:15.0012};
  assert.equal(excepted.d,result.d);
  assert.equal(excepted.m,result.m);
  assert.closeTo(excepted.s,result.s,0.0001);

  dd = -77.508333;
  result = coordSysConvertor.ddToDms(dd);
  excepted = {d: -77, m: 30,s:29.9988};
  assert.equal(excepted.d,result.d);
  assert.equal(excepted.m,result.m);
  assert.closeTo(excepted.s,result.s,0.0001);
}

function dmsToDdTest() {
  let dms, result, excepted;
  dms = {degrees: 164, minutes: 45,seconds:15.0012};
  result = coordSysConvertor.dmsToDd(dms);
  excepted = 164.754167;
  assert.closeTo(excepted,result,0.0001);

  dms =  {degrees: -77, minutes: 30,seconds:29.9988};
  result = coordSysConvertor.dmsToDd(dms);
  excepted = -77.508333;
  assert.closeTo(excepted,result,0.0001);
}

function ddmToDdTest() {
  let ddm, result, excepted;
  ddm = {degrees: 164, minutes: 45.25};
  result = coordSysConvertor.dmToDd(ddm);
  excepted = 164.754167;
  assert.closeTo(excepted,result,0.0001);

  ddm =  {degrees: -77, minutes: 30.5};
  result = coordSysConvertor.dmToDd(ddm);
  excepted = -77.508333;
  assert.closeTo(excepted,result,0.0001);
}

function dmsToDdmTest() {
  let dms, result, excepted;
  dms = {degrees: 164, minutes: 45,seconds:15.0012};
  result = coordSysConvertor.dmsToDm(dms);
  excepted = {degrees: 164, Mm: 45.25};
  assert.equal(excepted.degrees,result.degrees);
  assert.closeTo(excepted.Mm,result.Mm,0.0001);

  dms =  {degrees: -77, minutes: 30,seconds:29.9988};
  result = coordSysConvertor.dmsToDm(dms);
  excepted = {degrees: -77, Mm: 30.5};
  assert.equal(excepted.degrees,result.degrees);
  assert.closeTo(excepted.Mm,result.Mm,0.0001);
}

function geoToGarsTest() {
  let geoCoord = new Coordinate(34.000000, 32.000000, 0);
  let result = coordSysConvertor.convertGeoToGars(geoCoord);
  let excepted = new GarsCoordinate("429LE37");
  assert.equal(excepted.getMinute(), result.getMinute());

}

function garsToGeoTest() {
  let excepted = new Coordinate(34.041667, 32.041667, 0);
  let garsCoord = new GarsCoordinate("429LE37");
  let result = coordSysConvertor.convertGarsToGeo(garsCoord);

  assert.closeTo(result.getLongitude(), excepted.getLongitude(), 0.00001);
  assert.closeTo(result.getLatitude(), excepted.getLatitude(), 0.00001);
}

function geoToMgrsTest() {
  let geoCoord = new Coordinate(35.10222, 32.62722, 0);
  let mgrsCoordinate = coordSysConvertor.convertGeoToMgrs(geoCoord);
  let zone = 36;
  let result = new MgrsCoordinate(
    97221.0,
    11913.0, 0,
    'X',
    'B',
    'S',
    zone);
  assert.equal(Math.round(mgrsCoordinate.getLongitude()), result.getLongitude());
  assert.equal(Math.round(mgrsCoordinate.getLatitude()), result.getLatitude());
  assert.equal(mgrsCoordinate.getBand(), result.getBand());
  assert.equal(mgrsCoordinate.getSquareFirst(), result.getSquareFirst());
  assert.equal(mgrsCoordinate.getSquareSecond(), result.getSquareSecond());
  assert.equal(mgrsCoordinate.getZone(), result.getZone());
}

function mgrsToGeoTest() {
  let result = new Coordinate(35.10222, 32.62722, 0);
  let zone = 36;
  let mgrsCoordinate = new MgrsCoordinate(
    97221.0,
    11913.0, 0,
    'X',
    'B',
    'S',
    zone);
  let geo = coordSysConvertor.convertMgrsToGeo(mgrsCoordinate);

  assert.closeTo(geo.getLongitude(), result.getLongitude(), 0.00001);
  assert.closeTo(geo.getLatitude(), result.getLatitude(), 0.00001);
}

function geoToBngTest() {
  let geoCoord = new Coordinate(1.716038, 52.657977, 0);
  let result = coordSysConvertor.convertGeoToBng(geoCoord);
  let excepted = new BngCoordinate(
    51409,
    13177, 0,
    'T',
    'G');
  assert.closeTo(excepted.getLongitude(), result.getLongitude(), 0.1);
  assert.closeTo(excepted.getLongitude(), result.getLongitude(), 0.1);
  assert.equal(excepted.getSquareFirst(), result.getSquareFirst());
  assert.equal(excepted.getSquareSecond(), result.getSquareSecond());

}

function bngToGeoTest() {
  let excepted = new Coordinate(1.716038, 52.657977, 0);
  let bngCoordinate = new BngCoordinate(
    51409,
    13177, 0,
    'T',
    'G');
  let result = coordSysConvertor.convertBngToGeo(bngCoordinate);

  assert.closeTo(result.getLongitude(), excepted.getLongitude(), 0.00001);
  assert.closeTo(result.getLatitude(), excepted.getLatitude(), 0.00001);
}


function geoToUtmTest() {
  let geoCoord = new Coordinate(35.10222, 32.62722, 0);
  let utmCoordinate = coordSysConvertor.convertGeoToUtm(geoCoord);
  let result = new UtmCoordinate(
    697221,
    3611913, 0, 36);
  assert.equal(Math.round(utmCoordinate.getLongitude()), result.getLongitude(), 0.1);
  assert.equal(Math.round(utmCoordinate.getLatitude()), result.getLatitude(), 0.1);
  assert.equal(utmCoordinate.getZone(), result.getZone());
}

function geoToUtmNagtiveTest() {
  let geoCoord = new Coordinate(-0.09372, -0.24369, 0);
  let utmCoordinate = coordSysConvertor.convertGeoToUtm(geoCoord);
  let result = new UtmCoordinate(
    697221,
    3611913, 0, 36);
  assert.equal(Math.round(utmCoordinate.getLongitude()), result.getLongitude(), 0.1);
  assert.equal(Math.round(utmCoordinate.getLatitude()), result.getLatitude(), 0.1);
  assert.equal(utmCoordinate.getZone(), result.getZone());
}

function utmToGeoTest() {
  let result = new Coordinate(35.10222, 32.62722, 0);
  let utmCoordinate = new UtmCoordinate(697221, 3611913, 0, 36);
  let geo = coordSysConvertor.convertUtmToGeo(utmCoordinate);
  assert.closeTo(geo.getLongitude(), result.getLongitude(), 0.0001);
  assert.closeTo(geo.getLatitude(), result.getLatitude(), 0.0001);
}

function geoToS42Test() {
  let geoCoord = new Coordinate(35.10222, 32.62722, 0);
  let actual = coordSysConvertor.convertGeoToS42(geoCoord);
  let expected = new UtmCoordinate(697300, 3613358, 0, 6);
  assert.equal(Math.round(actual.getLongitude()), expected.getLongitude());
  assert.equal(Math.round(actual.getLatitude()), expected.getLatitude());
  assert.equal(actual.getZone(), expected.getZone());
}

function s42ToGeoTest() {
  let s42Coordinate = new UtmCoordinate(697300, 3613359, 0, 6);
  let actual = coordSysConvertor.convertS42ToGeo(s42Coordinate);
  let expected = new Coordinate(35.10222, 32.62722, 0);
  assert.closeTo(actual.getLongitude(), expected.getLongitude(), 0.00001);
  assert.closeTo(actual.getLatitude(), expected.getLatitude(), 0.00001);
}

function geoToIrishWorldTest() {
  let geoCoord, result, excepted;

  geoCoord = new Coordinate(-6.34803280555555, 53.3640400277777, 0);
  result = coordSysConvertor.convertGeoToIrishWorld(geoCoord, datums.IRIS);
  excepted = new IrishCoordinate(
    9958.2654,
    36141.9292, 0, "O");
  assert.closeTo(excepted.getLongitude(), result.getLongitude(), 0.1);
  assert.closeTo(excepted.getLatitude(), result.getLatitude(), 0.1);
  assert.equal(result.getLetter(), result.getLetter());

}

function irishWorldToGeoTest() {
  let irishCoordinate, result, excepted;
  irishCoordinate = new IrishCoordinate(
    9958.2654,
    36141.9292, 0, "O");
  excepted = new Coordinate(-6.34803280555555, 53.3640400277777, 0);
  result = coordSysConvertor.convertIrishWorldToGeo(irishCoordinate, datums.IRIS);
  assert.closeTo(result.getLongitude(), excepted.getLongitude(), 0.0001);
  assert.closeTo(result.getLatitude(), excepted.getLatitude(), 0.0001);
}

function irishEpsg29902ToGeoTest() {
  let irishCoordinate, result, excepted;
  irishCoordinate = new IrishCoordinate(
    183334.278108,
    229852.724253, 0);
  excepted = new Coordinate(-8.2508088, 53.3189278, 0);
  // result = coordSysConvertor.convertIrishWorldToGeo(irishCoordinate);
  // assert.closeTo(result.getLongitude(), excepted.getLongitude(), 0.0001);
  // assert.closeTo(result.getLatitude(), excepted.getLatitude(), 0.0001);
}

function geoToIrisEpsg29902Test() {
  let geoCoord, result, excepted;

  geoCoord = new Coordinate(-8.2508088, 53.3189278, 0);
  result = coordSysConvertor.convertGeoToIrishWorld(geoCoord);
  // excepted = new Coordinate(
  //   183334.278108,
  //   229852.724253, 0);
  // assert.closeTo(excepted.getLongitude(), result.getLongitude(), 0.1);
  // assert.closeTo(excepted.getLatitude(), result.getLatitude(), 0.1);


}

