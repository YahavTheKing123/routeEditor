//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.
require('../../src/constants');
global.IS_GEO_LIBRARY_NEEDED = true;
const {geo} = require('../../src/index');
const Coordinate = geo.coordinate;
const BaseGeometry = geo.baseGeometry;
const Point = geo.shapes.point;
const Circle = geo.shapes.circle;
const Ellipse = geo.shapes.ellipse;
const Polygon = geo.shapes.polygon;
const Rectangle = geo.shapes.rectangle;
const Sector = geo.shapes.sector;
const geoKind = geo.geoKind;
const geographicCalculations = geo.geographicCalculations;
const coordSysConvertor = geo.coordSysConvertor;
var assert = require('chai').assert;
const {Helper} = require('../helper');

describe('geographic calculations tests:', function () {

  it("Waiting for geo library asyc load1", async function () {
    await Helper.waitMs(1500)
  });

  it("Waiting for geo library asyc load2", async function () {
    await Helper.waitMs(1500)
  });

  it("Waiting for geo library asyc load2", async function () {
    await Helper.waitMs(1500)
  });

  it("Waiting for geo library asyc load4", async function () {
    await Helper.waitMs(1500)
  });

  it("should test 'getSmallestBoundingRect' functionality:", function () {
    getSmallestBoundingRect()
  });

  it("should test 'testNearestPointsDistance' functionality:", function () {
    testNearestPointsDistance()
  });

  it('should test expand shape functionality:', function () {
    testExpandPolygon()
  });

  it("should test 'locationFromLocationAndVector' && 'vectorFromTwoLocations' functionality:", function () {
    testlocationAndVector()
  });

  it("should test geographic 'AreaOfPolygon' functionality:", function () {
    testAreaOfPolygon()
  });

  it("should test geographic 'MagneticDeclination' functionality:", function () {
    //testMagneticDeclination()
  });

  it("should test geographic 'vectorInformationFromTwoLocations' functionality:", function () {
    vectorInformationFromTwoLocations()
  });
});

function vectorInformationFromTwoLocations() {
  let startCoord = new Coordinate(34.6508789, 28.4010648, -1000);
  let endCoord = new Coordinate(31.1132813, 29.0177480, 500);

  let considerEllUseHeight = geographicCalculations.vectorInformationFromTwoLocations(startCoord, endCoord, true, true);
  assert.equal(352325.59130000003, considerEllUseHeight.distance);
  assert.equal(281.2460169364954, considerEllUseHeight.azimuth);

  let considerEll = geographicCalculations.vectorInformationFromTwoLocations(startCoord, endCoord, true, false);
  assert.equal(352336.2109, considerEll.distance);
  assert.equal(281.2460169364954, considerEll.azimuth);

  let notConsiderEll = geographicCalculations.vectorInformationFromTwoLocations(startCoord, endCoord, false);
  assert.equal(352280.855, notConsiderEll.distance);
  assert.equal(281.2460169364954, notConsiderEll.azimuth);
}

function testMagneticDeclination() {
  let date, geoCoord, excepted, result;

  // test today
  geoCoord = new Coordinate(34.5, 32, 0);
  // excepted = 4.79;
  // result = geographicCalculations.getMagneticDeclination(geoCoord);
  // assert.closeTo(excepted, result, 0.01);

  // test 1
  date = new Date(2015, 0, 1);
  geoCoord = new Coordinate(0, 80, 0);
  excepted = -3.9;
  result = geographicCalculations.getMagneticDeclination(geoCoord, date);
  assert.closeTo(excepted, result, 0.01);
}


function getSmallestBoundingRect() {
  let circle = new Circle();
  circle.radius = 20.8295898;
  circle.coordinates = [];
  circle.coordinates.push(new Coordinate());
  circle.coordinates[0].setLongitude(34.8348126);
  circle.coordinates[0].setLatitude(32.1440598);
  circle.coordinates[0].setAltitude(56.835886);
  let rect = geographicCalculations.getSmallestBoundingRect(circle);
  assert.notEqual(rect, null);
  assert.notEqual(rect.height, null);
  assert.notEqual(rect.height, undefined);
  assert.equal(rect.height, 20.831475);
  assert.notEqual(rect.width, null);
  assert.notEqual(rect.width, undefined);
  assert.equal(rect.width, 20.82515);
  assert.notEqual(rect.coordinates, null);
  assert.notEqual(rect.coordinates, undefined);
  assert.equal(rect.coordinates.length, 1);
  assert.equal(rect.coordinates[0].longitude, 34.8348126);
  assert.equal(rect.coordinates[0].latitude, 32.144059799999994);
}


function testNearestPointsDistance() {

  //test point to polygon
  let point = new Point();
  point.coordinates = [];
  let coord = new Coordinate(35.76072, 32.235336, 932.92);
  point.coordinates.push(coord);

  let poly1 = new Polygon();
  poly1.setCoordinates([]);
  poly1.coordinates.push(new Coordinate(35.746399, 32.235469, undefined));
  poly1.coordinates.push(new Coordinate(35.746166, 32.226976, NaN));
  poly1.coordinates.push(new Coordinate(35.751128, 32.229773, NaN));
  poly1.coordinates.push(new Coordinate(35.754125, 32.237966, NaN));
  poly1.coordinates.push(new Coordinate(35.754125, 32.238032, NaN));

  let res0 = geographicCalculations.nearestDistanceBetweenGeometries(poly1, point);
  let res0A = poly1.getNearestDistance(point);
  assert.equal(res0A, res0.nearestDistance);


  //test 2 polygons near the north pole
  let first = new Polygon();
  first.setCoordinates([]);
  first.coordinates.push(new Coordinate(-116.6967773, 77.2544787));
  first.coordinates.push(new Coordinate(-119.0698242, 77.2496302));
  first.coordinates.push(new Coordinate(-120.1684570, 76.8658043));
  first.coordinates.push(new Coordinate(-117.0483398, 76.8707962));
  first.coordinates.push(new Coordinate(-116.2792969, 77.1033276));
  first.coordinates.push(new Coordinate(-116.6967773, 77.2544787));

  let second = new Polygon();
  second.setCoordinates([]);
  second.coordinates.push(new Coordinate(-115.5761719, 76.5475234));
  second.coordinates.push(new Coordinate(-118.2568359, 76.0955169));
  second.coordinates.push(new Coordinate(-115.7519531, 76.2269074));
  second.coordinates.push(new Coordinate(-115.1367188, 75.9522351));
  second.coordinates.push(new Coordinate(-113.9721680, 76.3726195));
  let res1A = first.getNearestDistance(second);
  let res1 = geographicCalculations.nearestDistanceBetweenGeometries(first, second);
  assert.equal(res1A, res1.nearestDistance);

  //test 2 polygons in Israel
  first = new Polygon();
  first.setCoordinates([]);
  first.coordinates.push(new Coordinate(35.7055664, 31.6533814));
  first.coordinates.push(new Coordinate(34.8486328, 31.9521622));
  first.coordinates.push(new Coordinate(33.3764648, 31.8588970));
  first.coordinates.push(new Coordinate(33.6621094, 30.6757154));
  first.coordinates.push(new Coordinate(35.9252930, 30.5244133));
  first.coordinates.push(new Coordinate(35.7055664, 31.6533814));

  second = new Polygon();
  second.setCoordinates([]);
  second.coordinates.push(new Coordinate(34.6508789, 28.4010648));
  second.coordinates.push(new Coordinate(31.1132813, 29.0177480));
  second.coordinates.push(new Coordinate(30.9814453, 27.6446064));
  second.coordinates.push(new Coordinate(32.7392578, 26.0765206));
  second.coordinates.push(new Coordinate(34.6508789, 28.4010648));
  let res2A = first.getNearestDistance(second);
  let res2 = geographicCalculations.nearestDistanceBetweenGeometries(first, second);
  assert.equal(res2A, res2.nearestDistance);
}


function testAreaOfPolygon() {
  let polygon = new Polygon();
  polygon.setCoordinates([]);
  polygon.coordinates.push(new Coordinate(34.6508789, 28.4010648, -1000));
  polygon.coordinates.push(new Coordinate(31.1132813, 29.0177480, -1000));
  polygon.coordinates.push(new Coordinate(30.9814453, 27.6446064, -1000));
  polygon.coordinates.push(new Coordinate(32.7392578, 26.0765206, -1000));
  polygon.coordinates.push(new Coordinate(34.6508789, 28.4010648, -1000));
  let geographic = BaseGeometry.geographicLibrary.areaOfGeometry(polygon.clone());
  let geographic2 = geographicCalculations.areaOfGeometry(polygon.clone());
  assert.equal((geographic / 1000) == 65655594.635421164, true);
  assert.equal((geographic2 / 1000) == 65655594.635421164, true);
  let a = 2;
}

function testlocationAndVector() {
  let distance = 3660;
  let azimuth = 90;
  let p1 = new Coordinate(34.84334, 32.30554);
  let azimuthGrid = coordSysConvertor.convertGeoToGridAzimuth(p1, azimuth);
  azimuthGrid = Math.round(azimuthGrid);
  //test via baseGeometry entity
  let p2 = BaseGeometry.geographicLibrary.locationFromLocationAndVector(p1, azimuthGrid, distance);
  let vector = BaseGeometry.geographicLibrary.vectorFromTwoLocations(p1, p2);
  assert.notEqual(vector, null);
  assert.notEqual(vector, undefined);
  let calculatedDistance = Math.round(vector.getDistance()).toFixed(2);
  assert.equal(calculatedDistance, distance);
  let calculatedAzimuth = Math.round(vector.getAzimuth()).toFixed(2);
  assert.equal(calculatedAzimuth, azimuthGrid);


  //test via static geographic library
  p2 = geographicCalculations.locationFromLocationAndVector(p1, azimuthGrid, distance);
  vector = geographicCalculations.vectorFromTwoLocations(p1, p2);
  assert.notEqual(vector, null);
  assert.notEqual(vector, undefined);
  calculatedDistance = Math.round(vector.getDistance()).toFixed(2);
  assert.equal(calculatedDistance, distance);
  calculatedAzimuth = Math.round(vector.getAzimuth()).toFixed(2);
  assert.equal(calculatedAzimuth, azimuthGrid);
}


function testExpandPolygon() {
  let sector = new Sector();
  sector.minimumRadius = 0;
  sector.maximumRadius = 50;
  sector.fromAngle = 20.42;
  sector.toAngle = 70.42;
  sector.coordinates = [];
  sector.coordinates.push(new Coordinate());
  sector.coordinates[0].setLongitude(34.8348126);
  sector.coordinates[0].setLatitude(32.1440598);
  sector.coordinates[0].setAltitude(56.835886);


  let point = new Point();
  point.coordinates = [];
  point.coordinates.push(new Coordinate());
  point.coordinates[0].setLongitude(34.85412);
  point.coordinates[0].setLatitude(-32.1440598);
  point.coordinates[0].setAltitude(11.435);


  let ellipse = new Ellipse();
  ellipse.horizontalRadius = 3008.8295898;
  ellipse.verticalRadius = 8908.44265;
  ellipse.orientation = 220.42;
  ellipse.coordinates = [];
  ellipse.coordinates.push(new Coordinate());
  ellipse.coordinates[0].setLongitude(34.8348126);
  ellipse.coordinates[0].setLatitude(32.1440598);
  ellipse.coordinates[0].setAltitude(56.835886);

  let circle = new Circle();
  circle.radius = 3008.8295898;
  circle.coordinates = [];
  circle.coordinates.push(new Coordinate());
  circle.coordinates[0].setLongitude(34.8348126);
  circle.coordinates[0].setLatitude(32.1440598);
  circle.coordinates[0].setAltitude(56.835886);

  let rectangle1 = new Rectangle();
  rectangle1.width = 3008.8295898;
  rectangle1.height = 600;
  rectangle1.orientation = 30;
  rectangle1.coordinates = [];
  rectangle1.coordinates.push(new Coordinate());
  rectangle1.coordinates[0].setLongitude(34.8348126);
  rectangle1.coordinates[0].setLatitude(32.1440598);
  rectangle1.coordinates[0].setAltitude(56.835886);

  let distance = 50;

  let result1 = sector.clone().expandShape(distance);
  let result2 = point.clone().expandShape(distance);
  let result3 = ellipse.clone().expandShape(distance);
  let result4 = circle.clone().expandShape(distance);
  let result5 = rectangle1.clone().expandShape(distance);


  //test via geographicStaticCalculations
  let result6 = geographicCalculations.expandShape(sector.clone(), distance);
  let result7 = geographicCalculations.expandShape(point.clone(), distance);
  let result8 = geographicCalculations.expandShape(ellipse.clone(), distance);
  let result9 = geographicCalculations.expandShape(circle.clone(), distance);
  let result10 = geographicCalculations.expandShape(rectangle1.clone(), distance);


  const reveresedRectangleAsPolygon = rectangle1.getShapeFallback();
  reveresedRectangleAsPolygon.coordinates.reverse();
  let result11 = geographicCalculations.expandShape(reveresedRectangleAsPolygon.clone(), distance);

  let isFail = false;
  //sector check
  assert.notEqual(result1, null);
  assert.notEqual(result1, undefined);
  assert.equal(result1.getPositionType(), geoKind.Polygon.Name);
  assert.notEqual(result1.coordinates, null);
  assert.notEqual(result1.coordinates, undefined);
  assert.notEqual(result1.coordinates.length, 0);

  assert.notEqual(result2, null);
  assert.notEqual(result2, undefined);
  assert.equal(result2.getPositionType(), geoKind.Circle.Name);
  assert.equal(result2.radius, distance);
  assert.notEqual(result2.coordinates, null);
  assert.notEqual(result2.coordinates, undefined);
  assert.equal(result2.coordinates.length, 1);
  assert.equal(result2.coordinates[0].getLongitude(), 34.85412);
  assert.equal(result2.coordinates[0].getLatitude(), -32.1440598);
  assert.equal(result2.coordinates[0].getAltitude(), 11.435);


  //check ellipse
  assert.notEqual(result3, null);
  assert.notEqual(result3, undefined);
  assert.equal(result3.getPositionType(), geoKind.Ellipse.Name);
  assert.equal(result3.verticalRadius, 8908.44265 + distance);
  assert.equal(result3.horizontalRadius, 3008.8295898 + distance);

  //check ellipse
  assert.notEqual(result4, null);
  assert.notEqual(result4, undefined);
  assert.equal(result4.getPositionType(), geoKind.Circle.Name);
  assert.equal(result4.radius, 3008.8295898 + distance);


  //check rectangle
  assert.notEqual(result5, null);
  assert.notEqual(result5, undefined);
  assert.equal(result5.getPositionType(), geoKind.Rectangle.Name);
  assert.equal(result5.width, 3008.8295898 + distance);
  assert.equal(result5.height, 600 + distance);


//test via geographicStaticCalculations
  assert.notEqual(result6, null);
  assert.notEqual(result6, undefined);
  assert.equal(result6.getPositionType(), geoKind.Polygon.Name);
  assert.notEqual(result6.coordinates, null);
  assert.notEqual(result6.coordinates, undefined);
  assert.notEqual(result6.coordinates.length, 0);

  assert.notEqual(result7, null);
  assert.notEqual(result7, undefined);
  assert.equal(result7.getPositionType(), geoKind.Circle.Name);
  assert.equal(result7.radius, distance);
  assert.notEqual(result7.coordinates, null);
  assert.notEqual(result7.coordinates, undefined);
  assert.equal(result7.coordinates.length, 1);
  assert.equal(result7.coordinates[0].getLongitude(), 34.85412);
  assert.equal(result7.coordinates[0].getLatitude(), -32.1440598);
  assert.equal(result7.coordinates[0].getAltitude(), 11.435);


  //check ellipse
  assert.notEqual(result8, null);
  assert.notEqual(result8, undefined);
  assert.equal(result8.getPositionType(), geoKind.Ellipse.Name);
  assert.equal(result8.verticalRadius, 8908.44265 + distance);
  assert.equal(result8.horizontalRadius, 3008.8295898 + distance);

  //check ellipse
  assert.notEqual(result9, null);
  assert.notEqual(result9, undefined);
  assert.equal(result9.getPositionType(), geoKind.Circle.Name);
  assert.equal(result9.radius, 3008.8295898 + distance);


  //check rectangle
  assert.notEqual(result10, null);
  assert.notEqual(result10, undefined);
  assert.equal(result10.getPositionType(), geoKind.Rectangle.Name);
  assert.equal(result10.width, 3008.8295898 + distance);
  assert.equal(result10.height, 600 + distance);

  //check reversed rectangle as polygon
  assert.notEqual(result11, null);
  assert.notEqual(result11, undefined);
  assert.equal(result11.getPositionType(), geoKind.Polygon.Name);
  assert.notEqual(result11.coordinates, null);
  assert.notEqual(result11.coordinates, undefined);
  assert.notEqual(result11.coordinates.length, 0);
}
