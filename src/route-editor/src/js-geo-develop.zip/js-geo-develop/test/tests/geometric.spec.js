//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.
require('../../src/constants');
global.IS_GEO_LIBRARY_NEEDED = true;
const {geo} = require('../../src/index');
const Coordinate = geo.coordinate;
const Polygon = geo.shapes.polygon;
const {Logger} = require('@elbit/logger-server');
const logger = Logger.getLogger("tests - geometric");
const GeoSerializer = geo.serializer;
const returnTypeEnum = geo.returnTypeEnum;
const geometricCalculations = geo.geometricCalculations;
var assert = require('assert');
const {Helper} = require('../helper');

describe('geometric calculations tests:', function () {

  it("Waiting for geo library asyc load1",async function () {
    await Helper.waitMs(1500)
  });

  it("Waiting for geo library asyc load2",async function () {
    await Helper.waitMs(1500)
  });

  it("Waiting for geo library asyc load2",async function () {
    await Helper.waitMs(1500)
  });

  it("Waiting for geo library asyc load4",async function () {
    await Helper.waitMs(1500)
  });

  it("should test 'CheckIsEquals' functionality:", function () {
    testNearestPointsDistance()
  });

  it("should test 'isContain\isContained\isIntersects\isOverlap' functionality:", function () {
    testIsContainIsIntersectsIsOverlapIsContained()
  });

  it("should test 'locationFromLocationAndVector' && 'vectorFromTwoLocations' functionality:", function () {
    testVectorAndLocation()
  });

  it("should test 'isPolySelfIntersection' functionality:", function () {
    testPolySelfIntersection()
  });

  it("should test geographic 'smoothShapeIfSpline' functionality:", function () {
    testSmoothShapeIfSpatial()
  });
});



function testSmoothShapeIfSpatial() {
  let arrowBase64 = "GQAAAAQCFDySAeyJUlbayRXE-2FBUW9AJQAAAAAAAABcAACvyIA"; //arrow with isSpline=true
  let arrow = geo.serializer.deserializePosition(arrowBase64);
  let begin = Date.now();
  for (i = 0; i < 1000; i++) {
    let result = geometricCalculations.smoothShapeIfSpline(arrow);
  }
  let end = Date.now()
  let diff = (end - begin);
  logger.info("Time for 1000 smoothShapeIfSpline took: " + diff+ "ms");
  assert.equal(diff <= 200, true,"1000 time of smoothShapeIfSpline took more the 200 ms!");
}

function testNearestPointsDistance() {

  //test 2 polygons near the north pole
  let first = new Polygon();
  first.setCoordinates([]);
  first.coordinates.push(new Coordinate(-116.6967773, 77.2544787));
  first.coordinates.push(new Coordinate(-119.0698242, 77.2496302));
  first.coordinates.push(new Coordinate(-120.1684570, 76.8658043));
  first.coordinates.push(new Coordinate(-117.0483398, 76.8707962));
  first.coordinates.push(new Coordinate(-116.2792969, 77.1033276));
  first.coordinates.push(new Coordinate(-116.6967773, 77.2544787));

  let second = new Polygon();
  second.setCoordinates([]);
  second.coordinates.push(new Coordinate(-115.5761719, 76.5475234));
  second.coordinates.push(new Coordinate(-118.2568359, 76.0955169));
  second.coordinates.push(new Coordinate(-115.7519531, 76.2269074));
  second.coordinates.push(new Coordinate(-115.1367188, 75.9522351));
  second.coordinates.push(new Coordinate(-113.9721680, 76.3726195));

  let res1 = geometricCalculations.nearestDistanceBetweenGeometries(first, second);

  //test 2 polygons in Israel
  first = new Polygon();
  first.setCoordinates([]);
  first.coordinates.push(new Coordinate(35.7055664, 31.6533814));
  first.coordinates.push(new Coordinate(34.8486328, 31.9521622));
  first.coordinates.push(new Coordinate(33.3764648, 31.8588970));
  first.coordinates.push(new Coordinate(33.6621094, 30.6757154));
  first.coordinates.push(new Coordinate(35.9252930, 30.5244133));
  first.coordinates.push(new Coordinate(35.7055664, 31.6533814));

  second = new Polygon();
  second.setCoordinates([]);
  second.coordinates.push(new Coordinate(34.6508789, 28.4010648));
  second.coordinates.push(new Coordinate(31.1132813, 29.0177480));
  second.coordinates.push(new Coordinate(30.9814453, 27.6446064));
  second.coordinates.push(new Coordinate(32.7392578, 26.0765206));
  second.coordinates.push(new Coordinate(34.6508789, 28.4010648));

  let res2 = geometricCalculations.nearestDistanceBetweenGeometries(first, second);

  let aaa = 0;
  /*
    //test 2 polygons in Israel
    first=new Polygon();
    first.setCoordinates(new ArrayList<Coordinate>());
    first.getCoordinates().add(new Coordinate(35.7055664, 31.6533814));
    first.getCoordinates().add(new Coordinate(34.8486328, 31.9521622));
    first.getCoordinates().add(new Coordinate(33.3764648, 31.8588970));
    first.getCoordinates().add(new Coordinate(33.6621094, 30.6757154));
    first.getCoordinates().add(new Coordinate(35.9252930, 30.5244133));
    first.getCoordinates().add(new Coordinate(35.7055664, 31.6533814));

    aaaaaa=new com.elbit.applications.BuiltInGeoCalcs.Coordinate[first.getCoordinates().size()];
    i=0;
    for (i=0;i<first.getCoordinates().size();i++) {
        aaaaaa[i]=new com.elbit.applications.BuiltInGeoCalcs.Coordinate();
        aaaaaa[i].Lon = first.getCoordinates().get(i).getLongitude();
        aaaaaa[i].Lat = first.getCoordinates().get(i).getLatitude();
    }

    second=new Polygon();
    second.setCoordinates(new ArrayList<Coordinate>());
    second.getCoordinates().add(new Coordinate(34.6508789, 28.4010648));
    second.getCoordinates().add(new Coordinate(31.1132813, 29.0177480));
    second.getCoordinates().add(new Coordinate(30.9814453, 27.6446064));
    second.getCoordinates().add(new Coordinate(32.7392578, 26.0765206));
    second.getCoordinates().add(new Coordinate(34.6508789, 28.4010648));


    bbbbbb=new com.elbit.applications.BuiltInGeoCalcs.Coordinate[second.getCoordinates().size()];
    i=0;
    for (i=0;i<second.getCoordinates().size();i++) {
        bbbbbb[i]=new com.elbit.applications.BuiltInGeoCalcs.Coordinate();
        bbbbbb[i].Lon = second.getCoordinates().get(i).getLongitude();
        bbbbbb[i].Lat = second.getCoordinates().get(i).getLatitude();
    }
    double dist2= GeoHelpers.GetDistancePolyline2Polyline(aaaaaa,bbbbbb);
    GeoRelationResult resfff2= geographicCalculations.nearestDistanceBetweenGeometries(first,second);*/
}

function testVectorAndLocation() {
  let distance = 3660;
  let azimuth = 90;
  let p1 = new Coordinate(34.84334, 32.30554);
  let p2 = geometricCalculations.locationFromLocationAndVector(p1, azimuth, distance);
  let vector = geometricCalculations.vectorFromTwoLocations(p1, p2);
  assert.equal(vector != null && vector != undefined, true);
  let calculatedDistance = Math.round(vector.getDistance());
  assert.equal(calculatedDistance == distance, true);
  let calculatedAzimuth = Math.round(vector.getAzimuth());
  assert.equal(calculatedAzimuth == azimuth, true);
}

function testIsContainIsIntersectsIsOverlapIsContained() {
  //test line with 2 points against polygon (check intersection and contain)
  let pol = "AgAAAAQCFZTkAe~F0IAAW3DBg8lL23QAAF8dxg0";
  let line2PointsIntersect = "AQAAAAICFXoWAe-25nImAAAAAA";
  let line2PointsInsidePol = "AQAAAAICFUK~Ae-xfmdXwfI";

  let pol_Obj = GeoSerializer.getPosition(pol, returnTypeEnum.customGeoObject);

  let line2PointsIntersect_Obj = GeoSerializer.getPosition(line2PointsIntersect, returnTypeEnum.customGeoObject);
  let line2PointsInsidePol_Obj = GeoSerializer.getPosition(line2PointsInsidePol, returnTypeEnum.customGeoObject);
  let intersectionPoint = pol_Obj.isIntersects(line2PointsIntersect_Obj);
  let intersectionPoint2 = line2PointsIntersect_Obj.isIntersects(pol_Obj);
  let intersectionPoint3 = pol_Obj.isContains(line2PointsInsidePol_Obj);

  logger.info("Testing polyline with 2 points against polygon (intersection and contains):");
  assert.equal(intersectionPoint != null && intersectionPoint.length > 0, true);
  assert.equal(intersectionPoint2 != null && intersectionPoint2.length, true);
  assert.equal(intersectionPoint3, true);

  ////////////////////////////test isContain////////////////////////////
  logger.info("------isContains test start ------");
  /////////////check point in polygon and ellipse in polygon

  let polygon_A = "AgAAAAQCFAqKAey~sfhewFrKUNtsAABXp8Zx";
  let pointInside_polygon_A = "4AIT3iAB7LKvAAAL-Q";
  let pointOutside_polygon_A = "4AIUHf4B7LZvAAAH9w";
  let ellipseInside_polygon_A = "JAIT7bYB7Lm3AAABswAAAEUAAAAA";
  let ellipseOutside_polygon_A = "JAIT5HQB7M8pAAACSAAAALAAAAAA";


  let polygon_A_Obj = GeoSerializer.getPosition(polygon_A, returnTypeEnum.customGeoObject);
  let pointInside_polygon_A_Obj = GeoSerializer.getPosition(pointInside_polygon_A, returnTypeEnum.customGeoObject);
  let pointOutside_polygon_A_Obj = GeoSerializer.getPosition(pointOutside_polygon_A, returnTypeEnum.customGeoObject);
  let ellipseInside_polygon_A_Obj = GeoSerializer.getPosition(ellipseInside_polygon_A, returnTypeEnum.customGeoObject);
  let ellipseOutside_polygon_A_Obj = GeoSerializer.getPosition(ellipseOutside_polygon_A, returnTypeEnum.customGeoObject);


  let isIn1 = polygon_A_Obj.isContains(pointInside_polygon_A_Obj);
  let isIn2 = polygon_A_Obj.isContains(pointOutside_polygon_A_Obj);
  let isIn3 = polygon_A_Obj.isContains(ellipseInside_polygon_A_Obj);
  let isIn4 = polygon_A_Obj.isContains(ellipseOutside_polygon_A_Obj);

  logger.info("Testing point in polygon && ellipse in polygon:");
  assert.equal(isIn1, true);
  assert.equal(isIn3, true);
  assert.equal(isIn2, false);
  assert.equal(isIn4, false);


  ///////////////check polygon in ellipse and circle in ellipse
  let ellipse_A = "JAIT2xQB7L3vAAAEgAAAAhQAAAAA";
  let polygonIn_ellipse_A = "AgAAAAQCE8skAezGX9Qnxq1QpMuaaXxEsA";
  let polygonOutside_ellipse_A = "AgAAAAMCFB0OAeyrp-9YyOhSwMfa";
  let circleIn_ellipse_A = "JQIT6sgB7MZfAAAAww";
  let circleOutside_ellipse_A = "JQIUBMwB7MC~AAABPQ";

  let ellipse_A_Obj = GeoSerializer.getPosition(ellipse_A, returnTypeEnum.customGeoObject);
  let polygonIn_ellipse_A_Obj = GeoSerializer.getPosition(polygonIn_ellipse_A, returnTypeEnum.customGeoObject);
  let polygonOutside_ellipse_A_Obj = GeoSerializer.getPosition(polygonOutside_ellipse_A, returnTypeEnum.customGeoObject);
  let circleIn_ellipse_A_Obj = GeoSerializer.getPosition(circleIn_ellipse_A, returnTypeEnum.customGeoObject);
  let circleOutside_ellipse_A_OutObj = GeoSerializer.getPosition(circleOutside_ellipse_A, returnTypeEnum.customGeoObject);

  isIn1 = ellipse_A_Obj.isContains(polygonIn_ellipse_A_Obj);
  isIn2 = ellipse_A_Obj.isContains(polygonOutside_ellipse_A_Obj);
  isIn3 = ellipse_A_Obj.isContains(circleIn_ellipse_A_Obj);
  isIn4 = ellipse_A_Obj.isContains(circleOutside_ellipse_A_OutObj);

  logger.info("Testing polygon in ellipse && circle in ellipse");
  assert.equal(isIn1, true);
  assert.equal(isIn3, true);
  assert.equal(isIn2, false);
  assert.equal(isIn4, false);


  //check polyline in polygon
  logger.info("Teting polyline in polygon:");
  let polygon_A2 = "AgAAAAQCE9mOAezTB-W8z1pDwOB2AABesFXq";
  let polygon_A2_Obj = GeoSerializer.getPosition(polygon_A2, returnTypeEnum.customGeoObject);
  let polyline_In_polygon_A2 = "AQAAAAUCE84wAezK01YmxQng0MSvUIbJBlPsSUI";
  let polyline_In_polygon_A2_Obj = GeoSerializer.getPosition(polyline_In_polygon_A2, returnTypeEnum.customGeoObject);
  let isPolylineContainIn_polygon_A2 = polygon_A2_Obj.isContains(polyline_In_polygon_A2_Obj);
  let res3 = false;
  assert.equal(isPolylineContainIn_polygon_A2, true);

  logger.info("------isContains test end ------");

  ////////////////////////////test intersection////////////////////////////

  //test intersection between 2 polygons, intesect between polygon and circle
  logger.info("\n------isIntersects test start ------");
  polygon_A2 = "AgAAAAQCFLg~Ae09tIAAvNNAt-AvgABV1AAAxWnJTA";
  let polygon_Intersect_Polygon_A2 = "AgAAAAQCFBDgAez-woAAUpxAW9NP8P4AAGwARKY";
  let circle_outside_NOT_Intersect_Polygon_A2 = "JQIT3bwB7W6yAAAFDw";
  let circle_inside_NOT_Intersect_Polygon_A2 = "JQIUMLQB7QkhAAAC9Q";
  let circle_Intersect_Polygon_A2 = "JQIUmSIB7Qv-AAAC7w";
  polygon_A2_Obj = GeoSerializer.getPosition(polygon_A2, returnTypeEnum.customGeoObject);
  let circle_outside_NOT_Intersect_Polygon_A2_Obj = GeoSerializer.getPosition(circle_outside_NOT_Intersect_Polygon_A2, returnTypeEnum.customGeoObject);
  let circle_inside_NOT_Intersect_Polygon_A2_Obj = GeoSerializer.getPosition(circle_inside_NOT_Intersect_Polygon_A2, returnTypeEnum.customGeoObject);
  let circle_Intersect_Polygon_A2_Obj = GeoSerializer.getPosition(circle_Intersect_Polygon_A2, returnTypeEnum.customGeoObject);
  let polygon_B_Intersect_Polygon_A2_Obj = GeoSerializer.getPosition(polygon_Intersect_Polygon_A2, returnTypeEnum.customGeoObject);
  let isIntersects1 = polygon_A2_Obj.isIntersects(polygon_B_Intersect_Polygon_A2_Obj);
  let isIntersects2 = polygon_B_Intersect_Polygon_A2_Obj.isIntersects(polygon_A2_Obj);
  let isIntersects3 = polygon_A2_Obj.isIntersects(circle_outside_NOT_Intersect_Polygon_A2_Obj);
  let isIntersects4 = polygon_A2_Obj.isIntersects(circle_inside_NOT_Intersect_Polygon_A2_Obj);
  let isIntersects5 = polygon_A2_Obj.isIntersects(circle_Intersect_Polygon_A2_Obj);


  //check intersection between polyline and polygon and polyline and polyline
  let polylineA = "AQAAAAMCE8ySAe03RAAARQVqjgAAVueAAE~A";
  let polylineB = "AQAAAAQCFGcQAe1A7IAAaG3ljQAAVdT6S4AAXg7HJw";
  let polygonIntersectWithPolyA = "AgAAAAQCE~IfAezt8wAAfYdD79yc3x2AAIUJzCg";
  let polylineA_Obj = GeoSerializer.getPosition(polylineA, returnTypeEnum.customGeoObject);
  let polylineB_Obj = GeoSerializer.getPosition(polylineB, returnTypeEnum.customGeoObject);
  let polygonIntersectWithPolyB_Obj = GeoSerializer.getPosition(polygonIntersectWithPolyA, returnTypeEnum.customGeoObject);
  let polyAWithPolyBIntersection = polylineA_Obj.isIntersects(polylineB_Obj);
  let polyBWithPolyAIntersection = polylineB_Obj.isIntersects(polylineA_Obj);
  let polygonBWithPolyAIntersection = polygonIntersectWithPolyB_Obj.isIntersects(polylineB_Obj);
  let polygonBWithPolyAIntersection1 = polygonIntersectWithPolyB_Obj.isIntersects(polylineA_Obj);


  logger.info("Testing isIntersects: polygon with polygon, circle with polygon, polygon with polygon, polyline with polyline");
  assert.equal(isIntersects1 != null && isIntersects1.length > 0, true);
  assert.equal(isIntersects2 != null && isIntersects2.length > 0, true);
  assert.equal(isIntersects3 == null, true);
  assert.equal(isIntersects4 == null, true);
  assert.equal(isIntersects5 != null && isIntersects5.length > 0, true);
  assert.equal(polyAWithPolyBIntersection != null && polyAWithPolyBIntersection.length > 0, true);
  assert.equal(polyBWithPolyAIntersection != null && polyBWithPolyAIntersection.length > 0, true);
  assert.equal(polygonBWithPolyAIntersection != null && polygonBWithPolyAIntersection.length > 0, true);
  assert.equal(polygonBWithPolyAIntersection1 == null, true);


  logger.info("------isIntersects test end ------");
  ////////////test overlap////////////////////////////

  logger.info("\n------isOverlap test start ------");
  let isOverlap1 = polygon_A2_Obj.isOverlap(polygon_B_Intersect_Polygon_A2_Obj);
  let isOverlap2 = polygon_B_Intersect_Polygon_A2_Obj.isOverlap(polygon_A2_Obj);
  let isOverlap13 = polygon_A2_Obj.isOverlap(circle_outside_NOT_Intersect_Polygon_A2_Obj);
  let isOverlap4 = polygon_A2_Obj.isOverlap(circle_inside_NOT_Intersect_Polygon_A2_Obj);
  let isOverlap5 = polygon_A2_Obj.isOverlap(circle_Intersect_Polygon_A2_Obj);
  assert.equal(isOverlap1, true);
  assert.equal(isOverlap2, true);
  assert.equal(isOverlap13, false);
  assert.equal(isOverlap4, true);
  assert.equal(isOverlap5, true);
  logger.info("------isOverlap test end ------");
}

function testPolySelfIntersection() {

  //test 2 polygons near the north pole
  let first = new Polygon();
  first.setCoordinates([]);
  first.coordinates.push(new Coordinate(34.8632593650428, 32.2846988921412));
  first.coordinates.push(new Coordinate(34.8751390174756, 32.2934211554059));
  first.coordinates.push(new Coordinate(34.8782270005243, 32.2831632824115));
  first.coordinates.push(new Coordinate(34.8610796123033, 32.2928376237087));
  first.coordinates.push(new Coordinate(34.8673645660369, 32.2801841995359));
  let res1 = geometricCalculations.isPolySelfIntersection(first, true);
  assert.equal(res1, true);

  let second=new Polygon();
  second.setCoordinates([]);
  second.coordinates.push(new Coordinate(34.8461119768223,	32.2988265016545));
  second.coordinates.push(new Coordinate(34.8683091255575	,32.2989493504329));
  second.coordinates.push(new Coordinate(34.8674735536739,	32.2913941505627));
  second.coordinates.push(new Coordinate(34.8482917295623,	32.2843303458061));
  second.coordinates.push(new Coordinate(34.8439685532947,	32.2919162578708));
  let res2= geometricCalculations.isPolySelfIntersection(second,true);
  assert.equal(res2,false);







}
