//Copyright © 2016-2019 Elbit Systems Ltd. and its affiliates. All rights reserved.
require('../../src/constants');
global.IS_GEO_LIBRARY_NEEDED = true;
const {geo} = require('../../src/index');
const {Logger} = require('@elbit/logger-server');
const logger = Logger.getLogger("tests - serialization");
const GeoSerializer = geo.serializer;
const Coordinate = geo.coordinate;
const BaseGeometry = geo.baseGeometry;
const Polygon = geo.shapes.polygon;
const Polyline = geo.shapes.polyline;
const GeoCamera = geo.shapes.geoCamera;
const Point = geo.shapes.point;
const Circle = geo.shapes.circle;
const Ellipse = geo.shapes.ellipse;
const Rectangle = geo.shapes.rectangle;
const Sector = geo.shapes.sector;
const Corridor = geo.shapes.corridor;
const Arrow = geo.shapes.arrow;
const Arc = geo.shapes.arc;
const TwoPoints = geo.shapes.twoPoints;
const returnTypeEnum = geo.returnTypeEnum;
var assert = require('assert');
const {Helper} = require('../helper');

describe('Serialization tests:', function () {
  it("Waiting for geo library asyc load1",async function () {
    await Helper.waitMs(1500);
    //let aaa ="4AIT3fQB7N09AAAP4Q";
  });

  it('test Rectangle serialization with any return type', function () {
    logger.info("\n\n")
    logger.info("Starting test for Rectangle, return type = customGeoObject: ");
    testRectangle(returnTypeEnum.customGeoObject);
    logger.info("Starting test for Rectangle, return type = geoJson: ");
    testRectangle(returnTypeEnum.geoJson);
    logger.info("Starting test for Rectangle, return type = geoJsonPlusPlus: ");
    testRectangle(returnTypeEnum.geoJsonPlusPlus);
    logger.info("Starting test for Rectangle, return type = geoJsonPlusPlusOnly: ");
    testRectangle(returnTypeEnum.geoJsonPlusPlusOnly);
  });

  it('test GeoCamera serialization with any return type', function () {
    logger.info("\n\n")
    logger.info("Starting test for GeoCamera, return type = customGeoObject: ");
    testGeoCamera(returnTypeEnum.customGeoObject);
    logger.info("Starting test for GeoCamera, return type = geoJson: ");
    testGeoCamera(returnTypeEnum.geoJson);
    logger.info("Starting test for GeoCamera, return type = geoJsonPlusPlus: ");
    testGeoCamera(returnTypeEnum.geoJsonPlusPlus);
    logger.info("Starting test for GeoCamera, return type = geoJsonPlusPlusOnly: ");
    testGeoCamera(returnTypeEnum.geoJsonPlusPlusOnly);
  });

  it('test Arc serialization with any return type', function () {
    logger.info("\n\n")
    logger.info("Starting test for Arc, return type = customGeoObject: ");
    testArc(returnTypeEnum.customGeoObject);
    logger.info("Starting test for Arc, return type = geoJson: ");
    testArc(returnTypeEnum.geoJson);
    logger.info("Starting test for Arc, return type = geoJsonPlusPlus: ");
    testArc(returnTypeEnum.geoJsonPlusPlus);
    logger.info("Starting test for Arc, return type = geoJsonPlusPlusOnly: ");
    testArc(returnTypeEnum.geoJsonPlusPlusOnly);
  });

  it('test Arrow serialization with any return type', function () {
    logger.info("\n\n")
    logger.info("Starting test for Arrow, return type = customGeoObject: ");
    testArrow(returnTypeEnum.customGeoObject);
    logger.info("Starting test for Arrow, return type = geoJson: ");
    testArrow(returnTypeEnum.geoJson);
    logger.info("Starting test for Arrow, return type = geoJsonPlusPlus: ");
    testArrow(returnTypeEnum.geoJsonPlusPlus);
    logger.info("Starting test for Arrow, return type = geoJsonPlusPlusOnly: ");
    testArrow(returnTypeEnum.geoJsonPlusPlusOnly);
  });

  it('test Corridor serialization with any return type', function () {
    logger.info("\n\n")
    logger.info("Starting test for Corridor, return type = customGeoObject: ");
    testCorridor(returnTypeEnum.customGeoObject);
    logger.info("Starting test for Corridor, return type = geoJson: ");
    testCorridor(returnTypeEnum.geoJson);
    logger.info("Starting test for Corridor, return type = geoJsonPlusPlus: ");
    testCorridor(returnTypeEnum.geoJsonPlusPlus);
    logger.info("Starting test for Corridor, return type = geoJsonPlusPlusOnly: ");
    testCorridor(returnTypeEnum.geoJsonPlusPlusOnly);
  });

  it('test Sector serialization with any return type', function () {
    logger.info("\n\n")
    logger.info("Starting test for Sector, return type = customGeoObject: ");
    testSector(returnTypeEnum.customGeoObject);
    logger.info("Starting test for Sector, return type = geoJson: ");
    testSector(returnTypeEnum.geoJson);
    logger.info("Starting test for Sector, return type = geoJsonPlusPlus: ");
    testSector(returnTypeEnum.geoJsonPlusPlus);
    logger.info("Starting test for Sector, return type = geoJsonPlusPlusOnly: ");
    testSector(returnTypeEnum.geoJsonPlusPlusOnly);
  });

  it('test Ellipse serialization with any return type', function () {
    logger.info("\n\n")
    logger.info("Starting test for Ellipse, return type = customGeoObject: ");
    testEllipse(returnTypeEnum.customGeoObject);
    logger.info("Starting test for Ellipse, return type = geoJson: ");
    testEllipse(returnTypeEnum.geoJson);
    logger.info("Starting test for Ellipse, return type = geoJsonPlusPlus: ");
    testEllipse(returnTypeEnum.geoJsonPlusPlus);
    logger.info("Starting test for Ellipse, return type = geoJsonPlusPlusOnly: ");
    testEllipse(returnTypeEnum.geoJsonPlusPlusOnly);
  });

  it('test Circle serialization with any return type', function () {
    logger.info("\n\n")
    logger.info("Starting test for Circle, return type = customGeoObject: ");
    testCircle(returnTypeEnum.customGeoObject);
    logger.info("Starting test for Circle, return type = geoJson: ");
    testCircle(returnTypeEnum.geoJson);
    logger.info("Starting test for Circle, return type = geoJsonPlusPlus: ");
    testCircle(returnTypeEnum.geoJsonPlusPlus);
    logger.info("Starting test for Circle, return type = geoJsonPlusPlusOnly: ");
    testCircle(returnTypeEnum.geoJsonPlusPlusOnly);
  });

  it('test Polyline serialization with any return type', function () {
    logger.info("\n\n")
    logger.info("Starting test for Polyline, return type = customGeoObject: ");
    testPolyline(returnTypeEnum.customGeoObject);
    logger.info("Starting test for Polyline, return type = geoJson: ");
    testPolyline(returnTypeEnum.geoJson);
    logger.info("Starting test for Polyline, return type = geoJsonPlusPlus: ");
    testPolyline(returnTypeEnum.geoJsonPlusPlus);
    logger.info("Starting test for Polyline, return type = geoJsonPlusPlusOnly: ");
    testPolyline(returnTypeEnum.geoJsonPlusPlusOnly);
    logger.info("Starting test for Polyline from standard geoJson ");
    testSetPositionFromStandardGeoJson();
  });

  it('test Polygon serialization with any return type', function () {
    logger.info("\n\n")
    logger.info("Starting test for Polygon, return type = customGeoObject: ");
    testPolygon(returnTypeEnum.customGeoObject);
    logger.info("Starting test for Polygon, return type = geoJson: ");
    testPolygon(returnTypeEnum.geoJson);
    logger.info("Starting test for Polygon, return type = geoJsonPlusPlus: ");
    testPolygon(returnTypeEnum.geoJsonPlusPlus);
    logger.info("Starting test for Polygon, return type = geoJsonPlusPlusOnly: ");
    testPolygon(returnTypeEnum.geoJsonPlusPlusOnly);
  });

  it('test Point serialization with any return type', function () {
    logger.info("\n\n")
    logger.info("Starting test for Point, return type = customGeoObject: ");
    testPoint(returnTypeEnum.customGeoObject);
    logger.info("Starting test for Point, return type = geoJson: ");
    testPoint(returnTypeEnum.geoJson);
    logger.info("Starting test for Point, return type = geoJsonPlusPlus: ");
    testPoint(returnTypeEnum.geoJsonPlusPlus);
    logger.info("Starting test for Point, return type = geoJsonPlusPlusOnly: ");
    testPoint(returnTypeEnum.geoJsonPlusPlusOnly);
  });

  it('test TwoPoints serialization with any return type', function () {
    logger.info("\n\n")
    logger.info("Starting test for TwoPoints, return type = customGeoObject: ");
    testTwoPoints(returnTypeEnum.customGeoObject);
    logger.info("Starting test for TwoPoints, return type = geoJson: ");
    testTwoPoints(returnTypeEnum.geoJson);
    logger.info("Starting test for TwoPoints, return type = geoJsonPlusPlus: ");
    testTwoPoints(returnTypeEnum.geoJsonPlusPlus);
    logger.info("Starting test for TwoPoints, return type = geoJsonPlusPlusOnly: ");
    testTwoPoints(returnTypeEnum.geoJsonPlusPlusOnly);
  });

  it('test standard geoJson', function () {
    logger.info("\n\n")
    logger.info("Starting test for standard geoJson ");
    testSetPositionFromStandardGeoJson();
  });
});


function testPoint(returnType) {
  let point = new Point();
  point.coordinates = [];
  point.coordinates.push(new Coordinate())
  point.coordinates[0].setLongitude(34.85412);
  point.coordinates[0].setLatitude(-32.144059);
  point.coordinates[0].setAltitude(11.435);

  let base64String = GeoSerializer.setPosition(point);
  let shape = GeoSerializer.getPosition(base64String, returnType);
  if (returnType != returnTypeEnum.customGeoObject) {
    shape = JSON.stringify(shape);
    base64String = GeoSerializer.setPosition(shape);
    if (base64String != null && base64String != undefined) {
      shape = GeoSerializer.getPosition(base64String, returnType);
    } else {
      return;
    }
  } else {
    base64String = GeoSerializer.setPosition(shape);
    shape = GeoSerializer.getPosition(base64String, returnType);
  }

  if (returnType == returnTypeEnum.customGeoObject) {
    assert.equal(shape.coordinates.length, 1);
    assert.equal(shape.coordinates[0].getLongitude(), 34.85412);
    assert.equal(shape.coordinates[0].getLatitude(), -32.144059);
    assert.equal(shape.coordinates[0].getAltitude(), 11.43);
  } else {
    logger.info(JSON.stringify(shape));
  }
}


function testPolygon(returnType) {
  let polygon = new Polygon();
  polygon.coordinates = [];
  polygon.coordinates.push(new Coordinate());
  polygon.coordinates[0].setLongitude(34.835356);
  polygon.coordinates[0].setLatitude(32.171189);
  polygon.coordinates.push(new Coordinate());
  polygon.coordinates[1].setLongitude(34.853999);
  polygon.coordinates[1].setLatitude(32.165734);
  polygon.coordinates.push(new Coordinate());
  polygon.coordinates[2].setLongitude(34.865309);
  polygon.coordinates[2].setLatitude(32.151999);
  polygon.coordinates.push(new Coordinate());
  polygon.coordinates[3].setLongitude(34.835356);
  polygon.coordinates[3].setLatitude(32.171189);
  polygon.isCustomGeoObject = true;

  let base64String = GeoSerializer.setPosition(polygon);
  let shape = GeoSerializer.getPosition(base64String, returnType);
  if (returnType != returnTypeEnum.customGeoObject) {
    shape = JSON.stringify(shape);
    base64String = GeoSerializer.setPosition(shape);
    if (base64String != null && base64String != undefined) {
      shape = GeoSerializer.getPosition(base64String, returnType);
    } else {
      return;
    }
  } else {
    base64String = GeoSerializer.setPosition(shape);
    shape = GeoSerializer.getPosition(base64String, returnType);
  }

  if (returnType == returnTypeEnum.customGeoObject) {
    assert.equal(shape.coordinates.length, 4);
    assert.equal(shape.coordinates[0].getLongitude(), 34.835356);
    assert.equal(shape.coordinates[0].getLatitude(), 32.171189);
    assert.equal(shape.coordinates[1].getLongitude(), 34.853999);
    assert.equal(shape.coordinates[1].getLatitude(), 32.165734);
    assert.equal(shape.coordinates[2].getLongitude(), 34.865309);
    assert.equal(shape.coordinates[2].getLatitude(), 32.151999);
    assert.equal(shape.coordinates[3].getLongitude(), 34.835356);
    assert.equal(shape.coordinates[3].getLatitude(), 32.171189);
  } else {
    logger.info(JSON.stringify(shape))
  }
}


function convertToStandardGeoJsonFunc(baseGeo) {

  return {
    type: baseGeo.geometry.type,
    coordinates: baseGeo.geometry.coordinates
  };
}

function testPolyline(returnType, convertToStandardGeoJson) {
  let polyline = new Polyline();
  polyline.coordinates = [];
  polyline.coordinates.push(new Coordinate());
  polyline.coordinates[0].setLongitude(34.835356);
  polyline.coordinates[0].setLatitude(32.171189);
  polyline.coordinates.push(new Coordinate());
  polyline.coordinates[1].setLongitude(34.853999);
  polyline.coordinates[1].setLatitude(32.165734);
  polyline.coordinates.push(new Coordinate());
  polyline.coordinates[2].setLongitude(34.865309);
  polyline.coordinates[2].setLatitude(32.151999);
  polyline.coordinates.push(new Coordinate());
  polyline.coordinates[3].setLongitude(34.864968);
  polyline.coordinates[3].setLatitude(32.135232);
  polyline.coordinates.push(new Coordinate());
  polyline.coordinates[4].setLongitude(34.835356);
  polyline.coordinates[4].setLatitude(32.171189);

  let base64String = GeoSerializer.setPosition(polyline);
  let shape = GeoSerializer.getPosition(base64String, returnType);

  if (convertToStandardGeoJson) {
    let geoJson = GeoSerializer.getPosition(base64String, returnTypeEnum.geoJson);
    polyline = convertToStandardGeoJsonFunc(geoJson);
    base64String = GeoSerializer.setPosition(polyline);
    shape = GeoSerializer.getPosition(base64String, returnType);
  }
  if (returnType != returnTypeEnum.customGeoObject) {
    shape = JSON.stringify(shape);
    base64String = GeoSerializer.setPosition(shape);
    if (base64String != null && base64String != undefined) {
      shape = GeoSerializer.getPosition(base64String, returnType);
    } else {
      return;
    }
  } else {
    base64String = GeoSerializer.setPosition(shape);
    shape = GeoSerializer.getPosition(base64String, returnType);
  }

  if (returnType == returnTypeEnum.customGeoObject) {
    assert.equal(shape.coordinates.length, 5);
    assert.equal(shape.coordinates[0].getLongitude(), 34.835356);
    assert.equal(shape.coordinates[0].getLatitude(), 32.171189);
    assert.equal(shape.coordinates[1].getLongitude(), 34.853999);
    assert.equal(shape.coordinates[1].getLatitude(), 32.165734);
    assert.equal(shape.coordinates[2].getLongitude(), 34.865309);
    assert.equal(shape.coordinates[2].getLatitude(), 32.151999);
    assert.equal(shape.coordinates[3].getLongitude(), 34.864968);
    assert.equal(shape.coordinates[3].getLatitude(), 32.135232);
    assert.equal(shape.coordinates[4].getLongitude(), 34.835356);
    assert.equal(shape.coordinates[4].getLatitude(), 32.171189);
  } else {
    logger.info(JSON.stringify(shape));
  }
}

function testCircle(returnType) {
  let circle = new Circle();
  circle.radius = 3008.8295898;
  circle.coordinates = [];
  circle.coordinates.push(new Coordinate());
  circle.coordinates[0].setLongitude(34.834812);
  circle.coordinates[0].setLatitude(32.144059);
  circle.coordinates[0].setAltitude(56.835886);

  let base64String = GeoSerializer.setPosition(circle);
  let shape = GeoSerializer.getPosition(base64String, returnType);
  if (returnType != returnTypeEnum.customGeoObject) {

    shape = JSON.stringify(shape);
    base64String = GeoSerializer.setPosition(shape);
    if (base64String != null && base64String != undefined) {
      shape = GeoSerializer.getPosition(base64String, returnType);
    } else {
      return;
    }
  } else {
    base64String = GeoSerializer.setPosition(shape);
    shape = GeoSerializer.getPosition(base64String, returnType);
  }

  if (returnType == returnTypeEnum.customGeoObject) {
    assert.equal(shape.radius, 3008);
    assert.equal(shape.coordinates.length, 1);
    assert.equal(shape.coordinates[0].getLongitude(), 34.834812);
    assert.equal(shape.coordinates[0].getLatitude(), 32.144059);
    assert.equal(shape.coordinates[0].getAltitude(), 56.83);
  } else {
    logger.info(JSON.stringify(shape));
  }
}


function testEllipse(returnType) {
  let ellipse = new Ellipse();
  ellipse.horizontalRadius = 3008.8295898;
  ellipse.verticalRadius = 8908.44265;
  ellipse.orientation = 220.42;
  ellipse.coordinates = [];
  ellipse.coordinates.push(new Coordinate());
  ellipse.coordinates[0].setLongitude(34.834812);
  ellipse.coordinates[0].setLatitude(32.144059);
  ellipse.coordinates[0].setAltitude(56.835886);

  let base64String = GeoSerializer.setPosition(ellipse);
  let shape = GeoSerializer.getPosition(base64String, returnType);
  if (returnType != returnTypeEnum.customGeoObject) {
    shape = JSON.stringify(shape);
    base64String = GeoSerializer.setPosition(shape);
    if (base64String != null && base64String != undefined) {
      shape = GeoSerializer.getPosition(base64String, returnType);
    } else {
      return;
    }
  } else {
    base64String = GeoSerializer.setPosition(shape);
    shape = GeoSerializer.getPosition(base64String, returnType);
  }

  if (returnType == returnTypeEnum.customGeoObject) {
    assert.equal(shape.horizontalRadius, 3008);
    assert.equal(shape.verticalRadius, 8908);
    assert.equal(shape.orientation, 220.42);
    assert.equal(shape.coordinates.length, 1);
    assert.equal(shape.coordinates[0].getLongitude(), 34.834812);
    assert.equal(shape.coordinates[0].getLatitude(), 32.144059);
    assert.equal(shape.coordinates[0].getAltitude(), 56.83);
  } else {
    logger.info(JSON.stringify(shape));
  }
}

function testSector(returnType) {
  let sector = new Sector();
  sector.minimumRadius = 3008.8295898;
  sector.maximumRadius = 8908.44265;
  sector.fromAngle = 20.42;
  sector.toAngle = 70.42;
  sector.coordinates = [];
  sector.coordinates.push(new Coordinate());
  sector.coordinates[0].setLongitude(34.834812);
  sector.coordinates[0].setLatitude(32.144059);
  sector.coordinates[0].setAltitude(56.835886);

  let base64String = GeoSerializer.setPosition(sector);
  let shape = GeoSerializer.getPosition(base64String, returnType);
  if (returnType != returnTypeEnum.customGeoObject) {
    shape = JSON.stringify(shape);
    base64String = GeoSerializer.setPosition(shape);
    if (base64String != null && base64String != undefined) {
      shape = GeoSerializer.getPosition(base64String, returnType);
    } else {
      return;
    }
  } else {
    base64String = GeoSerializer.setPosition(shape);
    shape = GeoSerializer.getPosition(base64String, returnType);
  }

  if (returnType == returnTypeEnum.customGeoObject) {
    assert.equal(shape.minimumRadius, 3008);
    assert.equal(shape.maximumRadius, 8908);
    assert.equal(shape.fromAngle, 20.42);
    assert.equal(shape.toAngle, 70.42);
    assert.equal(shape.coordinates.length, 1);
    assert.equal(shape.coordinates[0].getLongitude(), 34.834812);
    assert.equal(shape.coordinates[0].getLatitude(), 32.144059);
    assert.equal(shape.coordinates[0].getAltitude(), 56.83);
  } else {
    logger.info(JSON.stringify(shape));
  }
}


function testCorridor(returnType) {
  let corridor = new Corridor();
  corridor.radius = 30;
  corridor.coordinates = [];
  corridor.coordinates.push(new Coordinate());
  corridor.coordinates[0].setLongitude(34.835356);
  corridor.coordinates[0].setLatitude(32.171189);
  corridor.coordinates.push(new Coordinate());
  corridor.coordinates[1].setLongitude(34.853999);
  corridor.coordinates[1].setLatitude(32.165734);
  corridor.coordinates.push(new Coordinate());
  corridor.coordinates[2].setLongitude(34.865309);
  corridor.coordinates[2].setLatitude(32.151999);
  corridor.coordinates.push(new Coordinate());
  corridor.coordinates[3].setLongitude(34.835356);
  corridor.coordinates[3].setLatitude(32.171189);

  let base64String = GeoSerializer.setPosition(corridor);
  let shape = GeoSerializer.getPosition(base64String, returnType);
  if (returnType != returnTypeEnum.customGeoObject) {
    shape = JSON.stringify(shape);
    base64String = GeoSerializer.setPosition(shape);
    if (base64String != null && base64String != undefined) {
      shape = GeoSerializer.getPosition(base64String, returnType);
    } else {
      return;
    }
  } else {
    base64String = GeoSerializer.setPosition(shape);
    shape = GeoSerializer.getPosition(base64String, returnType);
  }

  if (returnType == returnTypeEnum.customGeoObject) {
    assert.equal(shape.radius, 30);
    assert.equal(shape.coordinates.length, 4);
    assert.equal(shape.coordinates[0].getLongitude(), 34.835356);
    assert.equal(shape.coordinates[0].getLatitude(), 32.171189);
    assert.equal(shape.coordinates[1].getLongitude(), 34.853999);
    assert.equal(shape.coordinates[1].getLatitude(), 32.165734);
    assert.equal(shape.coordinates[2].getLongitude(), 34.865309);
    assert.equal(shape.coordinates[2].getLatitude(), 32.151999);
    assert.equal(shape.coordinates[3].getLongitude(), 34.835356);
    assert.equal(shape.coordinates[3].getLatitude(), 32.171189);
  } else {
    logger.info(JSON.stringify(shape));
  }
}


function testArrow(returnType) {
  let arrow = new Arrow();
  arrow.gap = 50;
  arrow.headSize = 100;
  arrow.headAngle = 45.2244567;
  arrow.coordinates = [];
  arrow.coordinates.push(new Coordinate());
  arrow.coordinates[0].setLongitude(34.835356);
  arrow.coordinates[0].setLatitude(32.171189);
  arrow.coordinates.push(new Coordinate());
  arrow.coordinates[1].setLongitude(34.853999);
  arrow.coordinates[1].setLatitude(32.165734);
  arrow.coordinates.push(new Coordinate());
  arrow.coordinates[2].setLongitude(34.865309);
  arrow.coordinates[2].setLatitude(32.151999);
  arrow.coordinates.push(new Coordinate());
  arrow.coordinates[3].setLongitude(34.835356);
  arrow.coordinates[3].setLatitude(32.171189);

  let base64String = GeoSerializer.setPosition(arrow);
  let shape = GeoSerializer.getPosition(base64String, returnType);
  if (returnType != returnTypeEnum.customGeoObject) {
    shape = JSON.stringify(shape);
    base64String = GeoSerializer.setPosition(shape);
    if (base64String != null && base64String != undefined) {
      shape = GeoSerializer.getPosition(base64String, returnType);
    } else {
      return;
    }
  } else {
    base64String = GeoSerializer.setPosition(shape);
    shape = GeoSerializer.getPosition(base64String, returnType);
  }

  if (returnType == returnTypeEnum.customGeoObject) {
    assert.equal(shape.gap, 50);
    assert.equal(shape.headSize, 100);
    assert.equal(shape.headAngle, 45.224);
    assert.equal(shape.coordinates.length, 4);
    assert.equal(shape.coordinates[0].getLongitude(), 34.835356);
    assert.equal(shape.coordinates[0].getLatitude(), 32.171189);
    assert.equal(shape.coordinates[1].getLongitude(), 34.853999);
    assert.equal(shape.coordinates[1].getLatitude(), 32.165734);
    assert.equal(shape.coordinates[2].getLongitude(), 34.865309);
    assert.equal(shape.coordinates[2].getLatitude(), 32.151999);
    assert.equal(shape.coordinates[3].getLongitude(), 34.835356);
    assert.equal(shape.coordinates[3].getLatitude(), 32.171189);

  } else {
    logger.info(JSON.stringify(shape));
  }
}


function testArc(returnType) {
  let arc = new Arc();
  arc.radius = 3008.8295898;
  arc.fromAngle = 15.443;
  arc.toAngle = 340.5541234;
  arc.coordinates = [];
  arc.coordinates.push(new Coordinate());
  arc.coordinates[0].setLongitude(34.834813);
  arc.coordinates[0].setLatitude(32.144059);
  let base64String = GeoSerializer.setPosition(arc);
  let shape = GeoSerializer.getPosition(base64String, returnType);
  if (returnType != returnTypeEnum.customGeoObject) {
    shape = JSON.stringify(shape);
    base64String = GeoSerializer.setPosition(shape);
    if (base64String != null && base64String != undefined) {
      shape = GeoSerializer.getPosition(base64String, returnType);
    } else {
      return;
    }
  } else {
    base64String = GeoSerializer.setPosition(shape);
    shape = GeoSerializer.getPosition(base64String, returnType);
  }

  if (returnType == returnTypeEnum.customGeoObject) {
    assert.equal(shape.radius, 3008);
    assert.equal(shape.fromAngle, 15.443);
    assert.equal(shape.toAngle, 340.554);

    assert.equal(shape.coordinates.length, 1);
    assert.equal(shape.coordinates[0].getLongitude(), 34.834813);
    assert.equal(shape.coordinates[0].getLatitude(), 32.144059);
  } else {
    logger.info(JSON.stringify(shape));
  }
}


function testGeoCamera(returnType) {
  let geoCamera = new GeoCamera();
  geoCamera.coordinates = [];
  //push camera location
  geoCamera.coordinates.push(new Coordinate());
  geoCamera.coordinates[0].setLongitude(34.835356);
  geoCamera.coordinates[0].setLatitude(32.171189);
  //push camera sight location
  geoCamera.coordinates.push(new Coordinate());
  geoCamera.coordinates[1].setLongitude(34.853999);
  geoCamera.coordinates[1].setLatitude(32.165734);
  //push camera sight Polygon
  geoCamera.coordinates.push(new Coordinate());
  geoCamera.coordinates[2].setLongitude(34.865309);
  geoCamera.coordinates[2].setLatitude(32.151999);
  geoCamera.coordinates.push(new Coordinate());
  geoCamera.coordinates[3].setLongitude(34.864968);
  geoCamera.coordinates[3].setLatitude(32.135233);
  geoCamera.coordinates.push(new Coordinate());
  geoCamera.coordinates[4].setLongitude(34.835356);
  geoCamera.coordinates[4].setLatitude(32.171189);

  let base64String = GeoSerializer.setPosition(geoCamera);
  let shape = GeoSerializer.getPosition(base64String, returnType);
  if (returnType != returnTypeEnum.customGeoObject) {
    shape = JSON.stringify(shape);
    base64String = GeoSerializer.setPosition(shape);
    if (base64String != null && base64String != undefined) {
      shape = GeoSerializer.getPosition(base64String, returnType);
    } else {
      return;
    }
  } else {
    base64String = GeoSerializer.setPosition(shape);
    shape = GeoSerializer.getPosition(base64String, returnType);
  }

  if (returnType == returnTypeEnum.customGeoObject) {
    assert.equal(shape.coordinates.length, 5);
    assert.equal(shape.coordinates[0].getLongitude(), 34.835356);
    assert.equal(shape.coordinates[0].getLatitude(), 32.171189);
    assert.equal(shape.coordinates[1].getLongitude(), 34.853999);
    assert.equal(shape.coordinates[1].getLatitude(), 32.165734);
    assert.equal(shape.coordinates[2].getLongitude(), 34.865309);
    assert.equal(shape.coordinates[2].getLatitude(), 32.151999);
    assert.equal(shape.coordinates[3].getLongitude(), 34.864968);
    assert.equal(shape.coordinates[3].getLatitude(), 32.135233);
    assert.equal(shape.coordinates[4].getLongitude(), 34.835356);
    assert.equal(shape.coordinates[4].getLatitude(), 32.171189);
  } else {
    logger.info(JSON.stringify(shape));
  }
}


function testRectangle(returnType) {

  let rectangle = new Rectangle();
  rectangle.width = 3008.8295898;
  rectangle.height = 600;
  rectangle.orientation = 30;
  rectangle.coordinates = [];
  rectangle.coordinates.push(new Coordinate());
  rectangle.coordinates[0].setLongitude(34.834812);
  rectangle.coordinates[0].setLatitude(32.144059);
  rectangle.coordinates[0].setAltitude(56.835886);

  let base64String = GeoSerializer.setPosition(rectangle);
  let shape = GeoSerializer.getPosition(base64String, returnType);
  if (returnType != returnTypeEnum.customGeoObject) {
    shape = JSON.stringify(shape);
    base64String = GeoSerializer.setPosition(shape);
    if (base64String != null && base64String != undefined) {
      shape = GeoSerializer.getPosition(base64String, returnType);
    } else {
      return;
    }
  } else {
    base64String = GeoSerializer.setPosition(shape);
    shape = GeoSerializer.getPosition(base64String, returnType);
  }

  if (returnType == returnTypeEnum.customGeoObject) {
    assert.equal(shape.width, 3008);
    assert.equal(shape.height, 600);
    assert.equal(shape.coordinates.length, 1);
    assert.equal(shape.coordinates[0].getLongitude(), 34.834812);
    assert.equal(shape.coordinates[0].getLatitude(), 32.144059);
    assert.equal(shape.coordinates[0].getAltitude(), 56.83);
  } else {
    logger.info(JSON.stringify(shape));
  }

}

function testTwoPoints(returnType) {
  let twoPoints = new TwoPoints();
  twoPoints.coordinates = [];
  twoPoints.coordinates.push(new Coordinate());
  twoPoints.coordinates[0].setLongitude(34.85412);
  twoPoints.coordinates[0].setLatitude(-32.144059);
  twoPoints.coordinates.push(new Coordinate());
  twoPoints.coordinates[1].setLongitude(36);
  twoPoints.coordinates[1].setLatitude(-30.144059);


  let base64String = GeoSerializer.setPosition(twoPoints);
  let shape = GeoSerializer.getPosition(base64String, returnType);
  if (returnType != returnTypeEnum.customGeoObject) {
    shape = JSON.stringify(shape);
    base64String = GeoSerializer.setPosition(shape);
    if (base64String != null && base64String != undefined) {
      shape = GeoSerializer.getPosition(base64String, returnType);
    } else {
      return;
    }
  } else {
    base64String = GeoSerializer.setPosition(shape);
    shape = GeoSerializer.getPosition(base64String, returnType);
  }

  if (returnType == returnTypeEnum.customGeoObject) {
    assert.equal(shape.coordinates.length, 2);
    assert.equal(shape.coordinates[0].getLongitude(), 34.85412);
    assert.equal(shape.coordinates[0].getLatitude(), -32.144059);
    assert.equal(shape.coordinates[1].getLongitude(), 36);
    assert.equal(shape.coordinates[1].getLatitude(), -30.144059);
  } else {
    logger.info(JSON.stringify(shape));
  }
}



function testSetPositionFromStandardGeoJson() {
  let base64String, base64StringFromStandard;

  // Test polyline
  logger.info("Test polyline");
  let polyline = {type: "Feature", geometry: {}};
  polyline.geometry.coordinates = [[34.8353564, 32.1711894, 0], [34.8539997, 32.1657348, 0]];
  polyline.geometry.type = "LineString";
  let polylineStandard = {type: "LineString"};
  polylineStandard.coordinates = [[34.8353564, 32.1711894, 0], [34.8539997, 32.1657348, 0]];
  base64String = GeoSerializer.setPosition(polyline);
  base64StringFromStandard = GeoSerializer.setPosition(polylineStandard);
  assert.equal(base64String, base64StringFromStandard);


  // Test polygon
  logger.info("Test polygon");
  let polygon = {type: "Feature", geometry: {}};
  polygon.geometry.coordinates = [[[34.8353564, 32.1711894], [34.8539997, 32.1657348],[34.8653097, 32.1519998],[34.8353564, 32.1711894]]];
  polygon.geometry.type = "Polygon";
  let polygonStandard = {type: "Polygon"};
  polygonStandard.coordinates =  [[[34.8353564, 32.1711894], [34.8539997, 32.1657348],[34.8653097, 32.1519998],[34.8353564, 32.1711894]]];
  base64String = GeoSerializer.setPosition(polygon);
  base64StringFromStandard = GeoSerializer.setPosition(polygonStandard);
  assert.equal(base64String, base64StringFromStandard);

  // Test point
  logger.info("Test point");
  let point = {type: "Feature", geometry: {}};
  point.geometry.coordinates = [34.8353564, 32.1711894, 0];
  point.geometry.type = "Point";
  let pointStandard = {type: "Point"};
  pointStandard.coordinates = [34.8353564, 32.1711894, 0];
  base64String = GeoSerializer.setPosition(point);
  base64StringFromStandard = GeoSerializer.setPosition(pointStandard);
  assert.equal(base64String, base64StringFromStandard);
}





